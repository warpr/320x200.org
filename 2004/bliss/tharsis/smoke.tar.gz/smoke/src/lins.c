/*
    "linsen.c"
    example effect for "pdsys" (Perplexity Demo SYStem).
    Just shows basic structure (which is very ugly atm) 
    Yes this is not beautiful, yes there is unused code in here.
    no we don't care :)
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
    #include <windows.h>
#else
    #include <sys/time.h>
#endif

#include "tinyptc.h"
#include "pdsys.h"
#include "pngload.h"
#include "lins.h"
#include "timing.h"

/* size = size of lens, m = magnification */
void 
lensInit(int *t, int size, int m)
{
    int r=size/2;
    float s=sqrt(r*r-m*m);
    int y, x;
    int a=0;
    int b=0;
    float z;
    
    for(y=-r;y<r;y++)
    {
        for(x=-r;x<r;x++)
        {
            if(x*x+y*y>=s*s)
               {
                   a=x;
                 b=y;
              }
            else
               {
                  z=sqrt(r*r-x*x-y*y);
                 a=(x*m/(float)z+0.5);
                  b=(y*m/(float)z+0.5);
            }
            t[(y+r)*size+(x+r)]=(b+r)*size+(a+r);
        }
    }
}    

void 
lensInvert(int *t, int size)
{
    int i;
    for(i=0;i<size;i++)t[size*size-1-i]=i;
}

void 
lensFlipX(int *t, int size)
{
    int i, j;
    for(i=0;i<size;i++)
    {
        for(j=0;j<size;j++)
        {
            t[i*size+j]=i*size+size-1-j;
        }
    }
}

void 
lensFlipY(int *t, int size)
{
    int i, j;
    for(i=0;i<size;i++)
    {
        for(j=0;j<size;j++)
        {
            t[i*size+j]=(size-1-j)*size+i;
        }
    }
}

void 
lensMagnify(int *t, int size, int m)
{
    int i, j;
    for(i=0;i<size;i++)
    {
        for(j=0;j<size;j++)
        {
            t[i*size+j]=(i/m)*size+(j/m);
        }
    }
}

void 
initTables(int *sint, int *cost)
{
    int c;
    double i;
    i=0.0;
    for(c=0;c<256;c++,i++)
    {
        sint[c]=(int)(sin(i/255.0*2.0*PI)*50);
        cost[c]=(int)(cos(i/255.0*2.0*PI)*40);
    }
}

/* true init function */
void 
linsInit(void *nfo)
{
    int s = ((linsData *)nfo)->size;
    ((linsData *)nfo)->tmpbuf = malloc(sizeof(int32)*(s*s));

    lensInit(((linsData *)nfo)->lt, ((linsData *)nfo)->size, ((linsData *)nfo)->magni);    /* make lens table */
    initTables(((linsData *)nfo)->st, ((linsData *)nfo)->ct);    /* cos + sine table */
    putPNG(((linsData *)nfo)->texturename, (rgba *)((linsData *)nfo)->texture, 320, 0, 0);    /* put picture */
}

void 
linsMisc(void)
{
    printf("\tpdsys: lensEffect->effectMisc()\n");
    printf("\t...done.\n");
}

/*
void
linsLoop(signed int *buf, long stopt, void *info)
{
    int32 *img = ((linsScn *)info)->lins.texture;

    long st, td = 0;
    st = getUTime();
    while(td < stopt) {
        linsRender(buf, getUTime() - st, ((linsScn *)info)->lins);
        ptc_update(buf);
        memcpy(buf, img, RES*4);
        td = getUTimeDif(st);
    }
}
*/
    
void 
linsRender(signed int *buf, long stopt, linsData d)
{
    float xp, yp;
    int x, y;
    int32 *tmp=d.tmpbuf;
    int32 *img=buf; //d.texture;
    int32 *lut=d.lt;
    int *slt=d.st;    /* sine and cosine lookup tables */
    int *clt=d.ct;

    xp=(slt[(int)(stopt/20)<<1&255]+((XRES-(LENS>>1))>>1));
    yp=(clt[(int)(stopt/20)&255]+((YRES-(LENS>>1))>>1));
    if(yp<(YRES-LENS) && xp<(XRES-LENS))
    {
        for(y=0;y<LENS;y++)
        {
            for(x=0;x<LENS;x++)
            {
                tmp[x+y*LENS]=img[(int)(x+xp+(yp+y)*XRES)];
                buf[(int)(x+xp+(yp+y)*XRES)]=tmp[lut[x+y*LENS]];
            }
        }
    }
}

void 
linsClean(void *info)
{
    printf("\tpdsys: lensEffect->effectClean()\n");
    free(((linsData *)info)->texture);
    free(((linsData *)info)->tmpbuf);
    free(((linsData *)info)->ct);
    free(((linsData *)info)->st);
    free(((linsData *)info)->lt);
    printf("\t...done.\n");
}
