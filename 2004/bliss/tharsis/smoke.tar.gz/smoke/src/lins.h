#define PI 3.141592
#define TEXTURE "data/bday.png"    /* background */
#define LENS 64    /* size of lens */
#define MAGNIFICATION 5    /* lower = more magnification*/

/* sigh, this is effect specific stuff (not very modular that is;) */
typedef struct
{
    int32 *texture;    /* buffer holding texture */
    int32 *tmpbuf;     /* temporary buffer for effect */
    char *texturename;    /* path to texture */
    int *ct, *st;    /* cos, sine tables */
    int32 *lt;    /* lens table */
    
    int size;     /* parameters to the effect */
    int magni;
    int32 *to;
} linsData;

/*
typedef struct
{
    linsData lins;
} linsScn;
*/

void linsInit(void *nfo);
void linsMisc(void);
void linsRender(signed int *buf, long stopt, linsData d);
void linsClean(void *info);
