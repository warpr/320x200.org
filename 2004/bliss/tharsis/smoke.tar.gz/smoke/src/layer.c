/* not for pdsys.
    a bit hacked for intro.
*/

#include "pdsys.h"
#include "layer.h"
#include <stdlib.h>

/* Creates a layer with some basic default values.
    The layer returned should be inserted to a linkedList.
    Properties of the layer can be changed with the layerSet* functions */
layer *
layerCreate(unsigned int xres, unsigned int yres, BLENDMODE mode)
{
    layer *tmp;
    
    tmp=(layer *)malloc(sizeof(layer));
    tmp->buffer=(rgba *)malloc(sizeof(rgba)*(xres*yres));
    tmp->blendmode=mode;
    tmp->blendvalue=0.0;
    tmp->visible=FALSE;
    tmp->x=tmp->y=0;
    tmp->xres=xres;
    tmp->yres=yres;
    
    return tmp;
}

/* This will free all memory occupied by the layer target.
    WARNING: This layer should be removed from the linkedList as well! */
void
layerDestroy(layer *target)
{
    free(target->buffer);
    free(target);
}

/* wrapper functions for setting properties of the layer */
/* ____________________________________________________  */

void
layerSetBlendmode(layer *target, BLENDMODE mode)
{
    target->blendmode=mode;
}

void
layerSetBlendvalue(layer *target, float value)
{
    if(value>1.0)value=1.0;
    if(value<0.0)value=0.0;
    target->blendvalue=value;
}

void
layerSetPos(layer *target, unsigned int x, unsigned int y)
{
    /* perhaps some error checking against the main surface's borders */
    target->x=x;
    target->y=y;
}

void
layerSetBuffer(layer *target, rgba *buffer)
{
    free(target->buffer);   /* WARNING: this could cause trouble */
    target->buffer=buffer;
}

void 
layerSetVisible(layer *target, BOOL value)
{
    target->visible=value;
}

void
layerSetRes(layer *target, unsigned int xres, unsigned int yres)
{
    target->xres=xres;
    target->yres=yres;
    target->buffer=(rgba *)realloc(target->buffer, sizeof(rgba)*(xres*yres));
}

void
layerBlit(layer *target, layer *source)
{
    int x, y, xstart, i = 0;

    /* first we check which blendmode the source uses */
    switch(source->blendmode) {
        case NONE:
            break;
        case ALPHA:
            layerBlitAlpha(target, source);
            return;
        case ADDITIVE:
            /* layerBlitAdd(target, source); */
            return;
        case SUBTRACTIVE:
            /* layerBlitSub(target, source); */
            return;
        default:
            return;
    }

    for(y = source->y; y < source->yres+source->y; y++) {
        xstart = y*target->xres;
        for(x = source->x; x < source->xres+source->x; x++)
            target->buffer[xstart+x] = source->buffer[i++];
    }
}

void
layerBlitAlpha(layer *target, layer *source) {
    int x, y, xstart, alpha, i = 0;
    BOOL checkAlpha = TRUE;
    rgba to, from;

    if(source->blendvalue < 1 && source->blendvalue > 0) {
        alpha = source->blendvalue * 256;
        checkAlpha = FALSE;
    }

    for(y = source->y; y < source->yres+source->y; y++) {
        xstart = y*target->xres;
        for(x = source->x; x < source->xres+source->x; x++) {
            to = target->buffer[xstart+x];
            from = source->buffer[i];

            if(checkAlpha)
                alpha = from.a;

            if(from.a != 0xFF && (from.r!=0 && from.g!=0 && from.b!=0)) {
                to.r = (from.r+(to.r-from.r)*alpha/256);
                to.g = (from.g+(to.g-from.g)*alpha/256);
                to.b = (from.b+(to.b-from.b)*alpha/256);

                target->buffer[xstart+x] = to;
            }

            i++;
        }
    }
}

