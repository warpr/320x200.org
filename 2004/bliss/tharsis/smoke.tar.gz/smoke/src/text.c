#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>	/* for toupper */

#ifdef _WIN32
	#include <windows.h>
#endif

#include "tinyptc.h"
#include "pdsys.h"
#include "pngload.h"
#include "text.h"
#include "timing.h"

#define FONT "../data/font.png"
#define CHARX 10
#define CHARY 14
#define FONTX 320

int 
printSimple(int32 *font, int32 *to, char *string, int xp, int yp, char *fontbet)
{
	int len;
	int x, y, i, j, tmp, xo=xp, yo=yp;
	char c;

	len=strlen(string);
	
	for(i=0;i<len;i++)
	{
        if(string[i]==' '){ i++; xo+=(CHARX-1); }
		c=toupper(string[i]);	/* get upper-case */
		for(j=0;j<strlen(fontbet);j++)if(c==fontbet[j])break;
        tmp=(j*CHARX);
		for(y=0;y<CHARY;y++)
		{
			xp=xo;
			for(x=tmp;x<(tmp+CHARX);x++)
			{
                            if(xp < 320 && xp > 0) {
				if(font[x+y*FONTX]!=0)to[xp+yp*XRES]=font[x+y*FONTX];
                            }
                            xp++;
			}
			yp++;
		}
		xo+=(CHARX);
		yp=yo;
	}
	return 0;
}

void 
simplerInit(void *info)
{
    int i;
	printf("\tpdsys: simplerEffect->effectInit()\n");
	putPNG(((textDat *)info)->fontname, (rgba *)((textDat *)info)->font, FONTX, 0, 0);
        for(i = 0; i < 360; i++)
            ((textDat *)info)->st[i] = sin(i*3.14159/180)*92;
	printf("\t...done.\n");
}

void 
simplerMisc(void)
{
	printf("\tpdsys: simplerEffect->effectMisc()\n");
	printf("\t...done.\n");
}

void 
simplerRender(signed int *buf, long stopt, textDat d)
{
    int32 *fon=d.font;
    char *fontbet=d.fontbet;
    int y;
    char *text = "                                   Yo smoke!, A happy birthday from everyone in demoscene at openprojects.  I hope you had some nice cake -appeltaart!- and beer and all that ... and ofcourse that you may live very long and make many demos-intros or other interesting things which need creating. Well, skypher is keeping a tight deadline, so I'll stop now, thanks for everything  .warp-bliss                ... yes this was a fun little prod to do... ...end of scroller....sort of .. bye, and happy birthday again..hehe..";
    int length = strlen(text)*10;

    if(stopt < 1800)
        y = d.st[stopt/20];
    else
        y = 92;

    memset(buf, 0, RES*4);	
    printSimple(fon, buf, "HELLO SMOKE", 1, 10, fontbet);
    printSimple(fon, buf, "HAPPY BIRTHDAY", 10, 30, fontbet);
    printSimple(fon, buf, text, -(stopt/20)%length, y, fontbet); /* %450 is the total width of the string */
}

void 
simplerClean(void *info)
{
	printf("\tpdsys: simplerEffect->effectClean()\n");
	free(((textDat *)info)->font);
	printf("\t...done.\n");
}
/*	
int 
main(void)
{
	int32 pixel[XRES*240];	
	demoEffect fx;
	simplerDat sdata;
	
	fx.init=simplerInit;	
	fx.etc=simplerMisc;
	fx.render=simplerRender;
	fx.clean=simplerClean;
	
	sdata.fontname=FONT;
	sdata.font=malloc(sizeof(int32)*(FONTX*7));
	sdata.fontbet="ABCDEFGHIJKLMNOPQRSTUVWXYZ���/@-:.,�><!?;+";
	
	if(!ptc_open("pdsys - Perplexity Demos SYStem (simple text)", XRES, 240))return -1;
	
	fx.init(&sdata);/
	fx.etc();
	fx.render(pixel, 100, &sdata);
	fx.clean(&sdata);
	
	ptc_close();
	return 0;
}
*/
