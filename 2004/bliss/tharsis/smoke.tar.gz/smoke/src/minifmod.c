#include <stdio.h>

unsigned int FFILE_Open(char *name)
{
  return((unsigned int)fopen(name, "rb"));
}

void FFILE_Close(unsigned int handle)
{
  fclose((FILE *)handle);
}

int FFILE_Read(void *buffer, int size, unsigned int handle)
{
  return(fread(buffer, 1, size, (FILE *)handle));
}

void FFILE_Seek(unsigned int handle, int pos, signed char mode)
{
  fseek((FILE *)handle, pos, mode);
}

int FFILE_Tell(unsigned int handle)
{
  return(ftell((FILE *)handle));
}
