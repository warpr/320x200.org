/* sigh, this is effect specific stuff (not very modular that is;) */
typedef struct
{
	int32 *font;	/* buffer holding font */
	char *fontname;	/* path to font */
	char *fontbet;	/* availability and order of chars in font */
    int32 *to;  /* hello */
    int st[360];
} textDat;

void simplerInit(void *);
void simplerClean(void *);
void simplerRender(signed int *, long, textDat);
