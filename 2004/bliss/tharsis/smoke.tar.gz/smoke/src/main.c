/* happy birthday smoke. */

#include <stdio.h>
#include <stdlib.h>

/* graphicx lib */
#include "tinyptc.h"

/* stuff */
#include "pdsys.h"
#include "lists.h"  /* includes layer.h as well */
#include "timing.h"
#include "pngload.h"
#include "minifmod.h"

/* other stuff */
#include "text.h"
#include "lins.h"

layer *text, *logo;
typedef struct
{
    linsData lens;
    textDat txt;
} smokeScn;

void
ptc_cleanup_callback(void)
{
    printf("happy birthday to smoke/ECFH, from all in #demoscene @ openprojects !\n");
}

void
smokeInit(void *info)
{
    linsInit(&((smokeScn *)info)->lens);
    simplerInit(&((smokeScn *)info)->txt);
}

void
smokeMisc(void)
{
}

void
smokeLoop(signed int *buf, long stopt, void *info)
{
    long st, td=0;
    linsData l=((smokeScn *)info)->lens;
    textDat t=((smokeScn *)info)->txt;

    st=getUTime();
    for(;;)
    {
        memcpy(buf, l.texture, RES*4);
        simplerRender((signed int *)text->buffer, getUTime()-st, t); 
        layerBlit(logo, text);
        linsRender(buf, getUTime(), l);
        ptc_update(buf);
        td=getUTimeDif(st);
    }
}

void
smokeClean(void *info)
{
    linsData l=((smokeScn *)info)->lens;
    textDat t=((smokeScn *)info)->txt;

    linsClean(&l);
    simplerClean(&t);
}

int 
main(int argc, char *argv[])
{
    int32 pixel[RES];
    FMUSIC_MODULE *music;
    demoEffect fx;
    linsData l;
    textDat t;
    smokeScn scene;

    linkedList *headp=NULL;
    linkedList *new=NULL;
    logo=layerCreate(XRES, YRES, NONE);
    layerSetBuffer(logo, (rgba *)pixel);
    text=layerCreate(XRES, YRES, ALPHA);
    layerSetBlendvalue(text, 0.6);

    layerSetVisible(logo, TRUE);
    layerSetVisible(text, TRUE);
    
    headp=addElementToStart(new, headp, logo);    /* ! */
    headp=addElementToEnd(new, headp, text);

    fx.init=smokeInit;
    fx.etc=smokeMisc;
    fx.loop=smokeLoop;
    fx.clean=smokeClean; 
   
    t.fontname="data/font.png";
    t.font=malloc(sizeof(int32)*(320*14));
    t.fontbet="ABCDEFGHIJKLMNOPQRSTUVWXYZ.,!?-";
    t.to=(int32 *)text->buffer;
    
    l.texture=malloc(sizeof(int32)*(RES*4));
    l.texturename="data/bday.png";
    l.st=malloc(sizeof(int)*(256));
    l.ct=malloc(sizeof(int)*(256));
    l.magni=5;
    l.size=64;
    l.lt=malloc(sizeof(int32)*(64*64)); 
    scene.txt=t;
    scene.lens=l;
    /*
    0. init ptc & start music
    1. clear screen.
    2. paint logo background
    3. paint text & lins on that.
    goto 1 until esc pressed then goto 4.
    4. clean up, shut down music etc 
    */ 
    fx.init(&scene); 
    /* 0 */
    if(!ptc_open("Happy birthday smoke!", XRES, YRES))return 1; 
    if(!argv[1])
    {
        FSOUND_File_SetCallbacks(FFILE_Open, FFILE_Close, FFILE_Read, FFILE_Seek, FFILE_Tell);
        if(!FSOUND_Init(44100, 0))return -1;
        music = FMUSIC_LoadSong("data/bday.xm", 0);
        if(!music)
            return 404;
        FMUSIC_PlaySong(music);
    } 

    memset(pixel, 0, RES*4);
    fx.loop(pixel, 0, &scene);
    ptc_close();
    fx.clean(&scene);
    layerDestroy(text);
    freeAllElements(headp);
    if(!argv[1])
    {
        FMUSIC_StopSong(music);
        FMUSIC_FreeSong(music);
        FSOUND_Close();
    }
    return 0;
}
