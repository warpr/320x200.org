/*
    foundation of layer implementation
    skypher / plx
    2002
*/

#ifndef LAYER_H
#define LAYER_H

typedef enum { NONE=0, ALPHA=1, ADDITIVE=2, SUBTRACTIVE=3 } BLENDMODE;
typedef enum { FALSE=0, TRUE=1} BOOL;   /* this should be moved to pdsys.h */

typedef struct
{
    unsigned int xres, yres;  /* dimensions of the layer */
    BLENDMODE blendmode;    /* blendmode of the layer */
    float blendvalue;   /* something between 0 and 1. (0=no blending) */
    unsigned int x, y;  /* x and y position of the layer. */
    rgba *buffer; /* buffer to render layer to */
    BOOL visible;   /* is the layer on? */
} layer;

layer *layerCreate(unsigned int xres, unsigned int yres, BLENDMODE mode);
void layerDestroy(layer *target);
void layerSetBlendmode(layer *target, BLENDMODE mode);
void layerSetBlendvalue(layer *target, float value);
void layerSetPos(layer *target, unsigned int x, unsigned int y);
void layerSetBuffer(layer *target, rgba *buffer);
void layerSetVisible(layer *target, BOOL value);
void layerSetRes(layer *target, unsigned int xres, unsigned int yres);
void layerBlit(layer *target, layer *source);
void layerBlitAlpha(layer *target, layer *source);

#endif  /* LAYER_H */
