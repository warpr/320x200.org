long getTimeDif(long start);
long getTime(void);
long getUTime(void);
long getUTimeDif(long start);
