/*
 Ugly pngloader for PDSYS by skywarper\plx
 
 Loads 24bit non-interlaced png pix
 onto a 32bit surface (tinyptc style)

 OBS! It has no error handling at all! *todo*
*/

#ifndef PNGLOAD_H
#define PNGLOAD_H

int putPNG(const char *file, rgba *surface, int xRes, int x, int y);

#endif /* PNGLOAD_H */

