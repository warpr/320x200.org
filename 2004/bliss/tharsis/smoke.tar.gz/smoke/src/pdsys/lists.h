#include "layer.h"

typedef struct linkedList linkedList;

struct linkedList {
    layer *data;	
	linkedList *next;
};

linkedList *addElementToStart(linkedList *thenew, linkedList *tpointer, layer *info);
int getNElements(linkedList *tpointer);
linkedList *delLastElement(linkedList *tpointer);
linkedList *addElementToEnd(linkedList *thenew, linkedList *tpointer, layer *info);
linkedList *addElement(linkedList *thenew, linkedList *tpointer, int where, layer *info);
linkedList *delFirstElement(linkedList *tpointer);
linkedList *delElement(linkedList *tpointer, int which);
void freeAllElements(linkedList *tpointer);
void displayAllElements(linkedList *tpointer);
