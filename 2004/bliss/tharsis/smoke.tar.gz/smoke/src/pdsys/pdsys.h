#ifndef PDSYS_H
#define PDSYS_H

#define XRES 320
#define YRES 200
#define RES XRES*YRES

typedef struct
{
    unsigned char b, g, r;
} rgb;

typedef struct
{
    unsigned char b, g, r, a;
} rgba;

/* function pointer typedefs */
typedef void (*effectInit)(void *);	/* hmm :) */
typedef void (*effectMisc)(void);
// typedef void (*effectDo)(int32 *buf, float stopt, void *extra);
// typedef void (*effectDo)(signed int *, long, void *);
typedef void (*effectLoop)(signed int *, long, void *);
typedef void (*effectClean)(void *);

/* effect struct 
	upon creation of an demoEffect always prefix name with e_ (or just e)
	ex: demoEffect e_fire or demoEffect eFire */
typedef struct
{
	effectInit init;	/* init function */
	effectMisc etc;	/* any extra init functions may be placed here */
	// effectDo render;	/* draw function */
    effectLoop loop;    /* loop function */
	effectClean clean;	/* clean up function */
} demoEffect;

typedef void (*modifier)(signed *buf);
/* modifier struct, prefix with m_ or m */
typedef struct
{
	unsigned int amount;	/* amount od modifying */
	unsigned char r, g, b;	/* color modification */
	unsigned int xs, ys;	/* x and y start co-ordinates */
	unsigned int xe, ye;	/* x and y end co-ordinates */
	modifier filter;	/* modifying function */
} mod;

#endif /* PDSYS_H */
