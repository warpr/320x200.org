#ifdef _WIN32
    #include <windows.h>
#else
    #include <sys/time.h>
#endif
#include <stdio.h>

long
getTime(void)
{
    #ifdef _WIN32
        return (GetTickCount()/1000);
    #else
        struct timeval ct;
        gettimeofday(&ct, NULL);
        return ct.tv_sec;
    #endif
}

long
getTimeDif(long start)
{
    return (getTime()-start);
}

long
getUTime(void)
{
    #ifdef _WIN32
        return GetTickCount();
    #else
        struct timeval ct;
        gettimeofday(&ct, NULL);
        return (ct.tv_sec*1000)+ct.tv_usec/1000;
    #endif
}

long
getUTimeDif(long start)
{
    return (getUTime()-start);
}
