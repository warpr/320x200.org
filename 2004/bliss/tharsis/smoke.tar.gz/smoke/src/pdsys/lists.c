/*
	Linked list blahada

	Joel Carlbark 2001 - 2002
    skypher / PLX
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#include "pdsys.h"
#include "lists.h"

/*typedef struct linkedList linkedList;

struct linkedList {
    layer *data;	
	linkedList *next;
};*/

linkedList *addElementToStart(linkedList *thenew, linkedList *tpointer, layer *info);
int getNElements(linkedList *tpointer);
linkedList *delLastElement(linkedList *tpointer);

linkedList *
addElementToEnd(linkedList *thenew, linkedList *tpointer, layer *info)
{
	linkedList *cur=tpointer;
	
    if(cur==NULL)
    {
        thenew=(linkedList *)malloc(sizeof(linkedList));
        thenew->data=info;
        tpointer=thenew;
    }
    else
    {
	    while(cur->next!=NULL)	/* goto end of list */
	    {
		    cur=cur->next;
	    }
	
	    thenew=malloc(sizeof(linkedList));
	
	    cur->next=thenew;
	    thenew->next=NULL;
	
	    /* add data */
        thenew->data=info;	
    }	
	return tpointer;	
}

linkedList *
addElement(linkedList *thenew, linkedList *tpointer, int where, layer *info)
{
	linkedList *cur=NULL, *prev=NULL;
	int nelements=0, i=1;

	nelements=getNElements(tpointer);

	if(where<1 || where>nelements+1)
	{
		printf("out of bounds\n");
		return tpointer;
	}
	
	else if(where==1)
	{
		tpointer=addElementToStart(thenew, tpointer, info);
		return tpointer;
	}
	cur=tpointer->next;
	
	if(cur==NULL)
	{
		tpointer=addElementToEnd(thenew, tpointer, info);
		return tpointer;
	}
	else	
	{
		thenew=malloc(sizeof(linkedList));	
		cur=tpointer;
		while(cur!=NULL && i<where-1)
		{
			cur=cur->next;
			i++;
		}
		prev=cur->next;
		cur->next=thenew;
		thenew->next=prev;	
		
		/* add data */
		thenew->data=info;
	}
	return tpointer;						
}

linkedList *
addElementToStart(linkedList *thenew, linkedList *tpointer, layer *info)
{
		thenew=malloc(sizeof(linkedList));
		thenew->next=tpointer;
		tpointer=thenew;
		
		/* add the data */	
		thenew->data=info;

		return tpointer;
}

linkedList *
delFirstElement(linkedList *tpointer)
{
	linkedList *cur;
	cur=tpointer;
	tpointer=cur->next;
	free(cur);
	return tpointer;
}

linkedList *
delElement(linkedList *tpointer, int which)
{
	linkedList *cur, *last, *tmp;
	int i, nelements;
	
	nelements=getNElements(tpointer);
	
	if(which<1 || which>nelements)
	{
		printf("%d: Out of bounds\n", which);
		return tpointer;
	}
	
	if(which==1)
	{
		tpointer=delFirstElement(tpointer);
		return tpointer;
	}
	cur=tpointer->next;
	if(cur==NULL || which==nelements)
	{
		tpointer=delLastElement(tpointer);
		return tpointer;
	}
	else	
	{	
		i=1;
		cur=tpointer;
		while(i<which-1)
		{
			cur=cur->next;
			i++;
		}
		last=cur->next;
		tmp=cur->next;
		last=last->next;
		cur->next=last;
		
		free(tmp);
			
	}
	return tpointer;
}
		
linkedList *
delLastElement(linkedList *tpointer)
{
	linkedList *cur, *last;
	int nelements, i=1;
	
	nelements=getNElements(tpointer);
	cur=tpointer;
	while(i<nelements-1)
	{
		cur=cur->next;
		i++;
	}
	
	last=cur->next;
	cur->next=NULL;
	free(last);
	
	return tpointer;
}

void 
freeAllElements(linkedList *tpointer)
{
	linkedList *cur, *nxt;

	cur=tpointer;
	while(cur!=NULL)
	{
		nxt=cur->next;
		free(cur);
		cur=nxt;
	}
}
/* FIXME: not really useful for pdsys, but anyways...
void 
displayElement(linkedList *tpointer, int which)
{
	linkedList *cur=NULL;	
	int nelements=0, i=1;	

	nelements=getNElements(tpointer);
	if(which>nelements || which<1)
	{
		printf("%d: Out of bounds\n", which);
		return;
	}
	else
	{
		cur=tpointer;	
		while(cur!=NULL && i<which)
		{
			cur=cur->next;
			i++; 
		}
		printf("%d Firstname:\t%s\n", i, cur->firstname);
		printf("%d  Lastname:\t%s\n", i, cur->lastname);
		printf("%d   Subject:\t%s\n", i, cur->subject);
		printf("%d  Comments:\t%s\n", i, cur->comments);
		printf("%d       Age:\t%d\n\n", i, cur->age);
	}
}	
*/

int 
getNElements(linkedList *tpointer)
{
	linkedList *tmp;
	int ne=0;
	tmp=tpointer;
	while(tmp!=NULL)
	{
		tmp=tmp->next;
		ne++;
	}
	return ne;
}

void 
displayAllElements(linkedList *tpointer)
{
	int i, nelements;
	linkedList *cur;
	
	nelements=getNElements(tpointer);
	cur=tpointer;
	i=1;	
	while(cur!=NULL)
	{
		printf("Layer: %d\n\twidth: %d\n", i, cur->data->xres);
        printf("\theight: %d\n", cur->data->yres);
		printf("\tblendmode: %d\n", cur->data->blendmode);
		printf("\tblendvalue: %f\n", cur->data->blendvalue);
		printf("\tx position: %d\n", cur->data->x);
        printf("\ty position: %d\n", cur->data->y);
        printf("\tvisible: %s\n\n", (cur->data->visible==1)?"yes":"no");
		cur=cur->next;
		i++;
	}
}
		
/*		
int 
main(int argc, char *argv[])
{
	int i;
	linkedList *headp=NULL;
	linkedList *new=NULL;
	linkedList *this=NULL;
	layer *nfo, add;
	
	strcpy(nfo.firstname, "Joel");
	strcpy(nfo.lastname, "Carlbark");
	strcpy(nfo.subject, "HL Computer Science");
	strcpy(nfo.comments, "Elajt0rz h4XXOR!@#$*");
	nfo.age=18;
	
	strcpy(add.firstname, "Joel");
	strcpy(add.lastname, "Cbark");
	strcpy(add.subject, "Programming");
	strcpy(add.comments, "pHEAR bEER");
	add.age=666;
	
	headp=addElementToStart(new, headp, nfo);
	headp=addElementToEnd(new, headp, nfo);
	headp=addElementToEnd(new, headp, nfo);
	headp=addElement(new, headp, 2, add);
	
	displayAllElements(headp);
	headp=delElement(headp, 3);
	displayAllElements(headp);
	
	freeAllElements(headp);	
	return 0;
}
*/
