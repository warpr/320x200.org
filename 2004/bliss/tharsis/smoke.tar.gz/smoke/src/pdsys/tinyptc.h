/*
 *
 * TinyPTC SDL v0.2.1 ported by Alessandro Gatti (a.gatti@tiscalinet.it)
 * Original Windows version by Glenn Fiedler (ptc@gaffer.org)
 * http://www.gaffer.org/tinyptc
 *
 */

#ifndef __TINY_PTC_SDL
#define __TINY_PTC_SDL

typedef unsigned int int32;
typedef unsigned char char8;
typedef unsigned short int16;
typedef unsigned short short16;

extern int ptc_open(char *title, int width, int height);
extern int ptc_update(void *buffer);
extern void ptc_close(void);
int ptc_process_events(void);
		
/* #define __PTC_WINDOWED__ */
/* #define __PTC_CENTER_WINDOW__ */
#define __PTC_ENABLE_CONVERSIONS__

#endif /* __TINY_PTC_SDL */
