/*
 Ugly pngloader for PDSYS by skywarper\plx
 
 Loads 24bit non-interlaced png pix
 onto a 32bit surface (tinyptc style)

 OBS! It has no error handling at all! *todo*
*/

#include <stdlib.h>
#include <png.h>

#include "tinyptc.h"
#include "pdsys.h"

int putPNG(const char *file, rgba *surface, int xRes, int x, int y) {
    unsigned char buf[4];

    png_structp pngPtr;
    png_infop infoPtr;
    png_uint_32 width, height;
    int bpp, color, row, column;
    png_bytep rowPtr;
    signed int *tmpSurface;
    unsigned char alpha;

    FILE *fp = fopen(file, "rb");
    

    /* first we read the header and check if it's pngformat */
    if(fread(buf, 1, 4, fp) != 4)
        return 404;
    if(png_sig_cmp(buf, 0, 4))
        return 404;

    /* here we read in some pointers, don't know, don't care */
    pngPtr = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
    if(!pngPtr)
        return 404;

    infoPtr = png_create_info_struct(pngPtr);
    if(!infoPtr)
        return 404;

    if(setjmp(pngPtr->jmpbuf))
        return 404;

    /* now we start reading the accual png */
    png_init_io(pngPtr, fp);
    png_set_sig_bytes(pngPtr, 4);
    png_read_info(pngPtr, infoPtr);

    /* we want to know width, height, depth and so on */
    png_get_IHDR(pngPtr, infoPtr, &width, &height, &bpp, &color, 0, 0, 0);
    png_set_bgr(pngPtr);
    if (color & PNG_COLOR_MASK_ALPHA)
        png_set_invert_alpha(pngPtr);
    if(bpp == 8 && color == PNG_COLOR_TYPE_RGB)
        png_set_filler(pngPtr, 0x00, PNG_FILLER_AFTER);
    png_read_update_info(pngPtr, infoPtr);

    tmpSurface = malloc(sizeof(signed int)*width*height);

    /* finally we put the png on the surface! */
    for(row = 0; row < height; row++) {
        rowPtr = (png_bytep)(tmpSurface+row*width);
        png_read_row(pngPtr, rowPtr, 0);
    }
    for(row = 0; row < height; row++) {
        for(column = 0; column < width; column++) {
            alpha = *(signed int *)(tmpSurface+row*width+column)>>24;
            if(alpha || color != PNG_COLOR_TYPE_RGB_ALPHA)
                *(signed int *)(surface+(row+y)*xRes+(column+x)) = *(signed int *)(tmpSurface+row*width+column);
        }
    }

    /* and now we just read the last of the file */
    png_read_end(pngPtr, infoPtr);

    /* clean up and return */
    png_destroy_read_struct(&pngPtr, &infoPtr, (png_infopp)0);
    fclose(fp);

    return 0;
}

