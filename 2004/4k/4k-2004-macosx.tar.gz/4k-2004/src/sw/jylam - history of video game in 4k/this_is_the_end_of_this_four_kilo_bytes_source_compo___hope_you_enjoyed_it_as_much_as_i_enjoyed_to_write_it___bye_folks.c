/* History of video game (?)    */
/* (c) 2004 Jean-Yves Lamoureux jylam@lnxscene.org */
#include "s.h"
#define I for(i=0;i<W;i++)
#define L 1,2,1,2,1,2,1,2,
#define Z ,0,0,0,0,0,0,
#define O i+y*W
#define A bx + px
#define Y (by + py)
#define D (3.14/180)*
#define T ( ( i * ((float)(F2) / (float)(W)) ) - F )
#define C if(c == 
#define E V[O] = 
#define J (D t) * 150.0f)+4.0f*B;
#define K (D  (h+T));
#define M (H/2)
#define ML SDL_GetTicks()
#define N while((!SDL_PollEvent(&e)||e.type!=2)&&(ML<n)){SDL_LockSurface(b);
#define P ; SDL_UnlockSurface (b);SDL_Flip (b);}
#define R (sin((D (ix)+y*70)/5000.0f)*50.0f)
#define S ((fo[y+l*15]&
#define LAM Q(y*10,10,10,mx+py
#define JY )?30:255);
#define X4 255,255,
#define X2 X4 255,
#define X X2 X2 X4
#define X3 239,239,
#define FE ;N TX P memset(V,0,H*W*4);
#define AR strcpy(sf,
#define TX  {int i,l,y,py,mx;py=0;mx=0;  for(i=0;i<strlen(sf);i++){l = sf[i]-97;if(l!=-2)for(y=0;y<15;y++)\
      {LAM,S 128)>>7 JY LAM+10,S 64)>>6 JY LAM+20,S 32)>>5 JY LAM+30,S 16)>>4 JY \
       LAM+40,S 8)>>3 JY LAM+50,S 4)>>2  JY LAM+60,S 2)>>1  JY LAM+70,S 1) JY}\
      py+=80;}}
      float a[640],s,h=45, bx, by,rx, ry,ax, ay,he,t,o,
      m[]={L 2 Z 1, 1 Z 2,2,0,0,16,0,0,0,1,1,0,0,0,24,0,0,2,2 Z 1,1 Z 2,L};
      int x,y,px,py, mx=0,my=99,*p,*V,i,c=0,W=640,H=480,B=64,F2=90,
/********************************************************************************/
/**/      F=45, n, ix=10,iy=10,l,fo[]={ X2  X2 199,187,251,131,               /**/
/**/              123,123,133, X2  X4 127,127,127,71,59,125,125,125,59,71,    /**/
/**/                     X 197,185,125,127,127,189,195, X4                    /**/
/**/                 X2 249,253,253,197,185,125,125,125,185,196, X2 255,      /**/
/**/                   X2 255,199,187,125,1,127,189,195, X2  X4 241,          /**/
/**/                         238,239,129, X3  X3 239,129, X                   /**/
/**/          196,185,125,125,125,185,197,253,253,195, X4 63,191,191,163,157, /**/
/**/                  189,189,189,189,24, X2  X4  X3 255,143, X3  X3          /**/
/**/             239,1, X2  X4 247,247,255,131,251,251,251,251,251,251,251,   /**/
/**/             251,135, X4 63,191,191,176,187,183,143,183,187,48, X2  X4    /**/
/**/     143, X3  X3  X3  X3 1, X2  X2  X4 73,37,109,109,109,109,36, X 35,157,/**/
/**/                      189,189,189,189,24, X 199,187,125,125,125,          /**/
/**/                      187,199, X 35,157,190,190,190,157,163,191,          /**/
/**/             191,15, X2  X4 196,185,125,125,125,185,197,253,253,240,255,  /**/
/**/                         X2 255,17,206,223,223,223,223,3, X               /**/
/**/              193,189,191,195,253,189,131, X2  X2 191,191,3,191,191,191,  /**/
/**/                    191,189,195, X 57,189,189,189,189,185,196,255,        /**/
/**/                    X2  X2 255,16,125,187,187,215,215,239, X2  X4         /**/
/**/                        X2 56,125,109,171,171,147,187, X 17,              /**/
/**/                   187,215,239,215,187,17, X 56,125,187,187,215,          /**/
/**/                                   215, X3 223};                          /**/
                 unsigned char st[]=__FILE__,sf[99];; SDL_Surface * b;
  int Q(int d,int f,int g, int s, int c) {SDL_Rect r;r.x=s;r.y=d;r.w=f;r.h=g;SDL_FillRect(b,&r,c);}
                        int main (int warp, char **is_annoying){ 
        SDL_Event e; b = SDL_SetVideoMode(W, H, 32, 0);V = b->pixels;t = 45;
                            /* (pitite chose rulez) */
                                AR "history");n=2000 
                                 FE AR "of");n=4000 
                               FE AR "video");n=6000 
                                FE AR "game");n=8000 
                                FE AR "in");n=10000 
                              FE AR "four_k");n=12000 
                                  FE AR "pong");
/**/mx=99; px=20;py=350;n=25000;N memset(V, 0,W*H*4);Q(px,50,150,10,0xFFFFFF);/**/
/**/Q(py,50,150,580,0xFFFFFF);Q(my,10,10,mx,0xFFFFFF);mx+=ix;my+=iy;if(mx>=580/**/
/**/| mx<=60) ix=-ix;if(my>=470 | my<=0) iy=-iy; px++;py--;if(px>=330)break;TX/**/
/**/P AR "vroom");n = 32000;N ix=ML*1000;c=(800000-ML)/10;for(y=0;y<H/2;y++) I/**/
/**/V[O] = (256-y)<<8;for(y=H/2;y<H;y++) I V[O] = ((y+20)<<8)+((y+20)<<16);   /**/
/**/for(y=M;y<H;y++){py = (R+50)+((H-y));px = (R+550)-((H-y));for(i=py;i<px;  /**/
/**/i++)if((i>=((py+px)/2)&&i<=((py+px)/2)+10)&&(y+c)&16)E 0xFFFFFF; else E   /**/
/**/0x999999;} TX  P AR "doom");px=py=64;n = 50000; N t=ML/20;                /**/
/**/px=(sin J py=(cos J p= V+W* H / 2; while((p--) -V) {                      /**/
/**/p[0] = 0x9900; p[ W * H / 2 ]= 99; }                                      /**/
/**/i=W;while(i--){rx = bx =                                                  /**/   
/**/sin K ry = by = cos K z:                                                  /**/
/**/bx+=(rx);by+=(ry);                                                        /**/
/**/ax = A;ay = Y;          /* This hole bring to you by lazyness */          /**/
/**/mx = ((A)/B);my =                                                         /**/
/**/( (Y)/ B );c = m[ mx+ my                                                  /**/
/**/ *8]; if(c)goto w;goto z;w:                                               /**/
/**/o=s;s=( 6000 /( sqrt ( (px-(A))*(px-(A))+ (py- Y)*                        /**/
/**/(py-Y))*cos(D T)));for(y=M-(s);y<M+(s);y++){C 1 )E 255;C                  /**/
/**/2 )E  0xFE0;C 16 )E 0xFF00;C 24 )E 255<<16;}} h = t-180; TX  P t = ML;    /**/
/**/px =  strlen(st); n = 130661; N memset(V,0,W*H*4);py=0;mx=((t-ML)/4)+W;   /**/
/**/for(i=0;i<px-2;i++){l = st[i]-97;if(l!=-2)for(y=0;y<15;y++){LAM,S 128)>>7 /**/
/**/JY LAM +10,S 64)>>6 JY LAM +20,S 32)>>5 JY LAM +30,S 16)>>4 JY LAM+40,S 8)/**/
/**/>>3 JY LAM +50,S 4)>>2 JY LAM +60,S 2)>>1 JY LAM +70,S 1) JY}             /**/
/**/py+=80;}if(mx<-19700)break;P return 1;}                                   /**/
/********************************************************************************/	    

