History of video game in 4k
(c) 2004 Lamoureux Jean-Yves
jylam@lnxscene.org
http://4k.frob.nl/2004/

A brief recapitulative history of video game, from 70's to 90's, in less than 4k of ANSI C.
Successfully compiled under GCC 2.95, 3.2.3 (-ansi flag), and Microsoft Visual C++ 6.
Successfully ran under Linux/X11 (2.6.5) and Windows 2000.
Uses SDL and 2d only effects. OpenGL sucks for size compo. Oldschool rocks.


Compile tricks :
This program won't compile under certain cunditions. As its filename is quite big, under some systems, you MUST copy it on a directory with a size under 256 bytes (under windows. For example, under Windows, it compiles perfectly when source file is on C:\. But it won't under Desktop, or will crash before main will be called (argv[] seems too short ;).


List of effects:
1 - Title, using bitmapped font, 6 screens
2 - Pong lookalike with real bouncing ball
3 - Vroom road engine, with sky and ground
4 - Raycaster with rotating camera
5 - Scroller, using bitmapped font

Every single effect contains a text description and is time aware, and .so it won't run too speedy on today's computers. But Pong though, but who cares, anyway ? :)


Weird stuff :
The most notables things on this compo are :
1 - A complete bitmap font included. It is b&w, 1 bit per pixel so. It features all 26 chars. (actually, I lyied, I removed 'z')
2 - A real raycaster with it's map, very slow for size purposes, but complete, with colored walls, sky, and ground.
3 - And the weirdest thing, the scroller string is NOT contained in the source file. It IS the source file name. That can be a problem under VC++, has it fills __FILE__ with complete file path. Compile it under C:\ and it won't be a problem.


No sound this time, better for your ears :)


