#include "g.h"

int
main (int c, char **a) 
{
  SDL_Event e;

  SDL_Init(32);
  SDL_SetVideoMode(640,480,32,2);

  while (!SDL_PollEvent (&e) || e.type!=2)
    {
      glClear (65<<8);

      glColor3d (1,0.5,0);
      glRectf (-1,-1,1,1);

      SDL_GL_SwapBuffers ();
    }
}
