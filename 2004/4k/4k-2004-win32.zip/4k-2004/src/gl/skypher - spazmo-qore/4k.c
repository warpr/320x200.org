                                                     #include "g.h"
                                            #define f           float
                                         f P=3.1415,X=            500,Y=400, o;
                                                    #define e glEnd
                                                  #define g glVertex3d
                                                    #define n glEnable
                                                    #define N glNormal3d
                                                        #define fl for(
                                                #define i int
                            c(f h) { f j; glBegin(6);          N(0,0,-1);g(0,0,0);
       fl j=0;j<=9;j++)g(cos(j*.7)*.1,sin(j*.7)*.1,0);               e();glBegin(6);N(0,0,1);
    g(0,0,h);fl j=9;j>=0;j--)                                             g(cos(j*.7)*.1,sin(j*.7)*.1,h);
        e();glBegin(8);                                                                  fl j=0;j<=9;j++){
          f a=cos(j*.7), b=sin(j*.7);                                             N(a,b,0);g(a*.1,b*.1,0);
           g(a*.1, b*.1, h);}                                                    e();}C(){f j;o/=10000;
            fl j=0;j<=628;j++)                                                  {f x=sin(j),y=cos(j);
             glRotatef(-o-.5,-o,-o+.01,.3);                                    glColor4f(y,x,x,.5);
                glTranslatef(x,y,x);                                        c(x);}}typedef struct
                  { Uint8   *d;                                                   Uint32 l;}snd;
                    typedef struct                                               {  Sint16 *d;
                         i l, p, lv, rv;}voyc;voyc voz[1];snd snds[1];i step=0;i hm[100][100];
                            sp(i vc, i sd, f lv, f rv){voz[vc].l=sd[snds].l/2;voz[vc].p=0;
	                            vc[voz].lv=lv*256;voz[vc].rv=rv*256;vc[voz].d=snds[sd].d;


                                    }char *dp="|...*...*...*...|...*...*...*...";
                                            f rs(f sf, f sp, f *ut, i l)



                                                        { f ph;
                                               i j;fl j=0,    ph=sp;j<l;j++)
                                       {ut[j]=sin(ph);               ph+=2*P;}
                                return ph;}s(void *d,                  char *t, i l){
                            i vi, j;Sint16 *buf=                        (Sint16 *)t;l/=4;if(
                         step[dp]=='|')sp(0, 0,                           .8, .8);if(dp[step]==
                        '*')sp(0, 0, .3, .3);                               rs(800, sin(o), buf, l);
	                fl vi=0;vi<2;++vi){voyc *v                                =&voz[vi];if(!v->d)continue;
                        fl j=0;j<l;j++){                                        if(v->p>=v->l){v->d=
                          NULL;break;}buf[j*2]                              +=v->d[v->p]*v->lv>>8;
			               buf[j*2+1]+=                                     v->d[v->p]*v->rv>>8;
                              ++v->p;}}                                     step=(step+1)%32;}
                                ihm(){                                      i j, k;fl j=0;j<99;
                                  j++){fl k=0;                             k<99;k++){
                                   hm[j][k]=                        sin(j*k*o)*100;}
                                     }}i main(i z, char **v){SDL_Event v;SDL_Init(48);
                                       SDL_SetVideoMode(X,Y,32,2);SDL_AudioSpec c;
                                             c.freq=22050;c.format=32784;





                                        /* -> SPAZMO-QORE -> PERPLEXITY -> 2004 -> */
                                        c.channels= 2; c.samples =4096; c.callback=s;
                                        i j,k;snds[0].d=malloc(sizeof(Uint8*)*10000);
                                        snds[0].l=10000; fl j=0;j<10000;j++) snds[0].
                                        d[j ]=rand()% 256;n(3042);glHint(3152, 4354);
                                        glDepthFunc ( 515 ) ; glBlendFunc( 770, 1 ) ;
                                        glPolygonMode(1032, 6914);f d[]={1, 1, 1, 0},
                                        s[]={100};glShadeModel( 7424 ); glMaterialfv(
                                        1032, 4610, d ); glMaterialfv(1032, 5633, s);
	                                    glColorMaterial(1032,5634);n(2903);glLightfv(
                                        16384,4611,d);n(2896);n(16384);SDL_OpenAudio(
                  &c, NULL);SDL_PauseAudio(0);ihm();while(!SDL_PollEvent(&v) || v.type!=2){o=SDL_GetTicks();
                    glClear(65<<8); glMatrixMode(5889); glLoadIdentity() ;gluPerspective(65, X/Y, 1, 100);
                      glMatrixMode(5888);glLoadIdentity();gluLookAt(0, 0, 10, 0, 0,0, 0, 1,0);if(o<45000)
                        {glRotatef ( o / 100, 0, .1, 1);glTranslatef(0, 0, 7);C();}else {glPolygonMode(
                          GL_FRONT_AND_BACK, GL_FILL);glShadeModel(GL_SMOOTH); o/=300;glTranslatef( 0,
                            -5, -8);glScalef(.2, .2, .2);glRotatef(o, -1, 1, 0);glTranslatef( -50,
                               -50, 0);if(dp[step]=='|')ihm();fl j=0;j<99;j++)fl k=0; k<99;k++)
		                          {glBegin( GL_QUADS); glColor4f((f)j/99, (f)k/45, 0.5, 0.1);
                                     g((f)k, (f)j, hm[j][k]/256.0f*100-50); g((f)k+1,(f)j,
                                        hm[j][k+1] / 256.0f*100-50); g((f)k+1, (f)j +1,
                                          hm[j+1][k+1]/256.0f*100-50);g((f)k,(f)j+1,
                                              hm[j+1][k]/256.0f*100-50);e();} }
                                                    SDL_GL_SwapBuffers () ;}
                                                          SDL_Quit();
                                                            }/****
                                                              **/


   /********
   not enuff
   ideas  so
   ill leave
   it @ 2674
   b y t e s
   ********/

