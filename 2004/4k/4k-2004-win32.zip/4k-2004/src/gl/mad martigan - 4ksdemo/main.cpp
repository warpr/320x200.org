#include "g.h"

#define H );
#define W if(

#define Q {SDL_Quit( H exit(0 H }
#define F float
#define U GLubyte
#define I int

#define Fo(x,y) for(x=0;x<y;x++){

#define Ti glTexParameteri( 
#define Li glLightfv( 
#define E glEnable( 
#define D glDisable(
#define GT glGenTextures(
#define BT(x) glBindTexture(3553,x H 
#define LI glLoadIdentity( H  
#define MM glMatrixMode(
#define V glViewport(
#define TC glTexCoord2f(
#define V2 glVertex2f(
#define VF glVertex3fv(
#define Pu glPushMatrix( H 
#define Po glPopMatrix( H 
#define Pl glPolygonMode(
#define G gluLookAt(
#define PI 3.14


F g[33][33][3],A1,P,AL=0.5,A2;
U C[64][64][3];
U C2[64][64][3];
I h=4,sj,sm;
GLuint i1,i2,i3,cur,b;
GLUquadricObj *q;

void M(void *_, U *st, I l)
{
   sj++;sm++;
    W sm&8)
	   while(l--)
	   {
		    W sm%1 || sm%2)
		   {
				st[l]=l%3;
				 W sj>50) st[l]-=sin(40*l H
				 W sj>100) sj=0;
		   }
		   else
		   {
			   st[l]=(h<=2)?50:2.5*l;
				 W sj>50) st[l]-=sin(4*l H
				 W sj>100) sj=0;
		   }
		    W sm&20) st[l]-=(rand()%10)*sin(l H
		    W sm&16)  W sj&45) st[l]=rand()%128;
	}	
}

void Z()
{
	F m[]={0.4,0.2,0.8,1};
	 W h<2)
		m[2]=0;

	D 3553 H
	LI
	G 0,5,50,0,0,0,0,1,0 H

	glTranslated(5*cos(A2/50),10*sin(A2/50),-50+10*sin(A2/100) H
	glRotated(A2/2,1,0,0 H
	glRotated(A2/3,0,1,0 H

    glMaterialfv(1032,5634,m H
	
	Pl 1032,6913 H
	W h<2)
	gluPartialDisk(q,5,10,32,32,0,sm%360);
	else
		gluSphere(q,10,5,5 H
	Pl 1032,6914 H      
	E 3553 H
	
	Po
}

I main(I _,char** __)
{
	I i,j,k;
	F d1,d2,d3,c1,c2,c3,x,y,z,u,v,w;
    SDL_Event e;
    SDL_AudioSpec des={22500,32784,1,0,512};

	SDL_Init(48 H
	srand(0 H

    des.callback = M;

    SDL_OpenAudio(&des,0 H

    SDL_PauseAudio(0 H
	
	SDL_SetVideoMode(640,480,32,2 H

	F GA[]={0.2,0.2,0.2,1};
	F LP[]={0,5,10,1};
	F LA[]={0.2,0.2,0.2,1};
	F LD[]={0.3,0.3,0.3,1};
	
	glLightModelfv(2899,GA H	
	Li 16384,4611,LP H
	Li 16384,4608,LA H
	Li 16384,4609,LD H
	E 2896 H
	E 16384 H

	glMateriali(1028,5633,128 H

	glLineWidth(5 H
#define EG(z,b,f,l) z[i][j][0]=b;z[i][j][1]=f;z[i][j][2]=l;

	Fo(i,64)
		Fo(j,64)
			k = ((((i&0x8)==0)^((j&0x8))==0))*255;
			EG(C,(U)k,(U)k,(U)k)

			x=i-32;
			y=32-j;
			x/=32;
			y/=32;
			k = (I)((1-x*x-y*y)*100 H
			
			EG(C2,(i%3)?1:3*(U)k/5,rand()%255,(j%5)?1:5*(U)k/5)
		}
	}

	F tt[] = {1,1,1,1,0,1,0,0,0,1,0,1,1,1,0,0,
			  1,1,1,1,0,1,0,0,0,1,0,1,0,1,1,0,
			  1,1,0,0,0,1,1,0,0,1,0,1,0,1,1,0,
			  1,1,1,0,0,1,1,1,0,1,0,1,0,1,1,0,
			  1,1,1,0,0,1,0,1,1,1,0,1,0,1,1,0,
			  1,1,0,0,0,1,0,0,1,1,0,1,0,1,1,0,
			  1,1,1,1,0,1,0,0,0,1,0,1,0,1,1,0,
			  1,1,1,1,0,1,0,0,0,1,0,1,1,1,0,0
	};

	#define R(z) GT 1,&z H BT(z)Ti 3553,10241,9728 H
	#define T gluBuild2DMipmaps(3553,
	#define TT 3,64,64,6407,5121,
	R(b)
	T TT malloc(262144) H
	R(i1)
	T TT C H
	R(i2)
	T TT C2 H
	R(i3)
	T 1,16,8,6409,5126,tt H

	E 3553 H

	q=gluNewQuadric( H

	V 0,0,640,480 H
    MM 5889 H
    LI
    gluPerspective(45,1.3,0.1,1000 H
    MM 5888 H
    LI

	cur=i1;
	while(1)
	{
	    while (SDL_PollEvent(&e))
		{
			 W e.type==2)
				 W e.key.keysym.sym==27)
				{ W h<=1) Q	h--;}
			 W e.type == 12) Q
		}
#define K glClear(16640 H
		K

		V 0,0,128,128 H
		LI						
		G d1,d2,d3,c1,c2,c3,0,1,0 H
		Z( H
		BT(b)
		glCopyTexImage2D(3553,0,6409,0,0,128,128,0 H

		K
		V 0,0,640,480 H
		LI

		Fo(i,33)
			Fo(j,33)
				EG(g,F(3-j/12.0)*F(cos(2*PI/32*i)+2*sin((A1+2*j)/29)+cos((A1+2*j)/13)-2*sin(A1/29)-cos(A1/13)),
					F(3-j/12.0)*F(sin(2*PI/32*i)+2*cos((A1+2*j)/33)+sin((A1+2*j)/17)-2*cos(A1/33)-sin(A1/17)),
					F(-j))
			} 
		}

#define ia g[0][11]
#define ib g[15][11]
		x=ia[0];
		y=ia[1];
		z=ia[2];
		
		u=ib[0];
		v=ib[1];
		w=ib[2];
		
		c1=(x+u)/2;
		c2=(y+v)/2;
		c3=(z+w)/2;

#define ic g[0][3]
#define id g[15][3]
		x=ic[0];
		y=ic[1];
		z=ic[2];
		
		u=id[0];
		v=id[1];
		w=id[2];
		
		d1=(x+u)/2;
		d2=(y+v)/2;
		d3=(z+w)/2;
	
		G d1,d2,d3,c1,c2,c3,0,1,0 H
	
		 W h>=2)
		{
			BT(cur)
			D 2896 H
			glBegin(7 H
			Fo(k,33)
				Fo(j,33)
					i=32-k;
					F al=AL+k/33.0;
					glColor3d(al,al,al H
					TC i/(F)33,j/(F)33 H VF g[j][i] H 
					TC (i+1)/(F)33,j/(F)33 H VF g[j][i+1] H 
					TC (i+1)/(F)33,(j+1)/(F)33 H VF g[(j+1)%33][i+1] H 
					TC i/(F)33,(j+1)/(F)33 H VF g[(j+1)%33][i] H 
				}
			}
			glEnd( H 
			E 2896 H 
		}

		Z( H 

		glBlendFunc(770,1 H 
		E 3042 H 
		BT(b)

		MM 5889 H 
		Pu
		LI
		glOrtho(0,640,480,0,-1,1 H 
		MM 5888 H 
		Pu
		LI

		F s=0;
		F A3=0.2;

		MM 5890 H 
		Pu
		LI
		MM 5888 H 

		glBegin(7 H 
		Fo(i,25)
			glColor4d(1,1,1,A3 H 
			TC s,1-s H 
			V2 0,0 H 
			TC s,s H 
			V2 0,480 H 	
			TC 1-s,s H 
			V2 640,480 H 
			TC 1-s,1-s H 
			V2 640,0 H 
			s+=0.02;
			A3-=0.008;
		}
		glEnd( H 

		MM 5890 H 
		Po

		 W h<2)
		{
			D 2896 H 
			BT(i3)
			glBegin(7 H 
				glColor4d(0,1,1,0.75 H 
				TC 0,0 H V2 0,0 H 
				TC 0,1 H V2 0,480 H 
				TC 1,1 H V2 640,480 H 
				TC 1,0 H V2 640,0 H 
			glEnd( H 

			E 2896 H 
		}

		D 3042 H 

		MM 5888 H 
		MM 5889 H 
		Po
		MM 5888 H 
		Po


		P+=0.05;
		A1=13*sin(P H + 13*cos(2*P + PI/6 H
		A2+=10;

		 W h==2)
		{
			 W des.freq<44100)
			{
				des.freq=44100;
				SDL_CloseAudio( H 
				SDL_OpenAudio(&des,0 H 
				SDL_PauseAudio(0 H 
			}
			 W AL<1) AL+=0.05;
		}
		 W h==3)
		{
			AL-=0.05;
			 W AL<(-0.5))
			{
				cur=i2;
				h--;
			}
		}
		MM 5890 H 
		glTranslated(0.02,0,0 H 
		MM 5888 H 
		SDL_GL_SwapBuffers(  H 
	}
    Q
    return 0;
}

