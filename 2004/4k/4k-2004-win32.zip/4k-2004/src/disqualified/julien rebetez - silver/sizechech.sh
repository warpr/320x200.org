cat ogl_4k.c | perl -pe 's/\s//g' | wc -c
