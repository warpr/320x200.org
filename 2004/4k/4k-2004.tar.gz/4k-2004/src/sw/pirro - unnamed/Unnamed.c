#include                                                                  "s.h"
                                                                               
                                                                               
#define                              J   ){                                    
#define                              g   if                                    
#define                              u   128                                   
#define                              R   255                                   
#define                              O   abs                                   
#define                              L   cos                                   
#define                              z   int                                   
#define                              N   sin                                   
#define                              I   100.                                  
#define                              W   1500                                  
#define                              C   for(                                  
#define                              Q   }else                                 
#define                              M   float                                 
#define                              S   10000                                 
#define                              B   Uint8                                 
#define                             aa   double                                
#define                              F   format                                
#define                              U   Uint32                                
#define                             ad   ->pixels                              
#define                              V   SDL_MapRGB                            
#define                              q   3.1415926535                          
#define                             ac   SDL_FillRect                          
#define                             ae   SDL_GetTicks                          
#define                             af   SDL_BlitSurface                       
                                                                               
                                                                               
#define                             ak   2.*q                                  
#define                             ah   ag(mx)+ag(my)                         
#define                          _F(c)   220*pow(2,(c-64)/12.)*ak/22050        
#define                          ag(c)   (O(j-c))%u                            
#define                        Mm(b,c)   ((b)>(c)?c:b)                         
#define                        MM(b,c)   ((b)>(c)?b:c)                         
#define                        MN(b,c)   -Mm(-b,-c)                            
#define                      _T(a,b,c) C i=0;i++<S;) t##c##a[i]=a(i*ak/(M)(b));
                                                                               
                                                                               
aa fx[5]={10.,15.,20.,25.,30.},fy[5]={5.,10.,15.,20.,25.};z cl[5]={R<<16,R<<8,R
<<4,(R<<16)+(R<<8),(R<<16)+(R<<4)};char *sn="FFFFFF AAAAAAAAA FFF F H J K MMMM"
"MMMMMMMM M MMM MMM N P RRR N N NNN I I II RR RR RR PP NN PPPP N MMMMMMMMMMM I"
"II MMM KKK K M NNNNNNNNNNN MMM KKK III I K MMMMMMMMMMM KKK III HHHHHHHHHH J L"
"LLLLLLLLLL OOOOOO MMMM A AAA A A AAA A A AAA AAA FFFFFF AAAAAAAAA FFF F H J K"
" MMMMMMMMMMMM M MMM MMM N P RRR N N NNN I I II RR RR RR PP NN PPPP N MMMMMMMM"
"MMM III MMM KKK K M NNNNNNNNNNN MMM KKK III I K MMMMMMMMMMM KKK III HHHHHHHHH"
" HHH MMMMMM QQQQQQ RRRRRRRRRRRRRRRRR                                         "
"                                                                             "
"                                                                             "
"                                 Unnamed 2k4                                ";
                                                                               
                                                                               
z po,t2=0,ref=3000;U t1=0;void cb(void   *us,B *s,z l J M v,f2,f;char a,b;C;l>0
;l-=2 J a=sn[po];b=sn[(po+1)%661];f=_F   (sn[po]);g(a!=' ')v=N(f*t1);g(t2>(W-W/
8.) J f2=1-(t2-(W-W/8.))/(W/8.);v*=f2;   g(b!=' ')v+=(1-f2)*N(_F(b)*t1);}g(t1%W
==0 J t2=0;po++;po%=661;}*(Sint16*)s=(   Sint16)32000*v;s+=2;t1++;t2++;}}SDL_S\
urface* G;void ab(aa x,aa y,aa a,z n J   aa b;z i;SDL_Rect r;a=a/2;b=-a*sqrt(3.
);g(n>0 J C i=0;i<(z)a;i++ J r.x=(z)x+   i/2;r.y=(z)y+i;r. w=(z)a-i;r.h=1;ac(G,
&r,V(G->F,(B)x,(B)y,(B)(x+y)));}n=n-1;   ab(x,y,a,n);ab(x+a,y,a,n);ab(x+a/2,y+b
/2,a,n);}}z main(z c,char **a J z x,y,   p,w=400,h=300,t,fp,H, i,k,ms,di,c7,c8,
c9;B re,gr,bl,D,E,ny;U mx,my,j,*v,*d;M   X,Y,Z,o,s,K,c4,c5,c6;aa A=0.,P=0.;SDL\
_Surface *b;SDL_Event e;SDL_Rect m,r2;   SDL_AudioSpec T;T.freq=22050;T.F=AUDI\
O_S16LSB; T.channels=1;T.samples=8192;   T.callback=&cb;SDL_OpenAudio(&T,NULL);
SDL_PauseAudio ( 0); SDL_Init( 32); b=   SDL_SetVideoMode(w,h,32,0);G=SDL_Crea\
teRGBSurface(0,R+1,R+1,32,b->F->Rmask,   b->F->Gmask,b->F->Bmask,b->F->Amask);p
=b->pitch/4;t=fp=k=c9=0;j=H=1;A=P=0.;Z   =1.;M t0sin[S];M t0cos[S];M t1sin[S];M
t1cos[S];_T(sin,h,0)_T(cos,h,0)_T(sin,   w,1)_T(cos,w,1)ms=ae();ab(0,u,u,9);m.x
=m.y=r2.y=0; m.h=m.w=r2.x=r2.h=r2.w=u;   af(G,&m,G,&r2);m.x=64;r2.x=0;r2.y=u;af
(G,&m,G,&r2);m.x=m.y=u;af(G,&r2,G,&m);   while(! SDL_PollEvent(&e)||e.type!=2 J
t++;fp++;g(!c9&&k>4 J k=0;c9=j=1;H=5;A   =0.;Z=1.;Q g(k>1 J P+=.17;o=I*L(P/fy[2
]*ak);s=160.*L(P/fx[2]*ak);ac(b,NULL,0   );g(k==4){c7=MN(50+o,0)+1;c8=MN(100-s,
0)+1;Q{c7=MM(50+o,0)+1;c8=MM(100-s,0)+   1;} v=((U*)b ad)+c8+c7*p; C y=c7;y<Mm(
                                                                               

250+o,h );y++ J K=t0cos[ 3*(t+y)] ;c4=   t0sin[2*(y+t)];c5=pow(y-150-o,2);d=v;C
x=c8;x<Mm(300-s,w);x++ J g(k==2 J D=u+   u*(t1sin[w/2+(x+3*t)%(w/2)]+K+t1cos[w/
2+((x+t)*3)%(w/2)]+c4);Q{D=u+u*(t1sin[   x+3*t]+K+t1cos[3*(x+t)]+c4);}j=V(b->F,
(B)(t+D),D,D);g(k==4 J mx=j-*(v-1);my=   *(v-p)-j;Q{SDL_GetRGB(*(v-1),b->F,&re,
&gr,&bl);E=D-bl;SDL_GetRGB(*(v-p),b->F   ,&re,&gr,&bl); ny=bl-D;}c6=sqrt(pow(x-
200+s,2)+c5);g(k==3 J D=I-Mm(c6,100);g   (c6>90 J j=0;Q{j=V(b->F,(B)(O(D*-E)+O(
D-ny)),(B)(O(D-E)+O(D-ny)),50);} Q g(k   ==4 J j=I-Mm(0,100); j=V(b->F,ah,ah,ah
);Q{g(c6>80)j=0;}*v=j;v++;}v=d+p;}g(t%   500==0 J k++;t=0;j=H=1;A=0.;Z=1.;}Q g(
k>0 J A+=Z*.1;g(A>0 J o=A*L(t*q/20.);s   =A*N(t*q/20.);Q o=s=0;g(A>5||A<-1)Z=-Z
;v=(U*)b ad;K=(125-t/9)*s-(175+t/9)*o;   c4=(t/9-125)*o-(175+t/9)*s;C y=0;y<h;y
++ J C x=0;x<w;x++ J E=(B)K;ny=(B)c4;j   =*((U*)(G ad)+E+ny*G->pitch/4);g(!j){E
=(B)(2*((B)(3*t)-y*x));g(E<u)E=R-E;j=V   (b->F,(B)E,(B)E,(B)E);}* v=j;v++;K+=o;
c4+=s;}K-=(w*o+s);c4-=(w*s-o);}g(t%500   ==0 J k++;t=0;j=H=1;A=P=0.;Z=1.;}Q{A+=
.06;P+=.04;s=L(A); K=N(A);v=b ad;c7=u+   127*N(t*ak/1200.);gr=3*t;C y=0;y<h;y++
J re=3*t; C x=0;x<w;x++ J *v=V(b->F,re   ++,gr,c7);v++;}gr++;}C i=0;i<H;i++ J o
=(10+10*L(A+i*q/H));c4=L((P)/fx[i]*ak)   ;c5=L((P)/fy[i]*ak);C x=8;x-->0; J C y
=0;y++<16;J X=o*L(y/16.*ak)*N(x/16.*ak   );Y=o*N(y/16.*ak)*N(x/16.*ak);Z=o*L(x/
16.*ak) ;X=X*s-Z*K;Z=X *K+Z*s ;m.x=(((   150.*X )/(150-Z)*3)+200.)-160.*c4-3;m.
y=((200.*Y)/(200-Z)*3)+150.+I*c5-3;m.w   =m.h=16;ac(b,&m,0);m.x+=3;m.y+=3;m.w=m
.h=10;ac(b,&m,cl[i]);}}}g(t%200==0 J H   ++;g(c9)g(++c9==6 J break;Q H--;g(H==6
&&!c9 J H--;k++;t=0;j=H=1;A=P=0.;Z=1.;   }}}SDL_Flip(b);di=fp*30-(ae()-ms);g(di
>0)  SDL_Delay(di)  ;}   SDL_Quit() ;}                                         
                                                                               
                                                                               
               
