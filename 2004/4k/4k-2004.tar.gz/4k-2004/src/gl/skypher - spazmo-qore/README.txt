                       SPAZMO-QORE
               - --------------------------->
                <--------------------------   -
       After three years of blood, sweat and tremendous amount
       of coding. It is here. Finally.
       The much awaited SPAZMO-QORE 4k src intro. Wow.
       The title of the intro is a tribute to the new
       genre of music that it features as soundtrack.

                code: skypher / perplexity
                music: roobik / spazmo-qore society
                design: wiz-key / krayon

    --------------------- - -   -  -  ----->
                    <-------------------------- -   -

