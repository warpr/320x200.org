.___   |\_              |\_  __
|  _|__|  | _____  _____|  |/ /  _____  ______
|  \\_ \  |/  _  \| .-;_|  ' /__/  _  \|    __)
|   \/     `  \     `   |  |   /   \   '--, ` |
\_____________________________________________|
 2004       w o r l d       d o m i n a t i o n

make for building
./cube for running
any key for quiting
openGL for showing
silence for dancing
MooZ for the making
