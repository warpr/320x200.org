
                              /* "Shadow Sun" */
                         /* tonic - http://jet.ro */
                      #include                     "g.h"
                    #define    S1(a,b,c) #a".."#b".."#c"."
                   #define   X2(a)                      a a
                  #define   X4(a)                    a a a a
                  #define  S14(a,b,c)           X4(S1(a,b,c))
                  #define  S2(a)               #a"."#a"....."
                  #define S24(a)             X4  ( S2 ( a ) )
                  #define S4(a)             #a   #a   #a   #a
                   #define S3(a,b,        c) S1(a,b,c)S4(..)
                    #define SE         X4(  X4(  S4  (..)))
                      #define P(x)    glDisable(GL_##x);
                        #define EF_(x) F[C][1638##x+M
                             #define B     float

         char l[]=SE SE X2(S3(J,H,M)S3(J,H,E)S3(F,E,A)S3(F,E,J)S3(H,E
     ,O)S3( H,E,C)S3 (H,F,x) S3(H,F,L)) ;char b[] = SE X2(S4(j.jv.j.v)S4
   (f.fr.f.r)S4(e.eq.e.q)S4(h.ht.h.t))SE;char*r [3] ={S14(v,v,q)S14(r,r,m)
  S14(q,q,l)S14(t,t,o),S24(J)S24(F)S24(E)S24(H),S24(M)S24(J)S24(H)S24(L) };
  Uint32 S;GLUquadric*Q;int D,R,U,L,p=0;B T,F[5][0100000]={{0},{0}};void G(
   void*u,Uint8*_,int L){while(L>0){int M=p&037777,s=p>>12,H=(s%R)[l],J=(s
     #define EF(C,l,s,ms)    ((s*ms+EF_(4)-l]*(1-ms))*0.5f+EF_(3)]*0.5f)
         %U)[b],C=0,a=0,n;B      v,q,m,E=(0x2000-(p&017777))/8192e0f;
                #define FQ(s) (B)sin((0.12*pow(2,n/12.0))*p*s)
                     #define IZ(v,c) if(v c)v*=v;else v=0;
                  #define BF F[C][M]=F[C][M+16384]=q;v+=q;++C
            #define IP(n,x,y,z,c) if(n!='.'){x}q=EF(C,y,q,z);c;BF;
                  #define IS(s,c)   if(q c s 0.75f)q=s 0.75f;
             #define NQ(N,a,m) n=N-(N>='a'?'a'+24:'A')+a;q=FQ(m);
                    v=q=0;IP(H,NQ(H,12,1)m=FQ(1.01f);IZ(q,>
                      0.6)IZ(m,>0.6)q+=m;q*=E*0.5f+0.5f;,
                        12288,0.2f,;)for(;a<3;++a){char
                         sn=(s%D)[a[r]];q=0;IP (sn,NQ(
                         sn,12,0.25f)IZ(q,<0.3),12288,
                        0.2f,;)}q=0;IP(J,NQ(J,0,0.125f)
                         X4(q*=q;)q=(B)fmod(q*20,4)*4;
                         ,6144,0.25f,IS(-,<)IS(+,>)q*=
                         E)v*=0.6f;*(Sint16*)_=(Sint16
                          )(v*32767);_+=2;++p;L-=2;}}
                         #define N(x) glEnable(GL_##x);
                           void I(int a){B b[]={a?0.f
                           :1,a?0:4.f,-2.f,0},c[]={0,
                            -2,0,0},d[]={.2f,0.f,0.f
                           ,1},e[]={a?.5f:.8f,a?.75f
                              :.3f,a?1:.2f,1},f[]={
                              0,.2f,.3f,1},g[]={0,
                             0,0,1,1,1,1},*h=&g[3];
              #define GF(l,x,v) glLightfv(GL_LIGHT##l,GL_##x,v);
  GF(0,POSITION,b)GF(0,AMBIENT,d)GF(0,DIFFUSE,e)GF(0,SPECULAR,h)if(a)P(LIGHT1
 )else N(LIGHT1)GF(1,POSITION,c)GF(1,AMBIENT,f)GF(1,DIFFUSE,f)GF(1,SPECULAR,g)
              #define GM(t,x,v) glMaterial##t(GL_FRONT,GL_##x,v);
             GM(fv,AMBIENT,g)GM(fv,DIFFUSE,h)GM(fv,SPECULAR,h)GM(
             fv,EMISSION,g) GM (f,SHININESS,60) glColorMaterial (
             GL_FRONT,GL_DIFFUSE);N(COLOR_MATERIAL)}void K(int b,
            B c,int d){ int a; B  e=c*c,g=1e0f/e;glColor3f(1,1,1);
          #define BC(v,f,p,q) B v=(B)f(ta*(sin(T*p*g)*5e-2+q*c)*g)*c
          for(a=0;a<b;++a){B ta=T*1e-4f+a*c;BC(x,cos,2.3e-4,0.0867);
          BC(y,sin,2e-4,0.2735);BC(z,cos,1.5e-4,0.1243);glPushMatrix
          ();glTranslatef(x,y,z); glRotatef(50,1,0,0); glRotatef (T*
          5e-2f+a*20,0,1,0); glCallList(d);glPopMatrix();}}int main(
           int c,char **a) { SDL_Event e; SDL_AudioSpec as, oa;if (
           SDL_Init(48)<0)exit(1);atexit(SDL_Quit);SDL_SetVideoMode
              (640,480,32,2);as.freq=053042;as.format=AUDIO_S16;
                as.channels=1;as.samples=4096;as.callback=G;D=
                   strlen(r[0]);R=strlen(l);U=strlen(b);if(
                      SDL_OpenAudio(&as,&oa) <0)exit(2);
                              SDL_PauseAudio(0);
                              Q=gluNewQuadric();
                               L=glGenLists(2);
                  #define NL_ GL_COMPILE);gluSphere(Q,0.1,40
            #define NL(a,d) glNewList(L+a,NL_/d,20/d);glEndList();
                NL(0,1)NL(1,5)N(LIGHTING)N(LIGHT0)N(CULL_FACE)
                 glShadeModel(GL_SMOOTH);N(BLEND)glBlendFunc(
                  GL_ONE,GL_ONE);S=SDL_GetTicks();T=0;while(
                    !SDL_PollEvent(&e)||((e.type!=2||e.key.
                     keysym.sym!=27)&&e.type!=12)){B d,f;
                     Uint32 g;f=T;g=SDL_GetTicks()-S;T=T*
                     0.75f+g*2.5e-1f;glClearColor(0,0,0,1
                     );glClear(16640);glViewport(0,0,640,
                       480);glMatrixMode(GL_PROJECTION);
                       glLoadIdentity();gluPerspective(
                        45,4./3,0.5,100);glMatrixMode(
                        GL_MODELVIEW);glLoadIdentity()
                         ;d=T*1e-4f;gluLookAt(cos(d)*
                          3,0,sin(d)*3,0, 0, 0, 0,1,
                          0);I(0); K(0144, 1, L); P(
                          COLOR_MATERIAL)I(1);K(100+
                           0144+0x64+0620+0454,15,L
                            +1);P(COLOR_MATERIAL)
                            SDL_GL_SwapBuffers();
                            /* $Revision: 1.1 $*/
                              SDL_Delay(~0&1);}
                               SDL_CloseAudio
                               (); return 0;}
