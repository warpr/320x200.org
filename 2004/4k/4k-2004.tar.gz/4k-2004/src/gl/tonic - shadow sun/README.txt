
Shadow Sun
tonic's entry to 2nd #demoscene 4k source compo
(May 2004)

Once again I noticed just a bit before that the deadline is there.
This time I started with the sound stuff and then progressed to
get some stuff to the screen as well in a hurry, like it always
seem to be.

  -- tonic (of Armada, Grin, sYmptom, ..)
     http://jet.ro
