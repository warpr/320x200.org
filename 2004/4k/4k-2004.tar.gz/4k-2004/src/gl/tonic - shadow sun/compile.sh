#!/bin/sh
gcc -I /usr/include/SDL -lSDL -lGL -lGLU -lm -W -lpthread -O shadowsun.c -o shadowsun
