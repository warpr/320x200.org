#include <time.h>
#include "g.h"

#define h(a) (-(a)*(a)*((a)+5)*((a)-5)/16)
#define P2(a) ((a)*(a))
#define RF(a) (rand()*(a)/RAND_MAX)
#define R(a) (rand()%(a))
#define gc(a,b,c) glColor3d(a,b,c)
#define gcv(a) glColor3dv(a)
#define gv(a,b) glVertex3dv( C[a][b] )
#define ui unsigned int

typedef struct {
	ui x1:3;
        ui y1:3;
        ui z1:3;
        ui x2:3;
        ui y2:3;
        ui z2:3;
        ui x3:3;
        ui y3:3;
        ui z3:3;
        ui c:5;
} py;

int l;

void m( void )
{
	long fl[] = {
		0x26C1F2F8, 0x26C9F3B0, 0x25ADF3B2, 0x2B91F36B,
		0x258365B0, 0x258B6560, 0x25AF6562, 0x1DAEC55C,
		0x1D72C558, 0x1D8AC158, 0x3506B1C0, 0x35078140,
		0x1D72B144, 0x1D12B141, 0x2B92D75C, 0x2B75C95C,
		0x2B76B944, 0x2B15BB44, 0x1B7DC8DD, 0x1B7DBAD7,
		0x1B5DBACE, 0x1B39BAC5, 0x13E5C8A4, 0x1291C8DF,
		0x135D9C8E, 0x13398A85, 0x12399C85, 0x0D128000,
		0x0B168800, 0x0A158A00, 0x08110A00, 0x029000F8,
		0x03E548F8, 0x037D1CA4, 0x035D1CDF, 0x02390AA4,
		0x021408A4, 0x001000A4
	}, i,j,k;
	double x[] = {
		0,2,4,7,8,11,25,59,
		0,11,18,27,58,60,66,100,
		0,2,5,8,11,13,18,27
	},

	c[][3] = { {1,0,1}, {.1,.9,.9}, {1,0,0}, {.3,.3,.3},
		{1,1,1}, {1,0,0}, {1,0,0}
	},
	t[16][16][16][6], *tt;
	py *f = (py*)fl;

	l = glGenLists( 1 );
	glNewList( l, GL_COMPILE );
	glBegin( GL_TRIANGLES );

	for( i = 0 ; i < 16 ; i++ ) for( j = 0 ; j < 16 ; j++ ) for( k = 0 ; k < 16 ; k++ )
	{
		tt = t[i][j][k];
		tt[0] = x[i]/100;
		tt[3] = -x[i]/100;
		tt[4] = tt[1] = x[j+8]/100-.5;
		tt[5] = tt[2] = x[k+16]/100-.07;
	}

	for( i = 0 ; i < 38 ; i++ )
	{
		glColor3dv( c[f[i].c] );

#define gv2(x,y,z,d) glVertex3dv( t[f[i].x][f[i].y][f[i].z]+d );

		gv2(x1,y1,z1,0); gv2(x2,y2,z2,0); gv2(x3,y3,z3,0);
		gv2(x2,y2,z2,3); gv2(x1,y1,z1,3); gv2(x3,y3,z3,3);
	}

	glEnd();
	glEndList();
}

#define LEN 400
#define LEM 399
int main ( int a, char **c )
{
	SDL_Event e;
	double C[LEN][17][3],A[17],F[17],P[17],z=0,Z=z,Y,I,H[150],
	sy[] = { -5, 0, 3, 8, 12, 100 },
	sc[][3] = { {.91,.40,.07}, { .95,.71,.32 }, { .80,.71,.55 },
		{ .2,.44,.76 }, { .07,.23,.54 }, { 0,0,.1 } };
	int i,j,k,p=0,o[2]={0,0};

	srand(time(NULL));

	SDL_Init(32);
	SDL_SetVideoMode(640, 480, 32, 2);
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );

	glCullFace( GL_BACK );
	glEnable( GL_DEPTH_TEST );
        glEnable( GL_NORMALIZE );

	m();

	for( i = 0 ; i < 17 ; i++ )
	{
		A[i] = RF(2.5);
		F[i] = RF(40.0)+10;
		P[i] = RF(6.28);
	}
	
	for( i = 0 ; i < LEN ; i++ ) for( j = 0 ; j < 17 ; j++ )
	{
		C[i][j][0] = j-8;
		for( k = 0 ; k < 17 ; k++ )
			C[i][j][0] += A[k]*sin(P[k]+(i-LEN)/2.0/F[k]);
		C[i][j][1] = i/2.0;
		C[i][j][2] = (j-8)?h(j/2.0-4):0;
	}
	for( i = 0 ; i < 100 ; i++ )
		H[ i ] =  h(-1.5);

	while (!SDL_PollEvent (&e) || !(e.type==2 && e.key.keysym.sym == SDLK_ESCAPE) )
	{
		glClear (65<<8);

		if( p > (o[0] + 100) )
			o[0] = 0;
		if( !o[0] )
		{
			o[0] = p+LEN+50;
			o[1] = R(3);
		}

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glFrustum(-1.0, 1.0, -.75, .75, 5.0, 1000.0);
		glRotated( 90, -1, 0, 0 );
		
		
		glRotated( atan2(C[(p+LEN+1)%LEN][8][0]-C[(p+LEN+0)%LEN][8][0],1)*180/3.14, 0, 0, 1 );
		glRotated( 100*(C[(p+LEN+1)%LEN][8][0]-C[(p+LEN+0)%LEN][8][0]), 0, 1, 0 );
		glTranslated( -C[(p+10)%LEN][8][0], 0, -H[p%50]);

		glMatrixMode(GL_MODELVIEW);

		if( p <= o[0] )
		{
			if( (p+150)==o[0] && (fabs(z - o[1]) < .5) ) {
				while( (Z = R(3)) == o[1] );
				Y = z;
			} else if( p == o[0]) {
				z = Y = Z;
			} else if( (I=(o[0]-p)/150.0) < 1 ){
				z = Y+(Z-Y)*P2(cos( 3.14/2*I));
			}
		}
		
		H[(p+49)%50] = h((5-z)/2.0-4);

		glLoadIdentity();
		glTranslated( C[(p+20)%LEN][8][0], 8, h((5-z)/2.0-4) - .1 );
		glRotated( 5+(Z-z)*10, 1, 0, 0 );
		glRotated( -atan2(C[(p+65)%LEN][8][0]-C[(p+64)%LEN][8][0],1)*180/3.14, 0, 0, 1 );
		glRotated( 300*(C[(p+65)%LEN][8][0]-C[(p+64)%LEN][8][0]), 0, 1, 0 );
		glCallList( l );

		glLoadIdentity();
		glTranslated(0, -p/2.0, 0);

		for( i = 0 ; i < LEM ; i++ )
		{
			glBegin( GL_TRIANGLE_STRIP );
			for( j = 0 ; j < 17 ; j++ )
			{
				gc( 0,exp(-fabs((j-8)*.6)),(i+p)%LEN>10?0:1 );
				gv( (i+p)%LEN, j );
				gv( (i+1+p)%LEN, j );
			}
			glEnd();
		}

		glLoadIdentity();
		glTranslated(0, -p/2.0, 0);

		glBegin( GL_TRIANGLE_STRIP );
		gc( 0,0,1 );
		for( i = 0 ; i < LEM ; i++ )
		{
			gv( (i+p)%LEN, 7 );
			gv( (i+1+p)%LEN, 9 );
		}
		glEnd();

		for( j = 0 ; j < 17 ; j++ )
		{
			C[p%LEN][j][1] += LEN/2.0;
			C[p%LEN][j][0] = j-8;
			for( k = 0 ; k < 17 ; k++ )
				C[p%LEN][j][0] += A[k]*sin(P[k]+p/2.0/F[k]);
		}

		if( (o[0]) && (o[0]-p>0) && ((o[0] - p)< LEN) )
		{
			glBegin( GL_TRIANGLES );
			gc( .3,.3,.3 );
			gv( (o[0]%LEN), 5-o[1] );
			gv( (o[0]%LEN), 6-o[1] );
			gv( (o[0]%LEN), 11+o[1] );
			gv( (o[0]%LEN), 11+o[1] );
			gv( (o[0]%LEN), 10+o[1] );
			gv( (o[0]%LEN), 5-o[1] );
			glEnd();
		}

		p++;

		glLoadIdentity();
		glBegin( GL_QUAD_STRIP );
		for( i = 0 ; i < 6 ; i++ )
		{
			gcv( sc[i] );
			glVertex3d( 100, LEN/2.0, sy[i] ); 
			glVertex3d( -100, LEN/2.0, sy[i] ); 
		}

		glEnd();

		if( p > 10 )
			SDL_GL_SwapBuffers (), SDL_Delay( 4 );
                
	}

	return 0;
}
