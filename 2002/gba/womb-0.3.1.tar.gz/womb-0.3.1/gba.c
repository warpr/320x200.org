/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <linux/config.h>

#ifndef CONFIG_DEVFS_FS
#error please enable devfs in you kernel before using this module
#endif 

#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/vmalloc.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/devfs_fs_kernel.h>
#include <asm/uaccess.h>

#include "gba.h"
#include "dmb.h"
#include "multi.h"

#ifndef SEEK_SET
#define SEEK_SET 0
#endif
#ifndef SEEK_CUR
#define SEEK_CUR 1
#endif
#ifndef SEEK_END
#define SEEK_END 2
#endif

int init_module (void);
void cleanup_module (void);
int gba_open (struct inode *inode, struct file *filp);
int gba_release (struct inode *inode, struct file *filp);
ssize_t gba_read (struct file *filp, char *buff, size_t count, loff_t *offp);
ssize_t gba_write (struct file *filp, const char *buff, size_t count, loff_t *offp);

static int io = 0; /* do not use a default. */
MODULE_PARM (io, "i");
MODULE_PARM_DESC (io, "LPT i/o port (try 0x378)");

static int timeout = 30000;
MODULE_PARM (timeout, "i");
MODULE_PARM_DESC (timeout, "when waiting to receive data, time out after this many tries (default 3000)");

static int attempts = 100;
MODULE_PARM (attempts, "i");
MODULE_PARM_DESC (attempts, "make this many attempts when looking for GBA (default 100)");

MODULE_AUTHOR ("Kuno Woudt <warp-tmt@dds.nl>");
#ifdef MODULE_LICENSE
MODULE_LICENSE ("GPL");
#endif
MODULE_DESCRIPTION ("Gameboy Advance dumb multiboot cable driver");
MODULE_SUPPORTED_DEVICE ("Dumb Multiboot Cable for Gameboy Advance");

typedef struct {
  unsigned char *image;
  int size;
  int pos;
  devfs_handle_t handle;
  struct semaphore sem; 
} gba_dev;

static devfs_handle_t gba_devfs_dir;
static gba_dev gba_device = {
  image: NULL,
  pos: 0,
  size: 0,
  handle: NULL,
};

static struct file_operations gba_fops = {
  read:  gba_read,
  write:  gba_write,
/*   ioctl:  gba_ioctl, */
  open:  gba_open,
  release: gba_release,
  owner: THIS_MODULE,
};

static struct resource * gba_resource;

int
gba_init (void)
{
  int chk;

  if (!io)
    {
      err ("invalid LPT port: 0x%02x", io);
      return -ENXIO;
    }

  if ((chk = check_region(io, GBA_PORT_RANGE)) < 0)
    {
      err ("io port 0x%02x taken", io);
      return chk;
    }

  info (VERSION " init (LPT: 0x%02x).", io);

  gba_resource = request_region(io, GBA_PORT_RANGE, SHORTNAME);

  gba_devfs_dir = devfs_mk_dir (NULL, "gba", NULL);
  if (!gba_devfs_dir) 
    return -EBUSY;

  sema_init(&gba_device.sem, 1);

  devfs_register (gba_devfs_dir, "multiboot",
                  DEVFS_FL_AUTO_DEVNUM | DEVFS_FL_AUTO_OWNER,
                  0, 0, S_IFCHR | S_IRUGO | S_IWUGO,
                  &gba_fops,
                  &gba_device);

  gba_device.image = vmalloc (GBA_MB_MAX_SIZE);
  if (!gba_device.image)
    return -ENOMEM;

  gba_device.size = GBA_MB_MAX_SIZE;

  return 0;
}

void
gba_exit (void)
{
  vfree(gba_device.image);

  devfs_unregister(gba_device.handle);
  devfs_unregister(gba_devfs_dir);

  release_region(io, GBA_PORT_RANGE);

  dbg ("removed.");
}

int 
gba_open (struct inode *inode, struct file *filp)
{
  gba_dev *dev = (gba_dev *)filp->private_data;

  if (down_trylock (&dev->sem))
    return -EBUSY;

  return 0;       /* success */
}

int 
gba_release (struct inode *inode, struct file *filp)
{
  int chk;
  gba_dev *dev = (gba_dev *)filp->private_data;

  info ("preparing to write %d bytes to gba", dev->pos);

  chk = dmb_init (io, timeout, attempts);
  if (chk < 0) goto gba_release_exit;

  chk = dmb_detect_mb ();
  if (chk < 0) goto gba_release_exit;

  chk = multiboot (dev->image, dev->pos);
  if (chk < 0) goto gba_release_exit;

  chk = 0;

 gba_release_exit:
  up(&dev->sem);
  return chk;
}

ssize_t
gba_read (struct file *filp, char *buff, size_t count, loff_t *offp)
{
  gba_dev *dev = (gba_dev *)filp->private_data;
  unsigned char * src = dev->image + *offp;
  ssize_t read_count = count;
  
  if (*offp > dev->pos)
    return -ENODATA;

  if (*offp + read_count > dev->pos)
    read_count = dev->pos - *offp;

  if (copy_to_user(buff, src, read_count))
    return -EFAULT;

  *offp += read_count;

  return read_count; 
}

ssize_t
gba_write (struct file *filp, const char *buff, size_t count, loff_t *offp)
{
  gba_dev *dev = (gba_dev *)filp->private_data;
  unsigned char * dst = dev->image + *offp;
  ssize_t write_count = count;
  
  if (*offp >= dev->size)
    return -ENOSPC;

  if (*offp + write_count > dev->size)
    write_count = dev->size - *offp;

  if (copy_from_user(dst, buff, write_count))
    return -EFAULT;

  *offp += write_count;
  dev->pos = *offp;
  
  return write_count; 
}

module_init(gba_init);
module_exit(gba_exit);
