/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <linux/types.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/system.h>
#include <asm/errno.h>

#include "dmb.h"
#include "multi.h"
#include "gba.h"

unsigned char multiboot_header[GBA_HEADER_SIZE] =
  {
    0x2E, 0x00, 0x00, 0xEA, 0x24, 0xFF, 0xAE, 0x51, 0x69, 0x9A,
    0xA2, 0x21, 0x3D, 0x84, 0x82, 0x0A, 0x84, 0xE4, 0x09, 0xAD,
    0x11, 0x24, 0x8B, 0x98, 0xC0, 0x81, 0x7F, 0x21, 0xA3, 0x52,
    0xBE, 0x19, 0x93, 0x09, 0xCE, 0x20, 0x10, 0x46, 0x4A, 0x4A,
    0xF8, 0x27, 0x31, 0xEC, 0x58, 0xC7, 0xE8, 0x33, 0x82, 0xE3,
    0xCE, 0xBF, 0x85, 0xF4, 0xDF, 0x94, 0xCE, 0x4B, 0x09, 0xC1,
    0x94, 0x56, 0x8A, 0xC0, 0x13, 0x72, 0xA7, 0xFC, 0x9F, 0x84,
    0x4D, 0x73, 0xA3, 0xCA, 0x9A, 0x61, 0x58, 0x97, 0xA3, 0x27,
    0xFC, 0x03, 0x98, 0x76, 0x23, 0x1D, 0xC7, 0x61, 0x03, 0x04,
    0xAE, 0x56, 0xBF, 0x38, 0x84, 0x00, 0x40, 0xA7, 0x0E, 0xFD,
    0xFF, 0x52, 0xFE, 0x03, 0x6F, 0x95, 0x30, 0xF1, 0x97, 0xFB,
    0xC0, 0x85, 0x60, 0xD6, 0x80, 0x25, 0xA9, 0x63, 0xBE, 0x03,
    0x01, 0x4E, 0x38, 0xE2, 0xF9, 0xA2, 0x34, 0xFF, 0xBB, 0x3E,
    0x03, 0x44, 0x78, 0x00, 0x90, 0xCB, 0x88, 0x11, 0x3A, 0x94,
    0x65, 0xC0, 0x7C, 0x63, 0x87, 0xF0, 0x3C, 0xAF, 0xD6, 0x25,
    0xE4, 0x8B, 0x38, 0x0A, 0xAC, 0x72, 0x21, 0xD4, 0xF8, 0x07,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x31, 0x96, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF0,
    0x00, 0x00,
};

/*   ______     ______     _______ ,---.____  er. crc stuff :)
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int
do_crc_stuff (int foo, int bar)
{
  int i;

  for (i = 0; i < 0x20; i++)
    {
      int tmp = foo ^ bar;
      foo >>= 1;
      bar >>= 1;

      if (tmp & 1)
        foo ^= 0xA517;
    }

  return foo;
}

/*   ______     ______     _______ ,---.____  check response after sending some
 ,---\    /---./      \,--//      \|  //_   \ data.
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int
do_checkresponse (int response, int pos)
{
  if (response < 0)
    {
      err ("error: time out (at %d)", pos);
      return 0;
    }

  /* skip first pos? */
  if ((pos != GBA_HEADER_SIZE)
      && ((response ^ (pos + 0x1FFFFFE)) << 0x10))
    {
      err ("error: invalid response from console (at %d)", pos);
      return 0;
    }

  return 1;
}

/*   ______     ______     _______ ,---.____  multiboot protocol.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int
multiboot (uint8_t * image, int size)
{
  unsigned long flags;
  int i;
  int tmp;
  uint32_t response;
/*   int dot; */
/*   int dot_freq; */
  int pos;
  int value;
  int send;
  int seed_thingy;
  int crc_total;
  int crc_value;
  int image_size;

  /* transfer multiple of 16 bytes? */
  image_size = (size + 0x0F) & 0xFFFFFFF0;

  if (image_size < GBA_MB_MIN_SIZE)
    image_size = GBA_MB_MIN_SIZE;
  
/*   dot_freq = ((image_size/4) / 76) - 1; */
/*   dot = ((image_size/4) % 76) - 1; */

  response = 0;

  for (i = 4; i < GBA_HEADER_SIZE; i++)
    image[i] = multiboot_header[i];

  save_flags (flags);
  cli ();

  if (dmb_detect_mb () < 0)
    {
      err ("error: connection aborted.");
      goto multi_error;
    }

  info ("gameboy advance detected...");
  info ("sending %d bytes.", image_size);

  dmb_transfer_mb (0x6100);

  /* send header. */
  for (i = 0; i < GBA_HEADER_SIZE; i += 2)
    dmb_transfer_mb ((image[i + 1] << 8) + image[i]);

  response = dmb_transfer_mb (0x6202);
  dbg ("client data: 0x%04x", response);
  response = dmb_transfer_mb (0x63C1);
  dbg ("dlr: 0x%04x", response);
  response = dmb_transfer_mb (0x63C1);
  dbg ("dlr: 0x%04x", response);

  crc_value = (response + 0x0F) & 0xFF;
  seed_thingy = (response << 8) | 0xFFFF00C1;

  response = dmb_transfer_mb (crc_value | 0x6400);
  dbg ("sdl: 0x%04x", response);

  dmb_delay ();

  response = dmb_transfer_mb ((image_size - GBA_HEADER_SIZE - 0xD0) >> 2);
  dbg ("str5: 0x%04x", response);

  crc_value |= ((response & 0xFF) << 8) | 0xFFFF0000;
  crc_total = 0xFFF8;
  pos = GBA_HEADER_SIZE;

/*   womb_msg_short (info, "[ "); */

  for (pos = GBA_HEADER_SIZE; pos < image_size; pos += 4)
    {
/*       if (!dot--) */
/*         { */
/*           womb_msg_short (info, "="); */
/*           dot = dot_freq; */
/*         } */

      if (!do_checkresponse (response, pos))
        goto multi_error;

      value = (image[pos])
        + (image[pos + 1] << 0x08)
        + (image[pos + 2] << 0x10)
        + (image[pos + 3] << 0x18);

      crc_total = do_crc_stuff (crc_total, value);

      seed_thingy = (seed_thingy * 0x6F646573) + 1;
      send = seed_thingy ^ value ^ ((~(pos + 0x2000000)) + 1) ^ 0x6465646F;

      /* lower 16 bits. */
      response = dmb_transfer_mb (send & 0xFFFF);

      if (!do_checkresponse (response, pos + 2))
        goto multi_error;

      /* higher 16 bits. */
      response = dmb_transfer_mb (send >> 0x10);
    }

/*   womb_msg_short (info, " ]\n"); */

  tmp = 0x40;
  while (dmb_transfer_mb (0x0065) != 0x0075)
    if (!tmp--)
      {
        err ("error: invalid response from console after sending data.");
        goto multi_error;
      }

  dmb_transfer_mb (0x0066);

  crc_total = do_crc_stuff (crc_total, crc_value);
  tmp = crc_total & 0xFFFF;

  response = dmb_transfer_mb (tmp);
  dbg ("crc check: 0x%04x, 0x%04x", tmp, response);

  restore_flags (flags);

  if (tmp == response)
    {
      info ("CRC Ok - Done.");
      return 0;
    }
  else
    {
      err ("CRC Bad! - Abort.");
      return -EIO;
    }
  
 multi_error:
  restore_flags (flags);
  return -EIO;
}

