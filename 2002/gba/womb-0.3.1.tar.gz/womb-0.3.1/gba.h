/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef GBA_H
#define GBA_H

#define DEBUG
/* #undef DEBUG */

/*
 * Debugging helpers.. (taken almost verbatim from /usr/include/linux/usb.h)
 */
#ifdef DEBUG
#define dbg(format, arg...) printk(KERN_DEBUG SHORTNAME ": " format "\n" , ## arg)
#else
#define dbg(format, arg...) 
#endif
#define err(format, arg...) printk(KERN_ERR SHORTNAME ": " format "\n" , ## arg)
#define warn(format, arg...) printk(KERN_WARNING SHORTNAME ": " format "\n" , ## arg)
#define info(format, arg...) printk(KERN_INFO SHORTNAME ": " format "\n" , ## arg)

#define GBA_PORT_RANGE 0x03
#define GBA_HEADER_SIZE 0xC0
#define GBA_MB_MAX_SIZE 0x40000
#define GBA_MB_MIN_SIZE 0x1C0

#endif /* GBA_H */

