/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef DMB_H
#define DMB_H

#include <linux/types.h>

/*   ______     ______     _______ ,---.____  dumb multiboot driver.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/

/* port is an LPT port to which a dumb multiboot cable is connected.  I'm using 
   the cable designed by AjO (http://www.godsmaze.org/gba).  If you're using a similar
   cable connected to different pins on the LPT port you will have to edit dmb.c
   and recompile. */
int dmb_init (int port, int timeout, int attempts);
int dmb_detect_mb (void);
int32_t dmb_transfer_mb (uint16_t data);
void dmb_delay (void);


#endif /* DMB_H */

