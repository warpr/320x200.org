/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <string.h>

#include "getopt.h"
#include "womb.h"
#include "womb_err.h"

#define USAGE "Usage: " SHORTNAME \
"\t[-hvptds] [--help] [--verbose LVL] [--port PORT]\n" \
"      \t\t[--ticks TICKS] [--drv DRV] [--send FILE]\n"

/* help text used by `--help'. */
#define HELP "\nMisc:\n" \
"  -h, --help\t\tPrint this\n" \
"  -q, --quiet\t\tDon't output anything (same as --verbose=0)\n" \
"  -v, --verbose LVL\tSet how verbose " SHORTNAME " should be:\n" \
"  \t\t\t0 = be quiet,\n" \
"  \t\t\t1 = print only errors,\n" \
"  \t\t\t2 = print warnings and errors,\n" \
"  \t\t\t3 = print everyhting except debugging info (default)\n" \
"  \t\t\t4 = print everything\n" \
"\n" \
"Multiboot connection:\n" \
"  -p, --port PORT\tUse lpt port PORT (default: 378)\n" \
"  -t, --ticks TICKS\tcpu ticks for 115200 hz (default: autodetect)\n" \
"  -l, --loop TIMEOUT\tloop TIMEOUT many times when waiting for a response\n" \
"  -d, --drv DRV\t\tDRV should be one of the following:\n" \
"  \t\t\tdmb = old dumb multiboot driver,\n" \
"  \t\t\tdmb2 = new dumb multiboot driver,\n" \
"\n" \
"Action:\n" \
"  -s, --send FILE\tSend image FILE to gba\n"

/* option flags. */
static int help = 0;
static int verbose = 3;
int womb_opt_port = 0;
int womb_opt_ticks = 0;
int womb_opt_timeout = 0;
char * womb_opt_send = NULL;
char * womb_opt_drv = NULL;

/* `getopt_long' stores the option index here. */
static int option_index = 0;
static struct option long_options[] = {
  /* These options set a flag. */
  {"quiet",   no_argument,        &verbose, 0},
  {"help",    no_argument,        &help,    1},
  /* These options don't set a flag. We distinguish them by their indices. */
  {"verbose", required_argument,  0,        'v'},
  {"port",    required_argument,  0,        'p'},
  {"ticks",   required_argument,  0,        't'},
  {"loop",    required_argument,  0,        'l'},
  {"send",    required_argument,  0,        's'},
  {"drv",    required_argument,  0,        'd'},
  {0,         0,                  0,        0}
};


/*   ______     ______     _______ ,---.____  extract base name from argv[0].
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
unsigned char *
womb_basename (unsigned char *s)
{
  unsigned char *r;

  if ((r = strrchr (s, '/')))
    return r + 1;
  else if ((r = strrchr (s, '\\')))
    return r + 1;
  else
    return s;
}

/*   ______     ______     _______ ,---.____  parse commandline.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
void
womb_parse_cmdline (int argc, char **argv)
{
  int c = 0;

  /* this is just a temporary init for parse_cmdline. 
     womb_msg_init() will be called again after parsing
     the command line.
  */
  womb_msg_init (womb_basename (argv[0]), stdout);

  while (c != -1)
    {
      c = getopt_long (argc, argv, "v:qhp:t:s:d:l:", long_options, &option_index);

      switch (c)
        {
        case 0:
          /* If this option sets a flag, do nothing else now. */
          if (long_options[option_index].flag != 0)
            break;
          
        case 'v':
          {
            int opt;
            if (sscanf (optarg, "%d", &opt) < 1)
              womb_fatal ("invalid argument for --verbose");
            
            verbose = opt;
            break;
          }

        case 'p':
          {
            int opt;
            if (sscanf (optarg, "%x", &opt) < 1)
              womb_fatal ("invalid argument for --port");
            womb_opt_port = opt;
            break;
          }

        case 't':
          {
            int opt;
            if (sscanf (optarg, "%d", &opt) < 1)
              womb_fatal ("invalid argument for --ticks");
            womb_opt_ticks = opt;
            break;
          }

        case 'l':
          {
            int opt;
            if (sscanf (optarg, "%d", &opt) < 1)
              womb_fatal ("invalid argument for --loop");
            womb_opt_timeout = opt;
            break;
          }

        case 's':
          {
            womb_opt_send = optarg;
            break;
          }

        case 'd':
          {
            womb_opt_drv = optarg;
            break;
          }

        case 'q':
          verbose = 0;
          break;

        case 'h':
          help = 1;
          break;

        case -1:
          /* nothing to do for end of options. */
          break;

        case '?':
          /* `getopt_long' already printed an error message. */
          break;

        default:
          /* getopt should handle unknown options, so we should
             never come here. */
          womb_fatal ("internal error");
        }
    }

  if (help)
    {
      womb_banner (quiet, "%s%s%s", COPYRIGHT_SHORT, USAGE, HELP);
      exit (0);
    }

}

/*   ______     ______     _______ ,---.____  init womb_err and print banner,
 ,---\    /---./      \,--//      \|  //_   \ err_prefix should be argv[0].
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
void
womb_init (char * err_prefix)
{
  womb_msg_init (womb_basename (err_prefix), stdout);
  womb_msg_setverbose (verbose);

  womb_banner (info, COPYRIGHT);
}

