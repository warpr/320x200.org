/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef TIMER_H
#define TIMER_H

#include "types.h"

/* calibrate to cpu speed, returns the amount of cpu ticks which can be
   used with timer_until () to get the required hz. */
uint32_t timer_calibrate (int tests, int time, int hz);

/* i don't want any stack fiddling inside these macros. (i'm weird like that -- warp :) */
static uint_fast32_t _timer_reslo;
static uint_fast32_t _timer_reshi;
static uint_fast64_t _timer_res64;

/* get current cpu tick. */
#define timer_tick() ({ __asm__ ("rdtsc \n mov %%eax, %0 \n mov %%edx, %1"                       \
                                 : "=g" (_timer_reslo), "=g" (_timer_reshi) : : "eax", "edx", "cc"); \
                        _timer_res64 = ((uint_fast64_t)_timer_reshi) << 32 | _timer_reslo; _timer_res64; })

/* wait until tick n. */
#define timer_until(n) { uint_fast64_t _timer_tick = n; while (timer_tick () < _timer_tick); }

/* wait n ticks */
#define timer_wait(n) timer_until (timer_tick () + n)

#endif /* TIMER_H */
