/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/


/* #include <dos.h> */
#include <pc.h>
#include <conio.h>
#include <unistd.h>

#include "types.h"
#include "timer.h"
#include "womb_err.h"
#include "womb_drv.h"

/* timing...

   to measure how many cpu ticks occur during the transmission of 1 bit of
   data, TIMER_TESTS tests are performed, each test will take TIMER_TIME
   seconds.

 */
#define TIMER_HZ 115200
#define TIMER_TESTS 2
#define TIMER_TIME 4

/* input...

   SC is connected to `Paper Out' (bit 5).
   SD is connected to `Busy' (bit 7).
   SI is connected to `-Ack' (bit 6, inverted) .
   (SO is never used for input).
*/
#define rxSC(x) ((x >> 5) & 1)
#define rxSD(x) ((x >> 7) & 1)
#define rxSI(x) (~(x >> 6) & 1)

/* output...

   SC is connected to `D3' (bit 3).
   SD is connected to `D5' (bit 5).
   SO is connected to `D6' (bit 6).
   (SI is never used for output).
*/
#define txSC(x) ((x & 1) << 3)
#define txSD(x) ((x & 1) << 5)
#define txSO(x) ((x & 1) << 6)

static int dmb_cpu_ticks;
static int dmb_base_port;
static int dmb_timeout;
#define dmb_read_port() inportb (dmb_base_port+1)
#define dmb_write_port(x) outportb (dmb_base_port, x)

int32_t dmb_transfer_mb (uint16_t data);

/*   ______     ______     _______ ,---.____  init.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
uint32_t 
dmb_init (int port, uint32_t ticks)
{
  dmb_base_port = port;
  dmb_timeout = 300000;

  if (ticks)
    dmb_cpu_ticks = ticks;
  else 
    dmb_cpu_ticks = timer_calibrate (TIMER_TESTS, TIMER_TIME, TIMER_HZ);

  womb_msg (info, "using dumb multiboot cable (old driver):\n"
            " -- LPT port: 0x%x, transfer delay: %d cpu ticks.",
            port, dmb_cpu_ticks);

  return dmb_cpu_ticks;
}

/*   ______     ______     _______ ,---.____  a small delay.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
void
dmb_delay (void)
{
  timer_until (timer_tick () + (dmb_cpu_ticks / 19));
}

/*   ______     ______     _______ ,---.____  detect GBA. returns 1 on success,
 ,---\    /---./      \,--//      \|  //_   \ 0 on failure.
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int dmb_detect_mb (void)
{
  int32_t recv = 0;

  dmb_write_port (0xFF);
  puts ("looking for gameboy advance, press any key to abort...\n");

  while ((!kbhit ()) && (recv != 0x7202))
    {
      recv = dmb_transfer_mb (0x6202);

      if (recv == -1)
        womb_msg (debug, "time out waiting for GBA.");
      else
        womb_msg (debug, "response: 0x%04x.", recv);

      dmb_delay ();
    }

  return (recv == 0x7202);
}

/*   ______     ______     _______ ,---.____  transfer 16bits to GBA during
 ,---\    /---./      \,--//      \|  //_   \ multiboot, also receive 16bits.
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int32_t
dmb_transfer_mb (uint16_t data)
{
  /* start bit (0), data (lsb first), stop bit (1). */
  uint32_t output = 0x20000 | (data << 1);
  uint32_t input = 0;
  int timeout;
  int status;
  int bit;
  uint64_t next_bit;

  timeout = dmb_timeout;
  do
    {
      status = dmb_read_port ();

      if (!timeout--)
        return -1;
    }
  while (rxSD (status) || !rxSC (status));

  next_bit = timer_tick () + ((dmb_cpu_ticks * 13) / 16); /* FIXME: urk. */
  dmb_write_port (~(txSC(1) | txSD(1)));

  for (bit = 0; bit < 19; bit++)
    {
      dmb_write_port (~(txSC(1) | txSD(~((output >> bit) & 1))));
      timer_until (next_bit);
      next_bit += dmb_cpu_ticks;
    }

  dmb_write_port (~(txSC(1) | txSO(1)));
  
  timeout = dmb_timeout;
  while (!rxSD (dmb_read_port ()))
    if (!timeout--)
      return -1;

  next_bit = timer_tick () + ((dmb_cpu_ticks * 20) / 16); /* FIXME: urk. */

  for (bit = -1; bit < 17; bit++)
    {
      input |= (!rxSD (dmb_read_port ()) << bit);
      timer_until (next_bit);
      next_bit += dmb_cpu_ticks;
    }

  dmb_write_port (~txSC(1));

  timeout = dmb_timeout;
  while (rxSI (dmb_read_port ()))
    if (!timeout--)
      return -1;

  dmb_write_port (0xFF);
  
  return input & 0xFFFF;
}

/*   ______     ______     _______ ,---.____  register driver functions.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
womb_driver drv_dmb = {
  dmb_detect_mb,
  dmb_transfer_mb,
  dmb_delay,
};
