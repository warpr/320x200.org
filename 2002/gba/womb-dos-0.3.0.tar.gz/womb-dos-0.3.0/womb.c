/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <dos.h>

#include "types.h"
#include "wombfile.h"
#include "womb_opt.h"
#include "womb_err.h"
#include "womb_drv.h"
#include "drv_dmb.h"
#include "drv_dmb2.h"
#include "multi.h"

/*   ______     ______     _______ ,---.____  detect n-th lpt port.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int
womb_detect_lpt (int n)
{
  /* FIXME: do actual detection. :)
     e.g. read it from the bios segment at 0x0040 or something. */
  return 0x378;
}

/*   ______     ______     _______ ,---.____  main.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
int
main (int argc, char **argv)
{
  womb_file * image;

  womb_driver *drv = NULL;

  womb_parse_cmdline (argc, argv);
  womb_init (argv[0]);

  /* select action here (currently only send multiboot image). */
  if (!womb_opt_send)
    womb_fatal ("nothing to do\n");

  image = womb_file_load (womb_opt_send);

  /* detecting a port is harmless and quick, so let's do that first
     even if perhaps a future driver does not use it. */
  if (!womb_opt_port)
    womb_opt_port = womb_detect_lpt (1);
  
  /* select driver here. */
  if ((womb_opt_drv) && (!strcmp ("dmb", womb_opt_drv)))
    {
      /* note: the arguments for init may be driver specific,
         thus init is not included in the driver struct. */
      dmb_init (womb_opt_port, womb_opt_ticks);
      drv = &drv_dmb;
    }
  else if (((womb_opt_drv) && (!strcmp ("dmb2", womb_opt_drv)))
           || (!womb_opt_drv))
    {
      dmb2_init (womb_opt_port, womb_opt_ticks, womb_opt_timeout);
      drv = &drv_dmb2;
    }
  else if (womb_opt_drv)
    {
      womb_fatal ("unknown driver: %s", womb_opt_drv);
    }

  if (!drv)
    womb_fatal ("internal error");

  if (multiboot (drv, image))
    return 0;

  return 1;
}


