/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef WOMB_ERR_H
#define WOMB_ERR_H

#include <stdio.h>

/* never use `quiet'.  only --help should do that. */
enum priority { quiet = 0, error, warning, info, debug };

void womb_msg_init (char *progname, FILE *handle);
void womb_msg_setverbose (int verbose);
void womb_msg (int priority, const char *template, ...);
void womb_banner (int priority, const char *template, ...);
void womb_fatal (const char *template, ...);
void womb_msg_short (int priority, unsigned char * msg);

#endif /* WOMB_ERR_H */
