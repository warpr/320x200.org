           ______     ______     _______ ,---.____  
       ,---\    /---./      \,--//      \|  //_   \ 
        \   \  /|       /|       |/  \        /   / 
         \______\\--,____\\------/____\--,_______/  
        womb-dos 0.3.0 - copyright 2002 Kuno Woudt.

  Hi!

 [intro]

  You are reading the readme.txt for womb, a tool to communicate
  with the Nintendo Gameboy Advance handheld game console. 

  Currently it can only send a multiboot image to the GBA, but
  there are lots of other things which should be fairly easy to
  implement now that the actual transfer code is done. 

 [quickstart]

  try typing this at a dos prompt:  

     womb --send fairy.gba  

  read the manual (manual.txt) for more information.

 [thanks]

  Before I go on, I would like to thank Miguel Angel Ajo
  <ajo@godsmaze.org>.  He designed the schematic of the `dumb
  parallel multiboot cable' and wrote the software for it.  

  womb is just a rewrite of Ajo's `dmb'.

 [why?]

  After building the abovementioned `dumb multiboot parallel
  cable' I experienced several shortcomings in dmb: 

    - dmb was written for turbo assembler and watcom c/c++,
      which are not freely available. 

    - dmb only transferred correctly on my old pentium 133mhz,
      it does not work on faster machines such as a celeron
      466mhz.

    - dmb doesn't reliably transfer large .rom images.

    - dmb requires real MS-DOS (a win32 dos-box does not work).

  Ajo has fixed these shortcomings by designing an intelligent
  cable, with better software for it. 

  But I would rather keep using the dumb cable: the parts cost
  almost nothing, and it is very easy to build.

 [progress]

  I have not yet eliminated all the problems of the original dmb
  software, here is what I have done so far:

    - womb was written from scratch using DJGPP, except multi.c
      which has been ported from dmb`s multi.asm.
      (I just discovered Andrew May also ported multi.asm to c,
       it's nice to see so many people working on this! :)

    - I am not sure why `dmb' did not work on faster machines,    
      womb _seems_ to work, but has only been tested on this
      celeron 466mhz.

    - Transfers seem to be reliable now, even for larger files.
      (such as Ajo's modplayer preview (222 kb) posted on 
       www.gbadev.org).

  A new problem which has surfaced during development of womb is
  that it doesn't seem to work at all on some PC's - presumably
  dmb has the same problem.  My guess is that it has something
  to do with the printer port (changing spp/ecp/epp in the bios
  doesn't help though), but I don't have any means to
  investigate this.  
      
 [future]

  Some things I have planned to solve the remaining problems:

    - Create a linux kernel module to do the transfer, so I can
      stop using MS-DOS (work is progressing nicely on this,
      check http://www.digiskar.nl/~kuno for updates).

    - Write a stub which can be transferred to the GBA which
      will handle communications so that the multiboot protocol
      is only needed for the small stub.

 [distant future]

  If my idea of sending a stub to the GBA actually works, there
  are many things I would like to add to the stub:

    - Reset the GBA when a program exits cleanly, so that you do
      not need to switch off/on the GBA each time you want to
      try something.
    - Send debugging info to the PC (i'm not sure I feel up to
      writing a gdb stub, so i probably will stick to the printf
      style of debugging :)

  And if I feel like it - there is all that business of dumping
  the contents of a cartridge, bios, save games, and perhaps
  flashing empty cartridges and writing save games.

 [bye]

  That's it for now, see below for the license of this software
  and for links on the various multiboot cables out there.

  Don't hesitate to mail me for any reason,

  -- Kuno Woudt a.k.a. Warp^Bliss <warp-tmt@dds.nl>.

 [gba multiboot links]

  Ajo's site contains the schematics and his software for the
  dumb multiboot cable.  And he has recently added a new
  intelligent cable schematic + nice windows software to it.

  http://www.godsmaze.org/gba

  Jeff Frohwein's site contains lots of information about
  gameboy advance programming in general, and software for his
  commercially available MBV2 intelligent cable.

  http://www.devrs.com/gba

  The lastest version of womb and womb-dos should be available
  on my own site.

  http://www.digiskar.nl/~kuno

 [misc links]
  
  For general gba coding information, also have a look at
  http://www.gbadev.org. 

  For my own demoscene related work visit
  http://www.demonic.demon.nl. 

  And please visit #demoscene on openprojects irc if you are
  interested in any open source demoscene related activities.

 [license]

    This file is part of womb (warp's own multiboot), a tool to
    communicate with the Nintendo Gameboy Advance handheld game
    console.  
    Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; see the file copying.txt; if not, write to
    the Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  [emacs]

    Local Variables:
    fill-column: 64
