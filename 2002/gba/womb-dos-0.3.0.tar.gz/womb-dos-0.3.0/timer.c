/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <unistd.h>

#include "womb_err.h"
#include "types.h"
#include "timer.h"

/*   ______     ______     _______ ,---.____  calibrate timer.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
uint32_t
timer_calibrate (int tests, int time, int hz)
{
  uint64_t tick_start;
  uint64_t tick_end;
  uint32_t tick[tests];
  uint32_t tick_totaal = 0;
  int i;

  womb_msg (info, "measuring cpu speed...");

  for (i = 0; i < tests; i++)
    {
      tick_start = timer_tick ();
      sleep (time);
      tick_end = timer_tick ();

      tick[i] = (tick_end - tick_start) / (time * hz);

      tick_totaal += tick[i];

      womb_msg (debug, "ticks (for %d hz) %2d: %d.", hz, i, tick[i]);
    }

  tick_totaal /= tests;

  return tick_totaal;
}

