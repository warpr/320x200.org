/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef WOMB_TYPES_H
#define WOMB_TYPES_H

/* If this is built with glibc there should be a stdint.h. provide
   our own alternatives if stdint.h is not available. */

#include <stdio.h> /* glibc will include features.h here. */

#undef WOMB_STDINT
#ifdef __GLIBC_MINOR__
/* stdint.h is probably older, but i'm too lazy too check. */
#  if __GLIBC_PREREQ(2, 2)
#    define WOMB_STDINT
#  endif
#endif

#ifndef WOMB_STDINT

/* #warning not using stdint.h, if your system does have a C9X compiler, please add a proper check for it in types.h */

typedef signed char		int8_t;
typedef short int		int16_t;
typedef int			int32_t;
typedef long long int		int64_t;

typedef unsigned char		uint8_t;
typedef unsigned short int	uint16_t;
typedef unsigned int		uint32_t;
typedef unsigned long long int	uint64_t;

typedef signed char		int_fast8_t;
typedef int			int_fast16_t;
typedef int			int_fast32_t;
typedef long long int		int_fast64_t;

typedef unsigned char		uint_fast8_t;
typedef unsigned int		uint_fast16_t;
typedef unsigned int		uint_fast32_t;
typedef unsigned long long int	uint_fast64_t;

#endif /* WOMB_STDINT */
#undef WOMB_STDINT

#endif /* WOMB_TYPES_H */
