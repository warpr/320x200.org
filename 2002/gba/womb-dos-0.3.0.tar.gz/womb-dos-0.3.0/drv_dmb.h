/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef DRV_DMB_H
#define DRV_DMB_H

#include "womb_drv.h"

/*   ______     ______     _______ ,---.____  dumb multiboot driver.
 ,---\    /---./      \,--//      \|  //_   \ 
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/


/* port is an LPT port to which a dumb multiboot cable is connected.  I'm using 
   the cable designed by AjO (http://www.godsmaze.org/gba).  If you're using a similar
   cable connected to different pins on the LPT port you will have to edit drv_dmb.c
   and recompile.

   ticks is the amount of cpu ticks it should take to send a single bit, set it to
   0 to autodetect - the return value might be useful in this case, it contains the
   detected cpu ticks, which should be saved to a config file to prevent repeated
   autodetection.
 */
uint32_t dmb_init (int port, uint32_t ticks);
extern womb_driver drv_dmb;

#endif /* DRV_DMB_H */
