/*

  This file is part of womb (warp's own multiboot), a tool to communicate 
  with the Nintendo Gameboy Advance handheld game console.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include "wombfile.h"
#include "womb_err.h"
#include "multi.h"

static unsigned char womb_data[GBA_MB_MAX_SIZE];
static womb_file womb_image;

/*   ______     ______     _______ ,---.____  load a multiboot image, returns
 ,---\    /---./      \,--//      \|  //_   \ pointer to the data.
  \   \  /|       /|       |/  \        /   / =================================
   \______\\--,____\\------/____\--,_______/  womb - pc->gba multiboot transfer
*/
womb_file *
womb_file_load (char * filename)
{
  FILE * image;
  int size;

  if(!(image = fopen (filename, "rb")))
    womb_fatal ("cannot load file %s", filename);

  size = fread (&womb_data, sizeof (unsigned char), GBA_MB_MAX_SIZE, image);

  womb_msg (info, "read %d bytes from %s", size, filename);
  
  fclose (image);

  womb_image.data = &womb_data[0];
  womb_image.size = size;

  return &womb_image;
}
