/*
  This file is part of Fairy, a Gameboy Advance test screen.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef FNT_H
#define FNT_H

#include "types.h"

typedef struct {
  uint8_t width;           /* width of a char (fixed-width fonts) */
  uint8_t height;          /* height of a char */
  uint8_t ascii;           /* first char in font corresponds to 
                              this character in ascii. */
  uint8_t colour;          /* colour for mono fonts. 
                              if this is 0, the font is multicoloured and 
                              uses a byte for each pixel, if this is 1 the
                              font is monochrome and packed into a 1 bit
                              for each pixel format. */
  uint8_t count;           /* amount of characters in font. */
  uint8_t * charx;         /* if this is not NULL, it contains the width
                              for each character (non-fixed width font). */
  uint8_t * data;          /* if colour: count*width*height,
                              else: (count*width*height)/8. */
  uint16_t palcount;       /* amount of colours in palette. */
  uint8_t * pal;           /* if colour, this contains the rgb values for
                              each colour. */
} typeface;

#endif /* FNT_H */
