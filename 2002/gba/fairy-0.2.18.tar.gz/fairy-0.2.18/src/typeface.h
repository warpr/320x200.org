/*
  This file is part of bob, a 32k game for Mekka Symposium 2001.
  Copyright 2001 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program (see the file copying.txt); if not, write 
  to the Free Software Foundation, Inc., 
  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef TYPEFACE_H
#define TYPEFACE_H

#include "types.h"
#include "img.h"
#include "fnt.h"

char * format_text (const char * template, ...);

/* 
   NOTE: this is old now. some improvements have been done to 
   MAKE_RENDER_SCREEN and this MAKE_RENDER_TEXT still needs those updates.

   NOTE: no bitpacked font support yet. 
*/
#define MAKE_RENDER_TEXT(FONT, font, HSPACING, VSPACING) int                   \
  render_##font (const uint_fast8_t xpos, const uint_fast8_t ypos,             \
                 const char * msg)                                             \
    {                                                                          \
      uint16_t * vram_ptr;                                                     \
      uint16_t * vram_bak;                                                     \
      uint16_t * font_ptr;                                                     \
      const char * msg_ptr;                                                    \
      uint_fast8_t ch;                                                         \
      uint_fast8_t y;                                                          \
      uint_fast8_t x;                                                          \
                                                                               \
      vram_bak = (uint16_t *) VRAM + ypos * VRAM_MODE4_X_2 + (xpos>>1);        \
      vram_ptr = vram_bak;                                                     \
                                                                               \
      for (y=0; y<FONT##_HEIGHT; y++)                                          \
        {                                                                      \
          msg_ptr = msg-1;                                                     \
                                                                               \
          while (*(++msg_ptr))                                                 \
            {                                                                  \
              ch = *msg_ptr - FONT##_ASCII;                                    \
                                                                               \
              font_ptr = (uint16_t *) (font##_data                             \
                                       + ch * FONT##_WIDTH * FONT##_HEIGHT     \
                                       + y * FONT##_WIDTH);                    \
                                                                               \
              x = (FONT##_WIDTH/2);                                            \
              while (x--)                                                      \
                *vram_ptr++ = *font_ptr++;                                     \
                                                                               \
              vram_ptr += HSPACING;                                            \
            }                                                                  \
                                                                               \
          vram_bak += VRAM_MODE4_X_2;                                          \
          vram_ptr = vram_bak;                                                 \
        }                                                                      \
                                                                               \
      return ypos + FONT##_HEIGHT + VSPACING;                                  \
    }

/* NOTE: no bitpacked font support yet. */
#define MAKE_RENDER_SCREEN(FONT, font, HSPACING, VSPACING) void                \
  render_screen_##font (const char * msg)                                      \
    {                                                                          \
      uint16_t * vram_ptr;                                                     \
      uint16_t * vram_bak;                                                     \
      uint16_t * font_ptr;                                                     \
      const char * msg_ptr;                                                    \
      uint_fast8_t ch;                                                         \
      uint_fast8_t y;                                                          \
      uint_fast8_t x;                                                          \
      uint_fast8_t row;                                                        \
      uint_fast8_t column;                                                     \
                                                                               \
      vram_bak = (uint16_t *) VRAM;                                            \
      vram_ptr = vram_bak;                                                     \
      msg_ptr = msg;                                                           \
                                                                               \
      row = (160 / (FONT##_HEIGHT + VSPACING));                                \
      while (row--)                                                            \
        {                                                                      \
          column = (240 / (FONT##_WIDTH + HSPACING));                          \
          while (column--)                                                     \
            {                                                                  \
              if (!*msg_ptr) return;                                           \
              ch = *msg_ptr++ - FONT##_ASCII;                                  \
                                                                               \
              font_ptr = (uint16_t *) (font##_data                             \
                                       + ch * FONT##_WIDTH * FONT##_HEIGHT);   \
                                                                               \
              for (y=0; y<FONT##_HEIGHT; y++)                                  \
                {                                                              \
                  x = (FONT##_WIDTH/2);                                        \
                  while (x--)                                                  \
                    *vram_ptr++ = *font_ptr++;                                 \
                                                                               \
                  vram_ptr += (VRAM_MODE4_X - FONT##_WIDTH) / 2;               \
                }                                                              \
                                                                               \
              vram_ptr -= VRAM_MODE4_X_2 * FONT##_HEIGHT                       \
                        - (HSPACING + FONT##_WIDTH) / 2;                       \
            }                                                                  \
          vram_ptr += VRAM_MODE4_X_2 * (FONT##_HEIGHT + VSPACING - 1);         \
        }                                                                      \
    }

typedef struct
{
  char * label;
  int * var;
} menu_entry;

void menu (menu_entry * items, int x, int y);

#endif /* TYPEFACE_H */
