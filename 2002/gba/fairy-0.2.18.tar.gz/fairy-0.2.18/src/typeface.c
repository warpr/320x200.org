/*
  This file is part of bob, a 32k game for Mekka Symposium 2001.
  Copyright 2001 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program (see the file copying.txt); if not, write 
  to the Free Software Foundation, Inc., 
  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdarg.h>

#include "agb.h"
#include "types.h"
#include "typeface.h"
#include "img.h"

#include "retroo_1.h"
MAKE_RENDER_TEXT (RETROO_1, retroo_1, 0, 1);

#ifndef TYPEFACE_MAX_FORMAT
#define TYPEFACE_MAX_FORMAT 40  /* 40 characters on a row with most fonts. */
#endif

#define REPEAT_WAIT 16 
#define REPEAT_RATE 2

static char format_tmp[TYPEFACE_MAX_FORMAT];
static int current_item = 0;
static int current_bit = -1;

static int pressed_a = 0;
static int pressed_b = 0;
static int pressed_l = 0;
static int pressed_r = 0;
/* static int pressed_start = 0; */
/* static int pressed_stop = 0; */
static int pressed_up = 0;
static int pressed_left = 0;
static int pressed_right = 0;
static int pressed_down = 0;

static int repeat_a = 0;
static int repeat_b = 0;
static int repeat_l = 0;
static int repeat_r = 0;
/* static int repeat_start = 0; */
/* static int repeat_stop = 0; */
static int repeat_up = 0;
static int repeat_left = 0;
static int repeat_right = 0;
static int repeat_down = 0;

/*
   ____ int2str _____________________________________________________
   __________________________________________________________________
   __________________________________________________________________
   __________________________________________________________________
*/
char *
int2str_hex (char * str, char * end, int val, int pad, char pad_char)
{
  char digit;
  char * ptr;
  int tmp;
  int shift;
  unsigned int hex = (unsigned int) val;

  if (pad)                      /* pad = right aligned. so work from right to left. */
    {
      ptr = str + pad - 1;
      tmp = pad + 1;
      if (ptr >= end)
        return str;             /* FIXME: error reporting? */

      while (--tmp && hex)
        {
          digit = hex & 0x0F;
          *ptr-- = (digit > 9) ? digit + 'A' - 10 : digit + '0';
          hex >>= 4;
        }

      while (tmp--)
        *ptr-- = pad_char;

      return str + pad;
    }
  else                          /* !pad = left aligned. so work from left to right. */
    {
      ptr = str;
      shift = 0x20;
      tmp = 0;

      while ((ptr < end) && shift)
        {
          shift -= 4;
          digit = (hex & (0x0F << shift)) >> shift;
          hex = hex & (~(0x0F << shift));
          if (digit)
            tmp = 1;
          if (tmp)
            *ptr++ = (digit > 9) ? digit + 'A' - 10 : digit + '0';
        }

      return ptr;
    }
}

char *
int2str_bin (char * str, char * end, int val, int pad, char pad_char)
{
  char digit;
  char * ptr;
  int tmp;
  int shift;
  unsigned int bin = (unsigned int) val;

  if (pad)                      /* pad = right aligned. so work from right to left. */
    {
      ptr = str + pad - 1;
      tmp = pad + 1;
      if (ptr >= end)
        return str;             /* FIXME: error reporting? */

      while (--tmp && bin)
        {
          *ptr-- = (bin & 0x01) + '0'; 
          bin >>= 1;
        }

      while (tmp--)
        *ptr-- = pad_char;

      return str + pad;
    }
  else                          /* !pad = left aligned. so work from left to right. */
    {
      ptr = str;
      shift = 0x20;
      tmp = 0;

      while ((ptr < end) && shift)
        {
          shift -= 1;
          digit = (bin & (0x01 << shift)) >> shift;
          bin = bin & (~(0x01 << shift));
          if (digit)
            tmp = 1;
          if (tmp)
            *ptr++ = digit + '0';
        }

      return ptr;
    }
}

char *
int2str (char * str, char * end, int val, int radix, int pad, char pad_char)
{
  switch (radix)
    {
    case (16):
      return int2str_hex (str, end, val, pad, pad_char);
    case (2):
      return int2str_bin (str, end, val, pad, pad_char);
    }
  
  return str;
}

/*
   ____ format_text _________________________________________________
   __________________________________________________________________
   __________________________________________________________________
   __________________________________________________________________
*/
char *
format_text (const char * template, ...)
{
  va_list ap;
  const char * src = template;
  char * dst = format_tmp;
  char * end = format_tmp + TYPEFACE_MAX_FORMAT - 1;
  char pad_char = ' ';
  int pad = 0;

  va_start (ap, template);

  while ((dst < end) && (*src))
    {
      switch (*src)
        {
        case '%':
          src++;
          if (*src != '%')
            {
              if (*src == '0')
                pad_char = *src++;
              while ((*src > '0') && (*src <= '9'))
                pad = pad * 10 + (*src++ - '0');
              switch (*src)     /* ugh. nested switch. */
                {
                case ('D'):
                case ('d'):
                case ('X'):
                case ('x'):
                  dst = int2str (dst, end, va_arg (ap, int), 16, pad, pad_char);
                  break;
                case ('B'):
                case ('b'):
                  dst = int2str (dst, end, va_arg (ap, int), 2, pad, pad_char);
                  break;
/*                 default: */
                  /* FIXME: write some nice assertion code which
                     starts flashing the screen red or something :) */
                }
              break;
            }
          /* NOTE!: fall-through :) */
        default:
          *dst++ = *src;
        }
      src++;
    }

  va_end (ap);

  *dst = '\0';

  return format_tmp;
}

/* FIXME: do this properly, and move it to a keys.c/.h. */
int
checkkey (uint16_t key, int * pressed, int * repeat)
{
  if ((~(*(uint16_t *) REG_KEYS) & key))
    {
      if (!(*pressed)) 
        {
          *pressed = 1;
          *repeat = REPEAT_WAIT;
          return 1;
        }
      else
        if (!(*repeat)--)
          {
            *repeat = REPEAT_RATE;
            return 1;
          }
    }
  else
    *pressed = 0;

  return 0;
}


/*
   ____ menu ________________________________________________________
   __________________________________________________________________
   __________________________________________________________________
   __________________________________________________________________
*/
void
menu (menu_entry * items, int x, int y)
{
  int item_count = 0;
  menu_entry * itemptr = items;

  while (itemptr->label)
    {
      if (item_count == current_item)
        render_retroo_1 (0, y, ">");
      else
        render_retroo_1 (0, y, " ");

      y = render_retroo_1 (6, y, format_text (itemptr->label, *(itemptr->var)));
       
      item_count++;
      itemptr++;
    }

  item_count--;

  y = render_retroo_1 (6, y, " ");
  y = render_retroo_1 (6, y, 
                       format_text ("bits: 0b%016b", (*(items[current_item].var))));
  y = render_retroo_1 (6 + current_bit * RETROO_1_WIDTH, y, "        ^ ");

  if ((checkkey (BUTTON_UP, &pressed_up, &repeat_up)) 
      && (current_item>0)) current_item--;
  if ((checkkey (BUTTON_DOWN, &pressed_down, &repeat_down)) 
      && (current_item<item_count)) current_item++;
  if (checkkey (BUTTON_LEFT, &pressed_left, &repeat_left)) 
      (*(items[current_item].var))-=(0x01 << (15-current_bit));
  if (checkkey (BUTTON_RIGHT, &pressed_right, &repeat_right))
      (*(items[current_item].var))+=(0x01 << (15-current_bit));

  if ((checkkey (BUTTON_L, &pressed_l, &repeat_l))
      && (current_bit>-1)) current_bit--;
  if ((checkkey (BUTTON_R, &pressed_r, &repeat_r))
      && (current_bit<15)) current_bit++;

  if (checkkey (BUTTON_A, &pressed_a, &repeat_a))
    {
      if (current_bit>-1)
        (*(items[current_item].var)) |= (0x01 << (15-current_bit));
      else
        (*(items[current_item].var))++;
    }
  if (checkkey (BUTTON_B, &pressed_b, &repeat_b))
    {
      if (current_bit>-1)
        (*(items[current_item].var)) &= (~(0x01 << (15-current_bit)));
      else
        (*(items[current_item].var))--;
    }

/* static int pressed_start = 0; */
/* static int pressed_stop = 0; */
/* static int pressed_left = 0; */
/* static int pressed_right = 0; */

}
