/*

  This file is part of Fairy, a Gameboy Advance test screen.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

/* support multiboot too. */
int __gba_multiboot;

#define VRAM_SIZE 0x12C00
#define PAL_SIZE 0x100

#define BGR(b,g,r) ( ((b<<7) & 0x7C00) | ((g<<2) & 0x03E0) | (r>>3))

#include <stddef.h>

#include "types.h"
#include "agb.h"
#include "tab.h"
#include "img.h"
#include "typeface.h"
#include "fairy.h"
#include "balk.h"

/* MAKE_RENDER_SCREEN (RETROO_1, retroo_1, 0, 1); */

void
image (uint16_t * vram, uint_fast8_t x_off,
       uint_fast8_t y_off, image_bgr15 * src)
{
  uint16_t *vram_ptr;

  uint_fast8_t x;
  uint_fast8_t y;

  uint8_t *img = src->img;
  uint8_t t;

  for (y = y_off; y < src->height + y_off; y++)
    {
      vram_ptr = vram + 0x78 * y + (x_off >> 1);

      for (x = 0; x < src->width; x += 2)
        {
          t = *img++;
          *vram_ptr++ = t | (*img++) << 8;
        }
    }
}

void
vsync (void)
{
__asm__ ("    mov r1, #0x4000000 \n" 
         "0: ldrb r0, [r1, #6]   \n"
         "    cmp r0, #161       \n"
         "    bne 0b             \n"
         : : : "r0", "r1", "cc");
}

int oam_vals[6];
int oam_rotscal[4];

menu_entry oam_menu[] = { 
  { "oam 1, attr 0: 0x%04x            ", &oam_vals[0], },
  { "oam 1, attr 1: 0x%04x            ", &oam_vals[1], },
  { "oam 1, attr 2: 0x%04x            ", &oam_vals[2], },
  { "oam 2, attr 0: 0x%04x            ", &oam_vals[3], },
  { "oam 2, attr 1: 0x%04x            ", &oam_vals[4], },
  { "oam 2, attr 2: 0x%04x            ", &oam_vals[5], },
  { "oam PA (dx)  : 0x%04x            ", &oam_rotscal[0], },
  { "oam PB (dmx) : 0x%04x            ", &oam_rotscal[1], },
  { "oam PC (dy)  : 0x%04x            ", &oam_rotscal[2], },
  { "oam PD (dmy) : 0x%04x            ", &oam_rotscal[3], },
  { NULL, NULL, },
};

int
AgbMain (void)
{
  uint16_t *pal_data;
  uint16_t *ptr;
  uint8_t x = 0;
  uint8_t y = 0;
  uint8_t t = 0;
  uint8_t sprite_x = 0;
  uint8_t sprite_y = 0;
  uint8_t xinc = 0;
  uint8_t yinc = 0;
  uint8_t xinc2 = 0;
  uint8_t yinc2 = 0;
  uint8_t *img;
  int i;

  *(uint16_t *) REG_DISPCNT = 
    DISP_OBJ_BLANK | DISP_BG2_ON | DISP_MODE_4 | DISP_OBJ_ON | DISP_OBJ_1D;

  *(uint16_t *) REG_STAT = 0;

  ptr = (uint16_t *) PALETTE;
  pal_data = balk.pal;
  for (i = 0; i < balk.palcount; i++)
    *ptr++ = *pal_data++;

  /* init OBJ palette too. */
  ptr = (uint16_t *) PALETTE_OBJ;
  pal_data = balk.pal;
  for (i = 0; i < balk.palcount; i++)
    *ptr++ = *pal_data++;

  ptr = (uint16_t *) VRAM_OBJ0;
  while (ptr < (uint16_t *) (VRAM_OBJ1 + (VRAM_OBJ1 - VRAM_OBJ0)))
    {
      for (sprite_y = 0; sprite_y < 64/8; sprite_y++)
        for (sprite_x = 0; sprite_x < 32/8; sprite_x++)
          for (y = 0; y < 8; y++)
            {
              img = balk.img + balk.width * y 
                + sprite_y * balk.width * 8 + sprite_x * 8;
              for (x = 0; x < 4; x++)
                {
                  t = *img++;
                  *ptr++ = t | (*img++) << 8;
                }
            }
    }

  ptr = (uint16_t *) OAM;
  for (i = 0; i < 128; i++)
    {
      *ptr++ = 0x2200;
      *ptr++ = 0x0000;
      *ptr++ = 0x0000;
      *ptr++ = 0x0000;
    }

  for (i = 0; i < 6; i++) oam_vals[i] = 0;
  for (i = 0; i < 4; i++) oam_rotscal[i] = 0;

  oam_vals[0] = 0x2000;
  oam_vals[1] = 0x8000;
  oam_vals[2] = 0x0200;
  oam_vals[3] = 0x2000;
  oam_vals[4] = 0x8000;
  oam_vals[5] = 0x0220;

  while (1)
    {
      vsync ();

      xinc++;
      yinc += 2;

      xinc2 -= 2;
      yinc2 += 3;

      menu (oam_menu, 0, 40);

      x = sintab[xinc] >> 1;
      y = sintab[yinc] >> 2;

      *(uint16_t *) (OAM+0x00) = y | oam_vals[0];
      *(uint16_t *) (OAM+0x02) = x | oam_vals[1];
      *(uint16_t *) (OAM+0x04) = oam_vals[2];

      x = sintab[xinc2] >> 1;
      y = sintab[yinc2] >> 2;

      *(uint16_t *) (OAM+0x08) = y | oam_vals[3];
      *(uint16_t *) (OAM+0x0A) = x | oam_vals[4];
      *(uint16_t *) (OAM+0x0C) = oam_vals[5];

      *(uint16_t *) (OAM+0x06) = oam_rotscal[0];
      *(uint16_t *) (OAM+0x0E) = oam_rotscal[1];
      *(uint16_t *) (OAM+0x16) = oam_rotscal[2];
      *(uint16_t *) (OAM+0x1E) = oam_rotscal[3];

      image ((uint16_t *) VRAM, 240 - 32, 160 - 64, &balk);

    }
}

