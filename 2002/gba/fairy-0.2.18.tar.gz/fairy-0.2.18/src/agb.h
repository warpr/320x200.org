/*

  This file is part of Fairy, a Gameboy Advance test screen.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#ifndef AGB_H
#define AGB_H

#define DISP_LCDC_OFF  0x80
#define DISP_MODE_3    3
#define DISP_MODE_4    4
#define DISP_MODE_5    5
#define DISP_OBJ_BLANK 0x0020
#define DISP_OBJ_1D    0x0040
#define DISP_BG0_ON    0x0100
#define DISP_BG1_ON    0x0200
#define DISP_BG2_ON    0x0400
#define DISP_BG3_ON    0x0800
#define DISP_OBJ_ON    0x1000

#define BUTTON_A       0x0001
#define BUTTON_B       0x0002
#define BUTTON_SELECT  0x0004
#define BUTTON_START   0x0008
#define BUTTON_RIGHT   0x0010
#define BUTTON_LEFT    0x0020
#define BUTTON_UP      0x0040
#define BUTTON_DOWN    0x0080
#define BUTTON_R       0x0100
#define BUTTON_L       0x0200

#define REG_BASE       0x4000000
#define REG_DISPCNT    (REG_BASE + 0x000)
#define REG_STAT       (REG_BASE + 0x004)
#define REG_VCOUNT     (REG_BASE + 0x006)
#define REG_SND1       (REG_BASE + 0x060)
#define REG_SND2       (REG_BASE + 0x068)
#define REG_SND3       (REG_BASE + 0x070)
#define REG_SND4       (REG_BASE + 0x078)
#define REG_SNDCNTL    (REG_BASE + 0x080)
#define REG_SNDWAV     (REG_BASE + 0x090)
#define REG_KEYS       (REG_BASE + 0x130)
#define PALETTE        0x5000000
#define PALETTE_OBJ    0x5000200
#define VRAM           0x6000000
#define VRAM_OBJ0      0x6010000
#define VRAM_OBJ1      0x6014000
#define OAM            0x7000000

#define VRAM_MODE4_X      0xF0
#define VRAM_MODE4_X_2    0x78
#define VRAM_MODE4_Y      0xA0

#endif /* AGB_H */
