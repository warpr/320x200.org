/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

/* FIXME: hmm. more documentation :) */

#ifndef IMG_H
#define IMG_H

#include <stdint.h>

/* 
   img_lbm   == ilbm as used by deluxe paint IIe
                (however, the decoder only accepts 256 colour images)
   img_raw   == raw image data.
   img_pal   == raw palette data (colours range from 0x00 to 0x3F)
   img_act   == raw palette data (colours range from 0x00 to 0xFF)
   img_ppal  == raw packed palette data (rgb are packed into 16 bit 
                words, colours range from 0x00 to 0x1F)
   img_c     == .c file
   img_h     == accompanying header file
   img_raw_c == .c file without using a struct.
   img_raw_h == accompanying header file
*/
enum filetype { img_lbm, img_raw, img_pal, img_act, img_ppal, 
                img_c, img_h, img_raw_c, img_raw_h };

typedef struct {
  uint16_t width;
  uint16_t height;
  uint16_t palcount;
  uint8_t * pal;
  uint32_t imgsize;
  uint8_t * img;
} image_rgb24;

typedef struct {
  uint16_t width;
  uint16_t height;
  uint16_t palcount;
  uint16_t * pal;
  uint32_t imgsize;
  uint8_t * img;
} image_bgr15;

/* returns NULL on error. */
image_rgb24 * load_image (const char * filename);
image_bgr15 * load_image_bgr15 (const char * filename);

/* returns 0 on error. */
int save_image (const char * filename, const enum filetype type, 
                const image_rgb24 * img);
int save_image_bgr15 (const char * filename, const enum filetype type, 
                      const image_bgr15 * img);

#endif /* IMG_H */
