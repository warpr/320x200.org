/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <stdlib.h>

#include "err.h"
#include "raw.h"
#include "lbm.h"
#include "img.h"
#include "c.h"

#define BGR(b,g,r) ( ((b<<7) & 0x7C00) | ((g<<2) & 0x03E0) | (r>>3))

void
free_image (image_rgb24 * img)
{
  if (img)
    {
      if (img->img)
        free (img->img);

      if (img->pal)
        free (img->pal);
    }

  free (img);
}

image_rgb24 * 
load_image (const char * filename)
{
  FILE * handle;
  int size;
  int count;
  unsigned char * rawdata;
  image_rgb24 * img = NULL;

  handle = fopen (filename, "rb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  if (fseek (handle, 0, SEEK_END))
    fatal_errno ("cannot seek in %s", filename);

  size = ftell (handle);
  if (size == -1)
    fatal_errno ("cannot determine position in %s", filename);

  if (fseek (handle, 0, SEEK_SET))
    fatal_errno ("cannot seek in %s", filename);

  rawdata = (unsigned char *) malloc (size);
  if (!rawdata)
    fatal ("out of memory");

  count = fread (rawdata, 1, size, handle);
  if (count < size)
    fatal_errno ("cannot read %s", filename);

  /* detect + decode file format. */
  if (!img)
    img = in_lbm (rawdata, size, filename);

  if (!img)
    img = in_raw (rawdata, size, filename);

  free (rawdata);
  return img;
}

int save_image (const char * filename, const enum filetype type, 
                const image_rgb24 * img)
{
  int action = 0;

  if (type == img_raw)
    {
      if (img->img)
        {
          action = 1;
          msg (info, "writing raw image data (%dx%d)", img->width, img->height);
          out_raw (filename, img);
        }
    }
  else if (type == img_act)
    {
      if (img->pal)
        {
          action = 1;
          msg (info, "writing palette data (%d colours)", img->palcount);
          out_act (filename, img);
        }
    }
  else if ((type == img_c)
           || (type == img_raw_c))
    {
      char * include_file = "img.h";
      char * include_ptr = NULL;

      if (type == img_c)
        include_ptr = include_file;

      if ((img->pal) || (img->img))
        {
          action = 1;
          msg (info, "writing .c file");
          out_c (filename, img, include_ptr);
        }
    }
  else if ((type == img_h)
           || (type == img_raw_h))
    {
      char * include_file = "img.h";
      char * include_ptr = NULL;

      if (type == img_h)
        include_ptr = include_file;

      if ((img->pal) || (img->img))
        {
          action = 1;
          msg (info, "writing .h file");
          out_h (filename, img, include_ptr);
        }
    }
  else 
    return 0;

  /* no data to write. (i.e. img->img or img->pal point to NULL). */
  if (!action)
    msg (warning, "nothing to do");

  return 1;
}

int save_image_bgr15 (const char * filename, const enum filetype type, 
                      const image_bgr15 * img)
{
  int action = 0;

  if ((type == img_c)
      || (type == img_raw_c))
    {
      char * include_file = "img.h";
      char * include_ptr = NULL;

      if (type == img_c)
        include_ptr = include_file;

      if ((img->pal) || (img->img))
        {
          action = 1;
          msg (info, "writing .c file");
          out_c_bgr15 (filename, img, include_ptr);
        }
    }
  else if ((type == img_h)
           || (type == img_raw_h))
    {
      char * include_file = "img.h";
      char * include_ptr = NULL;

      if (type == img_h)
        include_ptr = include_file;

      if ((img->pal) || (img->img))
        {
          action = 1;
          msg (info, "writing .h file");
          out_h_bgr15 (filename, img, include_ptr);
        }
    }
  else 
    return 0;

  /* no data to write. (i.e. img->img or img->pal point to NULL). */
  if (!action)
    msg (warning, "nothing to do");

  return 1;
}

image_bgr15 * 
load_image_bgr15 (const char * filename)
{
  int i;
  image_rgb24 * img;
  image_bgr15 * img_bgr15 = NULL;

  img = load_image (filename);
  if (!img)
    return NULL;

  img_bgr15 = (image_bgr15 *) calloc (1, sizeof (image_bgr15));
  
  img_bgr15->width = img->width;
  img_bgr15->height = img->height;
  img_bgr15->palcount = img->palcount;
  img_bgr15->imgsize = img->imgsize;
  img_bgr15->img = img->img;

  img_bgr15->pal = (uint16_t *) calloc (sizeof (uint16_t), img_bgr15->palcount);
  for (i=0; i<img->palcount; i++)
    img_bgr15->pal[i] = BGR (img->pal[i*3+2], img->pal[i*3+1], img->pal[i*3+0]);

  img->img = NULL;
  free_image (img);

  return img_bgr15;
}
