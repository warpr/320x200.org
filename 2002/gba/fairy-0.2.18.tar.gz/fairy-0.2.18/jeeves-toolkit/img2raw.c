/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "img.h"
#include "err.h"

int
main (int argc, char ** argv)
{
  char * in_file;
  char * out_file;
  char * pal_file;
  char * ext_ptr1;
  char * ext_ptr2;
  image_rgb24 * img;
  
  msg_init (argv[0], stdout, info);

  if (argc > 1)
    in_file = argv[1];
  else 
    {
      /* help. */
      printf (PACKAGE " version " VERSION ".\n"
              "Copyright 2002 Kuno Woudt aka Warp^Bliss <warp-tmt@dds.nl>\n"
              "\n"
              "usage: img2raw infile [outfile] [palfile]\n\n");

      return 0;
    }

  if (argc > 2)
    out_file = argv[2];
  else
    if (in_file)
      {
        out_file = (char *) calloc (1, strlen (in_file) + 4);
        pal_file = (char *) calloc (1, strlen (in_file) + 4);
        
        strcpy (out_file, in_file);
        strcpy (pal_file, in_file);

        ext_ptr1 = strrchr (out_file, '.');
        ext_ptr2 = strrchr (pal_file, '.');

        if (!ext_ptr1)
          ext_ptr1 = strrchr (out_file, '\0');
        if (!ext_ptr2)
          ext_ptr2 = strrchr (pal_file, '\0');

        strcpy (ext_ptr1, ".raw");
        strcpy (ext_ptr2, ".act"); /* colours range from 0x00-0xFF. */
      }

  if (argc > 3)
    pal_file = argv[3];

  if (!strcmp (in_file, out_file))
    fatal ("input and output filename are identical");
  if (!strcmp (in_file, pal_file))
    fatal ("input and output filename are identical");
  if (!strcmp (out_file, pal_file))
    fatal ("output filenames are identical");

  img = load_image (in_file);
  if (!img)
    fatal ("unsupported file format");

  if (!save_image (out_file, img_raw, img))
    fatal ("unsupported file format");

  if (!save_image (pal_file, img_act, img))
    fatal ("unsupported file format");

  return 0;
}
