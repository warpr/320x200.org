/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file copying.txt; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

#include "err.h"

static char *programname = NULL;
static FILE *handle = NULL;
static int verbose = info;


static char *
basename (char *s)
{
  char *r;

  if ((r = strrchr (s, '/')))
    return r + 1;
  else if ((r = strrchr (s, '\\')))
    return r + 1;
  else
    return s;
}

void
msg_init (char * p, FILE * h, int v)
{
  programname = basename (p);
  handle = h;
  verbose = v;
}

void
msg (const int priority, const char *template, ...)
{
  if (priority <= verbose)
    {
      va_list ap;
     
      fprintf (handle, "%s: ", programname);
      va_start (ap, template);
      vfprintf (handle, template, ap);
      va_end (ap);
      fprintf (handle, "\n");
    }
}

void
fatal (const char *template, ...)
{
  va_list ap;

  /* fatal can be called before msg_init, so select stderr for this
     message and only print programname if it has been initialized. */
  if (!handle)
    handle = stderr;

  if (programname)
    fprintf (handle, "%s: ", programname);

  va_start (ap, template);
  vfprintf (handle, template, ap);
  va_end (ap);
  fprintf (handle, "\n");
  
  exit (1);
}

void
fatal_errno (const char *template, ...)
{
  va_list ap;

  /* fatal can be called before msg_init, so select stderr for this
     message and only print programname if it has been initialized. */
  if (!handle)
    handle = stderr;

  if (programname)
    fprintf (handle, "%s: ", programname);

  va_start (ap, template);
  vfprintf (handle, template, ap);
  va_end (ap);
  fprintf (handle, ": %s\n", strerror (errno));
  
  exit (1);
}

