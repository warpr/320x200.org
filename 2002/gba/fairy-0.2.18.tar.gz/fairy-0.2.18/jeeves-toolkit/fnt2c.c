/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "img.h"
#include "err.h"
#include "fnt.h"
#include "c.h"

#define MAX_DIGITS 0x40 /* NOTE: MAX_FONTS should fit in this. */

int
main (int argc, char ** argv)
{
  int i;

  /* 0 = input, 1 = output .c file, 2 = output header file. */
  char * files[3] = { NULL, NULL, NULL };
  char * cfile;
  int cfile_size;
  char * hfile;
  int hfile_size;
  char * ext_ptr;
  char * ext_ptr2;
  image_rgb24 * img;
  typeface ** fnts;

  int hlp = 0;
  int use_struct = 0;
  int use_gba = 0;
  int filecount = 0;
  int auto_number = 0;
  int count;
  
  msg_init (argv[0], stdout, info);

  for (i=1; i<argc; i++)
    {
      if (!strcmp (argv[i], "--help")) hlp = 1;
      else if (!strcmp (argv[i], "--struct")) use_struct = 1;
      else if (!strcmp (argv[i], "--gba")) use_gba = 1;
      else files[filecount++] = argv[i];
    }

  if ((hlp) || (filecount==0))
    {
      /* help. */
      printf (PACKAGE " version " VERSION ".\n"
              "Copyright 2002 Kuno Woudt aka Warp^Bliss <warp-tmt@dds.nl>\n"
              "\n"
              "usage: fnt2c [options] infile [c file] [header file]\n"
              "\noptions:\n\n"
              "\t--struct\tuse struct as defined in fnt.h\n"
              "\t--gba   \toutput 16bit palette and character data\n"
              "\n");

      return 0;
    }

  if (filecount <= 1)
    {
      files[1] = (char *) calloc (1, strlen (files[0]) + 4);
      strcpy (files[1], files[0]);

      ext_ptr = strrchr (files[1], '.');
      if (!ext_ptr)
        ext_ptr = strrchr (files[1], '\0');

      strcpy (ext_ptr, ".c");
    }

  if (filecount <= 2)
    {
      files[2] = (char *) calloc (1, strlen (files[1]) + 4);
      strcpy (files[2], files[1]);

      ext_ptr = strrchr (files[2], '.');
      if (!ext_ptr)
        ext_ptr = strrchr (files[2], '\0');

      strcpy (ext_ptr, ".h");
    }

  if (!strcmp (files[0], files[1]))
    fatal ("input and output filename are identical");
  if (!strcmp (files[0], files[2]))
    fatal ("input and output filename are identical");
  if (!strcmp (files[1], files[2]))
    fatal ("output filenames are identical");

  img = load_image (files[0]);
  if (!img)
    fatal ("unsupported file format");

  if (use_gba)
    fnts = decode_fonts (img, FNT_16BIT);
  else
    fnts = decode_fonts (img, 0);

  if (!fnts[0])
    fatal ("no fonts detected");

  if (fnts[1])
    auto_number = 1;

  if (auto_number)  /* more then 1 font in file. */
    {
      cfile = calloc (1, strlen (files[1]) + MAX_DIGITS); 
      cfile_size = strlen (files[1]) + MAX_DIGITS;
      hfile = calloc (1, strlen (files[2]) + MAX_DIGITS); 
      hfile_size = strlen (files[2]) + MAX_DIGITS;

      ext_ptr = strrchr (files[1], '.');
      if (!ext_ptr)
        ext_ptr = NULL;
      else
        *ext_ptr++ = '\0';
            
      ext_ptr2 = strrchr (files[2], '.');
      if (!ext_ptr2)
        ext_ptr2 = NULL;
      else
        *ext_ptr2++ = '\0';
    }
  else
    {
      cfile = calloc (1, strlen (files[1])); 
      strcpy (cfile, files[1]);
      hfile = calloc (1, strlen (files[2])); 
      strcpy (hfile, files[2]);
    }

  count = 0;
  fnts--;
  while (*(++fnts))
    {
      if (auto_number)
        {
          if (ext_ptr)
            snprintf (cfile, cfile_size, "%s_%d.%s", files[1], count, ext_ptr);
          else
            snprintf (cfile, cfile_size, "%s_%d", files[1], count);
          
          if (ext_ptr2)
            snprintf (hfile, hfile_size, "%s_%d.%s", files[2], count, ext_ptr2);
          else
            snprintf (hfile, hfile_size, "%s_%d", files[2], count);
        }

      if (use_struct)
        {
          out_fnt_c (cfile, fnts[0], "fnt.h");
          out_fnt_h (hfile, fnts[0], "fnt.h");
        }
      else
        {
          out_fnt_c (cfile, fnts[0], NULL);
          out_fnt_h (hfile, fnts[0], NULL);
        }
      msg (info, "wrote %s and %s", cfile, hfile);
      
      count++;
    }

  fprintf (stderr, "wrote %d fonts.\n", count);

  /* FIXME: there's some calloc's which still need to be freed. */

  return 0;
}
