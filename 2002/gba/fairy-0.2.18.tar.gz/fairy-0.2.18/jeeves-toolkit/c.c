/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

/* FIXME: hmm, should I really have to check all the fprintf's for errors? */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "err.h"
#include "img.h"
#include "fnt.h"

/* ===[ strchrII ]==========================================================
  
   > strrchr which returns pointer after character if found, or pointer to
   start of string if c not found.
   
   ========================================================================= */
static const char *
strchrII (const char *s, const char c)
{
  char *t;

  return ((t = strrchr (s, c)) == NULL ? s : t + 1);
}

/* ===[ bin2h_basename ]====================================================
  
   > format filenames.
   > (the returned value is calloc()ed, so please free() it).
   
   ========================================================================= */
static char *
bin2h_basename (const char *filename)
{
  char *ptr;
  char *basename;

  basename = (char *) calloc (1, strlen (filename) + 1);

  strcpy (basename, strchrII (filename, '/'));

  if ((ptr = strrchr (basename, '.')))
    *ptr = '\0';

  ptr = basename;

  if (!((*ptr >= 'a' && *ptr <= 'z') || (*ptr >= 'A' && *ptr <= 'Z')))
    fatal ("filename should start with a character from A-Z or a-z");

  while (*(++ptr))
    if (!((*ptr >= 'a' && *ptr <= 'z') 
          || (*ptr >= 'A' && *ptr <= 'Z')
          || (*ptr >= '0' && *ptr <= '9')))
      *ptr = '_';

  return basename;
}

/* ===[ bin2h_NAME ]========================================================
  
   > format filenames.
   > (the returned value is calloc()ed, so please free() it).
   
   ========================================================================= */
static char *
bin2h_NAME (const char *filename)
{
  char *NAME = bin2h_basename (filename);
  char *ptr = NAME;

  *ptr = toupper (*ptr);

  while (*(++ptr))
    *ptr = toupper (*ptr);

  return NAME;
}

/* ===[ bin2h_name ]========================================================
  
   > format filenames.
   > (the returned value is calloc()ed, so please free() it).
   
   ========================================================================= */
static char *
bin2h_name (const char *filename)
{
  char *name = bin2h_basename (filename);
  char *ptr = name;

  *ptr = tolower (*ptr);

  while (*(++ptr))
    *ptr = tolower (*ptr);

  return name;
}

/* ===[ bin2h_banner ]======================================================
  
   > banner for .c and .h files.
   
   ========================================================================= */
static int
bin2h_banner (FILE * out, const char *file)
{
  return fprintf (out, "/*\n  %s\n  (converted by %s %s)\n*/\n\n",
                  file, PACKAGE, VERSION);
}

/* ===[ bin2h_guard ]===[ bin2h_unguard ]===================================
  
   > #define protection for .h file
   
   ========================================================================= */
static int
bin2h_guard (FILE * out, const char *header)
{
  return fprintf (out, "#ifndef %s%s\n#define %s%s\n\n",
                  header, "_H", header, "_H");
}

static int
bin2h_unguard (FILE * out, const char *header)
{
  return fprintf (out, "\n#endif /* %s%s */\n", header, "_H");
}

/* ===[ bin2h_define ]======================================================
  
   > #define stuff in the .h file.
   
   ========================================================================= */
static int
bin2h_define (FILE * out, const char *header, const char *define,
              const int val)
{
  return fprintf (out, "#define %s_%s %d\n", header, define, val);
}

/* ===[ bin2h_include ]======================================================
  
   > #include stuff in the .c file.
   
   ========================================================================= */
static int
bin2h_system_include (FILE * out, const char *hfile)
{
  return fprintf (out, "#include <%s>\n", hfile);
}

static int
bin2h_include (FILE * out, const char *hfile)
{
  return fprintf (out, "#include \"%s\"\n", hfile);
}

/* ===[ bin2h_image_rgb24 ]=================================================
  
   > fill the contents of a struct in the .c file.
     FIXME: er. this is silly, I should just give it an image_rgb24 *.

   ========================================================================= */
static void
bin2h_image_rgb24 (FILE * out, const char *name, const int width,
                   const int height, const int palcount,
                   const char *palette, const int imgsize,
                   const char *imgdata)
{
  fprintf (out, "image_rgb24 %s = \n  {\n    %d,\n    %d,\n",
           name, width, height);

  if (palcount)
    fprintf (out, "    %d,\n    %s_%s,\n", palcount, name, palette);
  else
    fprintf (out, "    0,\n    NULL,\n");

  if (imgsize)
    fprintf (out, "    %d,\n    %s_%s,\n", imgsize, name, imgdata);
  else
    fprintf (out, "    0,\n    NULL,\n");

  fprintf (out, "  };\n");
}

static int
bin2h_image_rgb24_h (FILE * out, const char *infile)
{
  return fprintf (out, "extern image_rgb24 %s;\n", infile);
}
/* ===[ bin2h_image_rgb24 ]=================================================
  
   > fill the contents of a struct in the .c file.
     FIXME: er. this is silly, I should just give it an image_rgb24 *.

   ========================================================================= */
static void
bin2h_image_bgr15 (FILE * out, const char *name, const int width,
                   const int height, const int palcount,
                   const char *palette, const int imgsize,
                   const char *imgdata)
{
  fprintf (out, "image_bgr15 %s = \n  {\n    %d,\n    %d,\n",
           name, width, height);

  if (palcount)
    fprintf (out, "    %d,\n    (uint16_t *) %s_%s,\n", palcount, name, palette);
  else
    fprintf (out, "    0,\n    NULL,\n");

  if (imgsize)
    fprintf (out, "    %d,\n    %s_%s,\n", imgsize, name, imgdata);
  else
    fprintf (out, "    0,\n    NULL,\n");

  fprintf (out, "  };\n");
}

static int
bin2h_image_bgr15_h (FILE * out, const char *infile)
{
  return fprintf (out, "extern image_bgr15 %s;\n", infile);
}

/* ===[ bin2h_typeface ]====================================================
  
   > fill the contents of a struct in the .c file.
   
   ========================================================================= */
static void
bin2h_typeface (FILE * out, const char *name, const typeface * fnt)
{
  fprintf (out, "typeface %s = \n  {\n    %d,\n    %d,\n"
           "    %d,\n    %d,\n    %d,\n",
           name, fnt->width, fnt->height, fnt->ascii, fnt->colour, fnt->count);
  
  if (fnt->charx)
    fprintf (out, "    %s_%s,\n", name, "charx");
  else
    fprintf (out, "    NULL,\n");

  fprintf (out, "    %s_%s,\n", name, "data");
  
  fprintf (out, "  };\n");
}

static int
bin2h_typeface_h (FILE * out, const char *infile)
{
  return fprintf (out, "extern typeface %s;\n", infile);
}

/* ===[ bin2h_unsigned_char ]===============================================
  
   > write unsigned char array to .c file.
   
   ========================================================================= */
static void
bin2h_unsigned_char_dim (FILE * out, const char *infile, const char *name,
                         const unsigned char *data, const int size,
                         const int x, const int y)
{
  int col = 0;
  int row = 0;
  int i;

  fprintf (out, "unsigned char %s_%s[] = \n  {", infile, name);

  for (i = 0; i < size; i++)
    {
      if (!col--)
        {
          if (y)
            if (!row--)
              {
                fprintf (out, "\n");
                row = y;
              }

          fprintf (out, "\n    ");
          col = x;
        }

      fprintf (out, "0x%02x, ", data[i]);
    }

  fprintf (out, "\n  };\n\n");
}

static void
bin2h_unsigned_char (FILE * out, const char *infile, const char *name,
                     const unsigned char *data, const int size)
{
  bin2h_unsigned_char_dim (out, infile, name, data, size, 10, 0);
}

static int
bin2h_unsigned_char_h (FILE * out, const char *infile, const char *name)
{
  return fprintf (out, "extern unsigned char %s_%s[];\n", infile, name);
}

int
out_c (const char *filename, const image_rgb24 * img, const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);

  if (include)
    {
      bin2h_include (handle, include);
      fprintf (handle, "\n");
    }

  if (img->img)
    {
      bin2h_unsigned_char (handle, name, "data", img->img, img->imgsize);
      fprintf (handle, "\n");
    }
  if (img->pal)
    bin2h_unsigned_char (handle, name, "palette", img->pal,
                         (img->palcount) * 3);

  if (include)
    {
      bin2h_image_rgb24 (handle, name, img->width, img->height, 
                         (img->pal) ? img->palcount : 0, "palette", 
                         (img->img) ? img->imgsize : 0, "data");
    }

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}

int
out_h (const char *filename, const image_rgb24 * img, const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);
  bin2h_guard (handle, NAME);

  if (include)
    {
      bin2h_include (handle, include);
      fprintf (handle, "\n");
      bin2h_image_rgb24_h (handle, name);
    }
  else
    {
      if (img->img)
        {
          bin2h_define (handle, NAME, "WIDTH", img->width);
          bin2h_define (handle, NAME, "HEIGHT", img->height);
          bin2h_define (handle, NAME, "SIZE", img->imgsize);
          bin2h_unsigned_char_h (handle, name, "data");

          fprintf (handle, "\n");

        }

      if (img->pal)
        {
          bin2h_define (handle, NAME, "PALCOUNT", img->palcount);
          bin2h_unsigned_char_h (handle, name, "palette");
        }
    }

  bin2h_unguard (handle, NAME);

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}

int
out_c_bgr15 (const char *filename, const image_bgr15 * img, 
             const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);

  if (include)
    {
      bin2h_include (handle, "types.h");
      bin2h_include (handle, include);
      fprintf (handle, "\n");
    }

  if (img->img)
    {
      bin2h_unsigned_char (handle, name, "data", img->img, img->imgsize);
      fprintf (handle, "\n");
    }
  if (img->pal)
    bin2h_unsigned_char (handle, name, "palette", (unsigned char *) img->pal,
                         (img->palcount) * 2);

  if (include)
    {
      bin2h_image_bgr15 (handle, name, img->width, img->height, 
                         (img->pal) ? img->palcount : 0, "palette", 
                         (img->img) ? img->imgsize : 0, "data");
    }

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}

int
out_h_bgr15 (const char *filename, const image_bgr15 * img, 
             const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);
  bin2h_guard (handle, NAME);

  if (include)
    {
      bin2h_include (handle, include);
      fprintf (handle, "\n");
      bin2h_image_bgr15_h (handle, name);
    }
  else
    {
      if (img->img)
        {
          bin2h_define (handle, NAME, "WIDTH", img->width);
          bin2h_define (handle, NAME, "HEIGHT", img->height);
          bin2h_define (handle, NAME, "SIZE", img->imgsize);
          bin2h_unsigned_char_h (handle, name, "data");

          fprintf (handle, "\n");

        }

      if (img->pal)
        {
          bin2h_define (handle, NAME, "PALCOUNT", img->palcount);
          bin2h_unsigned_char_h (handle, name, "palette");
        }
    }

  bin2h_unguard (handle, NAME);

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}

int
out_fnt_c (const char *filename, const typeface * fnt, const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);

  if (include)
    {
      bin2h_system_include (handle, "stddef.h");
      bin2h_include (handle, include);
      fprintf (handle, "\n");
    }

  if (fnt->charx)
    {
      bin2h_unsigned_char (handle, name, "charx", fnt->charx, fnt->count);
      fprintf (handle, "\n");
    }

  bin2h_unsigned_char_dim (handle, name, "data", fnt->data, 
                           fnt->count * fnt->width * fnt->height,
                           (fnt->width-1) % 10, (fnt->height-1));
  fprintf (handle, "\n");

  if (include)
    bin2h_typeface (handle, name, fnt);

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}

int
out_fnt_h (const char *filename, const typeface * fnt, const char *include)
{
  FILE *handle;
  char *NAME = bin2h_NAME (filename);
  char *name = bin2h_name (filename);

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  bin2h_banner (handle, filename);
  bin2h_guard (handle, NAME);

  if (include)
    {
      bin2h_include (handle, include);
      fprintf (handle, "\n");
      bin2h_typeface_h (handle, name);
    }
  else
    {
      bin2h_define (handle, NAME, "WIDTH", fnt->width);
      bin2h_define (handle, NAME, "HEIGHT", fnt->height);
      bin2h_define (handle, NAME, "ASCII", fnt->ascii);
      bin2h_define (handle, NAME, "COLOUR", fnt->colour);
      bin2h_define (handle, NAME, "COUNT", fnt->count);

      if (fnt->charx)
        bin2h_unsigned_char_h (handle, name, "charx");

      bin2h_unsigned_char_h (handle, name, "data");
      fprintf (handle, "\n");
    }

  bin2h_unguard (handle, NAME);

  fclose (handle);
  free (NAME);
  free (name);

  return 1;
}
