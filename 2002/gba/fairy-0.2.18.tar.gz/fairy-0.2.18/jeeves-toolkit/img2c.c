/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "img.h"
#include "err.h"

int
main (int argc, char ** argv)
{
  int i;

  /* 0 = input, 1 = output .c file, 2 = output header file. */
  char * files[3] = { NULL, NULL, NULL };
  char * ext_ptr;
  image_rgb24 * img;
  image_bgr15 * img15;

  int hlp = 0;
  int use_struct = 0;
  int use_gba = 0;
  int filecount = 0;
  
  msg_init (argv[0], stdout, info);

  for (i=1; i<argc; i++)
    {
      if (!strcmp (argv[i], "--help")) hlp = 1;
      else if (!strcmp (argv[i], "--struct")) use_struct = 1;
      else if (!strcmp (argv[i], "--gba")) use_gba = 1;
      else files[filecount++] = argv[i];
    }

  if ((hlp) || (filecount==0))
    {
      /* help. */
      printf (PACKAGE " version " VERSION ".\n"
              "Copyright 2002 Kuno Woudt aka Warp^Bliss <warp-tmt@dds.nl>\n"
              "\n"
              "usage: img2c [options] infile [c file] [header file]\n\n"
              "options:\n\n"
              "\t--struct\tuse struct as defined in img.h\n"
              "\t--gba   \toutput 16bit palette data\n"
              "\n");

      return 0;
    }

  if (filecount <= 1)
    {
      files[1] = (char *) calloc (1, strlen (files[0]) + 4);
      strcpy (files[1], files[0]);

      ext_ptr = strrchr (files[1], '.');
      if (!ext_ptr)
        ext_ptr = strrchr (files[1], '\0');

      strcpy (ext_ptr, ".c");
    }

  if (filecount <= 2)
    {
      files[2] = (char *) calloc (1, strlen (files[1]) + 4);
      strcpy (files[2], files[1]);

      ext_ptr = strrchr (files[2], '.');
      if (!ext_ptr)
        ext_ptr = strrchr (files[2], '\0');

      strcpy (ext_ptr, ".h");
    }

  if (!strcmp (files[0], files[1]))
    fatal ("input and output filename are identical");
  if (!strcmp (files[0], files[2]))
    fatal ("input and output filename are identical");
  if (!strcmp (files[1], files[2]))
    fatal ("output filenames are identical");

  if (use_gba)
    {
      img15 = load_image_bgr15 (files[0]);
      if (!img15)
        fatal ("unsupported file format");

      if (use_struct)
        {
          if (!save_image_bgr15 (files[1], img_c, img15)) fatal ("unsupported file format");
          if (!save_image_bgr15 (files[2], img_h, img15)) fatal ("unsupported file format");
        }
      else
        {
          if (!save_image_bgr15 (files[1], img_raw_c, img15)) fatal ("unsupported file format");
          if (!save_image_bgr15 (files[2], img_raw_h, img15)) fatal ("unsupported file format");
        }
    }
  else
    {
      img = load_image (files[0]);
      if (!img)
        fatal ("unsupported file format");

      if (use_struct)
        {
          if (!save_image (files[1], img_c, img)) fatal ("unsupported file format");
          if (!save_image (files[2], img_h, img)) fatal ("unsupported file format");
        }
      else
        {
          if (!save_image (files[1], img_raw_c, img)) fatal ("unsupported file format");
          if (!save_image (files[2], img_raw_h, img)) fatal ("unsupported file format");
        }
    }

  /* FIXME: there's some calloc's which still need to be freed. */

  return 0;
}
