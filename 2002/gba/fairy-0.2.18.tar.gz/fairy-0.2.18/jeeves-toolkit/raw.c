/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "img.h"
#include "err.h"

image_rgb24 * 
in_raw (const unsigned char * data, const int size,
        const char * filename)
{
  image_rgb24 * img;

  img = (image_rgb24 *) calloc (1, sizeof (image_rgb24));
  if (!img)
    fatal ("out of memory");

  img->img = NULL; /* according to ANSI-C calloc doesn't get */
  img->pal = NULL; /* me NULL pointers on some systems :(    */

  switch (size)
    {
    case (240*160):
      img->width = 240;
      img->height = 160;
      break;

    case (320*200):
      img->width = 320;
      img->height = 200;
      break;

    case (640*480):
      img->width = 640;
      img->height = 480;
      break;

    case (128*128):
      img->width = 128;
      img->height = 128;
      break;

    case (256*256):
      img->width = 256;
      img->height = 256;
      break;

    case (3*256):
      img->palcount = 256;
      break;

    case (3*16):
      img->palcount = 16;
      break;

    default:
      msg (error, "cannot guess image dimensions");
      free (img);
      return NULL;
    }

  if (img->palcount)
    {
      const char * ext_ptr;
      int i;

      img->pal = (unsigned char *) malloc (size);
      if (!img->pal)
        fatal ("out of memory");

      memcpy (img->pal, data, size);

      /* .pal colours range from 0x00 - 0x3F. */
      /* .act colours range from 0x00 - 0xFF. */
      ext_ptr = strrchr (filename, '.');
      if (!strcmp (ext_ptr, ".pal"))
        for (i=0; i<(img->palcount * 3); i++)
          img->pal[i] = img->pal[i]<<2;
    }
  else
    {
      img->img = (unsigned char *) malloc (size);
      if (!img->img)
        fatal ("out of memory");

      memcpy (img->img, data, size);
      img->imgsize = (img->width)*(img->height);
    }

  return img;
}

int
out_raw (const char * filename, const image_rgb24 * img)
{
  FILE * handle;
  int size;

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  size = fwrite (img->img, 1, img->imgsize, handle);
  if (size != img->imgsize)
    {
      fclose (handle);
      fatal_errno ("error writing to %s (%d bytes written)", filename, size);
    }

  if (fclose (handle))
    fatal_errno ("cannot close %s", filename);

  return 1;
}

int
out_act (const char * filename, const image_rgb24 * img)
{
  FILE * handle;
  int size;

  handle = fopen (filename, "wb");
  if (!handle)
    fatal_errno ("cannot open %s", filename);

  size = fwrite (img->pal, 1, (img->palcount * 3), handle);
  if (size != (img->palcount * 3))
    {
      fclose (handle);
      fatal_errno ("error writing to %s (%d bytes written)", filename, size);
    }

  if (fclose (handle))
    fatal_errno ("cannot close %s", filename);

  return 1;
}
