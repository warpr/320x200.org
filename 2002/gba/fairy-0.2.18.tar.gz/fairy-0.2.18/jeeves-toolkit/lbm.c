/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "img.h"
#include "err.h"

/* =========================================================================
   WARNING: this is a messy old lbm decoder I wrote some time ago :) 
   comments might be incorrect and in general it's not written very well.

   -- warp
   ========================================================================= */

/* I don't think this so-called `type-punning' stuff is allowed in ANSI-C, 
   but i'm in a hurry and cannot be bothered to fix it -- warp. */

/* iff/ilbm chunk header */
union iff_chunk
{
  unsigned char buffer[8];
  struct 
  {
    char ID[4];             /* type of data in this chunk */
    unsigned char size[4];  /* size of data in this chunk */
  } chunk;
} __attribute__ ((packed));


/* iff/ilbm bitmap header */
union iff_BMHD
{
  unsigned char buffer[20];
  struct
  {                                /* byte offset */
    unsigned char width[2];                 /*  0 */
    unsigned char height[2];                /*  2 */
    char x[2];                              /*  4 */
    char y[2];                              /*  6 */
    unsigned char nPlanes;                  /*  8 */
    unsigned char Masking;                  /*  9 */
    unsigned char RLE;                      /* 10 */
    unsigned char pad1;                     /* 11 */
    unsigned char trColor[2];               /* 12 */
    unsigned char xAspect;                  /* 14 */
    unsigned char yAspect;                  /* 15 */
    char pagewidth[2];                      /* 16 */
    char pageheight[2];                     /* 18 */
  } bmhd;                                   /* 20 */
} __attribute__ ((packed));


/* ===[ iff_chunk_eq ]======================================================
  
   > compares the iff CHUNK id with a given string.
   
   .        chunk               4 chars.
   :        id                  4 chars.

   ========================================================================= */
static int
iff_chunk_eq (const char* chunk, const char* id)
{
  return (chunk[0]==id[0]) 
    && (chunk[1]==id[1])
    && (chunk[2]==id[2])
    && (chunk[3]==id[3]);
}

/* FIXME: isn't this little-endian?  i'm always confusing the two :) */

/* ===[ get_xxbit_big_endian_int ]==========================================
  
   > convert a 16bit or 32bit big-endian value to an int.
   
   .        word                2 unsigned chars (16bit big-endian int)
   .        dword               4 unsigned chars (32bit big-endian int)

   ========================================================================= */
static int 
get_16bit_big_endian_int (const unsigned char * word)
{ 
  return (word[0] << 0x08)
    | (word[1] << 0x00);
}

static int 
get_32bit_big_endian_int (const unsigned char * dword)
{ 
  return (dword[0] << 0x18)
    | (dword[1] << 0x10)
    | (dword[2] << 0x08)
    | (dword[3] << 0x00); 
}

/* ===[ decode_lbm ]========================================================
  
   > decode lbm and output raw image data or palette data.
   
   .        in          the lbm file.
   :        size        input buffer/file size.

   ========================================================================= */
static image_rgb24 * 
decode_lbm (const unsigned char * in, const int insize)
{
  int rle;
  int x, y, bpp;
  int size;
  int pad;

  const unsigned char * inptr = in;
  image_rgb24 * img;

  int bodycount;
  int tmpcount;
  char bodyrun;
  unsigned char bodyblok;

  union iff_chunk chunk;
  union iff_BMHD bmhd;

  int BMHD = 0;  /* has the header       been found and decoded? */
  int CMAP = 0;  /* has the palette      been found and decoded? */
  int BODY = 0;  /* has the picture data been found and decoded? */

  img = (image_rgb24 *) calloc (1, sizeof (image_rgb24));
  if (!img)
    fatal ("out of memory");

  img->img = NULL; /* according to ANSI-C calloc doesn't get */
  img->pal = NULL; /* me NULL pointers on some systems :(    */

  while ((!(CMAP && BODY))
         && (inptr < (in+insize)))
    {
      memcpy (chunk.buffer, inptr, sizeof (chunk.buffer));
      inptr += sizeof (chunk.buffer);              

      size = get_32bit_big_endian_int (chunk.chunk.size);
      pad = size % 2; 

      /* ===================================================================
         FORM CHUNK
         =================================================================== */
      if (iff_chunk_eq (chunk.chunk.ID, "FORM"))
        {
          memcpy (chunk.buffer, inptr, 4);
          inptr += 4;

          /* if this form d
             FORM chunk (I suppose this skips to EOF for most files). */
          if ((!iff_chunk_eq (chunk.chunk.ID, "PBM "))
              && (!iff_chunk_eq (chunk.chunk.ID, "ILBM")))
            inptr+=(size+pad-4);
        }

      /* ===================================================================
         BMHD CHUNK
         =================================================================== */
      else if (iff_chunk_eq (chunk.chunk.ID, "BMHD"))
        {
          /* BMHD chunk found, init image info */
          memcpy (bmhd.buffer, inptr, sizeof (bmhd.buffer));
          inptr += sizeof (bmhd.buffer);

          bpp = 8; /* I don't support anything else :) */
          x = get_16bit_big_endian_int (bmhd.bmhd.width);
          y = get_16bit_big_endian_int (bmhd.bmhd.height);

          img->width = x;
          img->height = y;
          img->imgsize = (x*y);

          rle = (bmhd.bmhd.RLE==1);

          msg (info, "found BMHD (%dx%d:%d, nPlanes: %d, Masking: %d, rle: %d)", 
               x, y, bpp, bmhd.bmhd.nPlanes, bmhd.bmhd.Masking, rle);

          if (bmhd.bmhd.nPlanes!=8)
            fatal ("fileformat not supported (wrong number of bitplanes)");

          if (bmhd.bmhd.Masking == 1)
            fatal ("fileformat not supported (please deactivate stencil before saving)");

          BMHD = 1;
        }

      /* ===================================================================
         CMAP CHUNK
         =================================================================== */
      else if (iff_chunk_eq (chunk.chunk.ID, "CMAP"))
        {
          /* CMAP chunk found, init Palette */
          if (BMHD) /* ignore any CMAPs without preceding BMHD chunks */
            {
              msg (info, "decoding CMAP");

              img->pal = (unsigned char *) malloc (size);
              if (!img->pal)
                fatal ("cannot allocate memory.");
              
              memcpy (img->pal, inptr, size);
              img->palcount = (size/3);
              
              CMAP = 1;
            }

          inptr += (size+pad);
        }

      /* ===================================================================
         BODY CHUNK
         =================================================================== */
      else if (iff_chunk_eq (chunk.chunk.ID, "BODY"))
        {
          /* BODY chunk found, load data */
          if (BMHD) /* ignore any BODY chunks without preceding BMHD chunks */
            {
              msg (info, "decoding BODY");

              img->img = (unsigned char *) malloc (x*y);
              if (!img->img)
                fatal ("cannot allocate memory.");

              if (rle)
                {
                  bodycount = 0;

                  while (bodycount < (x*y))
                    {
                      bodyrun = *inptr++;

                      if (bodyrun!=-128)
                        {
                          if (bodyrun>=0)
                            {
                              tmpcount = bodyrun + 1;
                              if ((tmpcount + bodycount) > (x*y))
                                tmpcount = x*y - bodycount;

                              memcpy (img->img+bodycount, inptr, tmpcount);

                              /* yes. there is too much counting going on.
                                 but there is lots of stuff wrong with all
                                 of this, and i'm in no mood to fix things.
                                 -- warp. */
                              inptr+=tmpcount;
                              bodycount+=tmpcount;
                            }
                          else /* (bodyrun<0) && (bodyrun != -128) */
                            {
                              bodyblok = *inptr++;
                              
                              tmpcount = 1-bodyrun;
                              if ((tmpcount + bodycount) > (x*y))
                                tmpcount = x*y - bodycount;

                              memset (img->img + bodycount, bodyblok, tmpcount);
                              bodycount += tmpcount;
                            }
                        }
                    }
                }
              else /* !rle */
                {
                  int i;
                  unsigned char * imgptr;
                  
                  imgptr = img->img;

                  for (i=0; i<y; i++)
                    {
                      memcpy (imgptr, inptr, x);
                      imgptr+=x;
                      inptr+=x;

                      if (x&1)
                        inptr++;
                    }
                }
              
              BODY = 1;

              inptr += pad;
            }
          else
            inptr += (size+pad);
        }

      /* ===================================================================
         unknown CHUNK
         =================================================================== */
      else /* chunk.ID not recognized. */
        {
          msg (debug, "skipping unknow chunk: %c%c%c%c",
               chunk.chunk.ID[0], chunk.chunk.ID[1], 
               chunk.chunk.ID[2], chunk.chunk.ID[3]);

          inptr += (size+pad);
        }
    }
  
  return img;
}

image_rgb24 * 
in_lbm (const unsigned char * data, const int size,
        const char * filename)
{
  if (iff_chunk_eq ((char *) data, "FORM"))
    return decode_lbm (data, size);
  else
    return NULL;
}

