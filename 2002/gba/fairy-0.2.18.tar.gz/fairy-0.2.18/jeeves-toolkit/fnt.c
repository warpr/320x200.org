/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <stdlib.h>
#include <stdint.h>

#include "err.h"
#include "img.h"
#include "fnt.h"

#define MAX_FONTS 0x10  /* max amount of fonts in an image. */
#define MAX_CHARS 0x100 /* max amount of characters in a font. */

static typeface * fonts[MAX_FONTS];

/* 
 [input]	
	
    The typeface decoder  expects fonts in  an 8bpp indexed mode buffer.
    In  order  for the  decoder to  automatically  grab any font  in the 
    buffer and determine the dimensions  and colours used by those fonts
    it has to know a few things about the font.

    First it  needs to know  which colours mark  the top-left and lower-
    right of a character: the colour index which marks the top-left of a
    character should  be placed  at the first pixel  in the buffer;  the
    colour  which marks  the lower-right  should be  placed at  the next 
    pixel, and so on - here's a list:

      buffer[0]       - this colour marks bottom-right of character
      buffer[1]       - this colour marks top-left of character
      buffer[2]       - this colour marks the background colour
                        (i.e. transparent parts)
      buffer[3]       - this is the colour used by single colour fonts
      buffer[4]       - this colour, and any colours following are the
                        colours used by multi-coloured fonts.
      buffer[n]       - a pixel with the same value as buffer[size-3] 
                        (the background colour marks the end of the 
                         list of colours used by multi-coloured fonts)

    Every other colour encountered in the buffer will be treated similar
    to the background c   olour - i.e. they will be treated as  transparent
    and not end up in the font.
*/

int
is_bg(const uint8_t c, const uint8_t bg, const uint8_t * colours)
{
  int r = 1;

  colours--;

  while (*(++colours) != bg)
    r = r && (c != *colours);

  return r;
}


void
decode_font (typeface * tmp, uint8_t ** bufptr, uint8_t ** endptr,
             const uint8_t * bufend, const uint16_t pitch, 
             const uint8_t * topleft, const int flags)
{
  const uint8_t end = topleft[1];
  const uint8_t start = topleft[0];
  const uint8_t bg = topleft[2];
/*   const uint8_t mono = topleft[3]; */
  const uint8_t * mc = &topleft[3]; /* also use the mono colour in is_bg() */
  const uint16_t charsize = tmp->width*tmp->height;

  uint8_t * dataptr;
  uint8_t * charptr;
  uint8_t * tmpptr;

  int x;
  int y;

  *endptr = *bufptr + ((tmp->height+1)*pitch+(tmp->width+1));

  tmp->data = (uint8_t *) calloc (MAX_CHARS, charsize);
  dataptr = tmp->data;

  while ((*(*endptr) == end) /* new font, character dimensions changed. */
         && ((*endptr) < bufend)) /* no more fonts. */
    {
      /* copy current char. */
      for (y=0; y<tmp->height; y++)
        {
          charptr = *bufptr + (y+1)*pitch + 1;

          for (x=0; x<tmp->width; x++)
            {
              *dataptr++ = is_bg(*charptr, bg, mc) ? 0 : *charptr;
              charptr++;
            }
          if ((flags & FNT_16BIT) && (tmp->width & 1))
            *dataptr++ = 0;
        }  
      tmp->count++;

      /* find next char. */
      charptr = *bufptr;
      while ((*(++charptr) != start) && (charptr < bufend));
      tmpptr = charptr + ((tmp->height+1)*pitch+(tmp->width+1));

      if ((tmpptr < bufend) && (*tmpptr != end))
        { 
          (*bufptr)++; /* new font, character dimensions changed. */
          (*endptr)++;
        }
      else
        {
          *bufptr = charptr;
          *endptr = tmpptr;
        }
    }

  if (!tmp->count)
    {
      free (tmp->data);
      tmp->data = NULL;
    }

  /* assume fonts with a character count near 128 are (almost) a complete
     7bit ascii font, assume fonts with less characters start with a space. */
  if (tmp->count < 120)
    tmp->ascii = ' '; 

  if ((flags & FNT_16BIT) && (tmp->width & 1))
    tmp->width++;
}


/* NOTE: this updates bufptr too. */
static typeface *
find_fonts (uint8_t ** bufptr, uint8_t ** endptr, const uint8_t * bufend, 
             const uint16_t pitch, const uint8_t * topleft, const int flags)
{
  const uint8_t end = topleft[1];
  const uint8_t start = topleft[0];

  uint32_t char_start;
  uint32_t char_end;

  typeface * tmp = (typeface *) calloc (1, sizeof (typeface));
  if (!tmp)
    fatal ("out of memory");

  tmp->charx = NULL;
  tmp->data = NULL;

  while (((*bufptr)++ < bufend)
         && (!(tmp->data)))
    if (*(*bufptr) == start)
      {
        char_start = (*bufptr) - topleft;

        while (((*endptr)++ < bufend) && (*(*endptr) != end));

        if ((*endptr) < bufend)
          {
            uint16_t x;
            uint16_t y;

            char_end = (*endptr) - topleft;

            x = char_end % pitch - char_start % pitch - 1;
            y = char_end / pitch - char_start / pitch - 1;

            if ((x > 0x100) || (y > 0x100))
              fatal ("invalid input file, character too large (%dx%d)", x, y);

            if ((x != tmp->width) || (y != tmp->height))
              {
                tmp->width = x;
                tmp->height = y;

                decode_font (tmp, bufptr, endptr, bufend, pitch, 
                             topleft, flags);
              }
            else
              {
                tmp->width = x;
                tmp->height = y;
              }
          }
      }

  if (!tmp->data)
    {
      free (tmp);
      tmp = NULL;
    }
  else
    msg (info, "decoded %dx%d font, %d characters", 
         tmp->width, tmp->height, tmp->count);

  return tmp;
}

typeface ** 
decode_fonts (const image_rgb24 * img, const int flags)
{
  typeface ** fntptr;
  uint8_t * topleft = img->img;
  uint8_t * bufptr = img->img + 2;
  uint8_t * endptr = img->img + 2;
  uint8_t * bufend = img->img + img->imgsize;

  fntptr = fonts;
  while (fntptr < fonts+MAX_FONTS)
    *fntptr++ = NULL;

  fntptr = fonts;
  while (fntptr < fonts+MAX_FONTS)
    if (!(*fntptr++ = find_fonts (&bufptr, &endptr, bufend, img->width, 
                                  topleft, flags)))
      break;

  /* FIXME: 
     - detect + bitpack mono fonts.
     - determine character width.
   */

  return fonts;
}


