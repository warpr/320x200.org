/*
  Jeeves Toolkit - various demoscene related conversion tools.
  Copyright 2002 Kuno Woudt <warp-tmt@dds.nl>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

*/

#include <SDL.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "img.h"
#include "err.h"

int
main (int argc, char ** argv)
{
  char * in_file = NULL;
  char * pal_file = NULL;
  image_rgb24 * img = NULL;
  image_rgb24 * pal = NULL;
  
  msg_init (argv[0], stdout, info);

  if (argc > 1)
    in_file = argv[1];
  else 
    {
      /* help. */
      printf (PACKAGE " version " VERSION ".\n"
              "Copyright 2002 Kuno Woudt aka Warp^Bliss <warp-tmt@dds.nl>\n"
              "\n"
              "usage: sdlimg infile [palfile] \n\n");

      return 0;
    }

  if (argc > 2)
    pal_file = argv[2];

  if (in_file)
    {
      int i;
      int x;
      int y;
      int bpp;
      unsigned char * palptr;
      SDL_Surface * screen;
      SDL_Event event;
      SDL_Color colours[0x100];

      img = load_image (in_file);
      if (!img)
        fatal ("unsupported file format");

      if (pal_file)
        {
          pal = load_image (pal_file);
          if (!pal)
            fatal ("unsupported file format");
        }
        
      if (pal && pal->pal)
        {
          img->pal = pal->pal;
          img->palcount = pal->palcount;
        }

      if (SDL_Init(SDL_INIT_VIDEO))
        fatal ("cannot init SDL: %s", SDL_GetError());

      screen = SDL_SetVideoMode(img->width, img->height, 8, 
                                SDL_HWPALETTE|SDL_HWSURFACE|SDL_FULLSCREEN);
      if (!screen)
        fatal ("cannot set videomode: %s", SDL_GetError());

      x = screen->w;
      y = screen->h;
      bpp = screen->format->BytesPerPixel;

      if ((x != img->width) || (y != img->height) || (bpp != 1))
        fatal ("SDL gave me a wrong videomode: "
               "I asked for (%dx%d:1) and I got (%dx%d:%d)",
               img->width, img->height, 1, x, y, bpp);

      if (screen->pitch != x)
        fatal ("SDL pitch not supported (warp is a lazy bum)");

      SDL_ShowCursor(0);

      if (SDL_MUSTLOCK (screen))
        if (!SDL_LockSurface (screen))
          fatal ("cannot lock SDL surface: %s", SDL_GetError());

      if (img->pal)
        {
          palptr = img->pal;
          for (i = 0; i<img->palcount; i++)
            {
              colours[i].r = *palptr++;
              colours[i].g = *palptr++;
              colours[i].b = *palptr++;
            }
        }
      else
        msg (warning, "no palette in image, display may be incorrect");
        
      SDL_SetColors(screen, colours, 0, 0x100);

      memcpy ((unsigned char *) screen->pixels,
              img->img, img->imgsize);

      if (SDL_MUSTLOCK (screen))
        SDL_UnlockSurface (screen);

      SDL_UpdateRect (screen, 0, 0, 0, 0);

      SDL_PollEvent(&event);
      while (event.type != SDL_KEYDOWN)
        SDL_PollEvent(&event);

      SDL_Quit ();
    }
  else
    fatal ("nothing to do");

  return 0;
}
