readme for the 4k source competition thingie, randomname.
main.c is 3748 bytes.
Makefile is 33 bytes.