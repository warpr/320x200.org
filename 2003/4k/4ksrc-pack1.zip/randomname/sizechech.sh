cat main.c | perl -pe 's/[\s\r\n]//g' | wc -c
