/* fill the rest of the bytes with comments */
#include <GL/glut.h>
#include <GL/gl.h>
#include <math.h>

#define X .52572111
#define Z .85065080
#define W 0x0DE1
#define G GLfloat
#define E GLubyte
#define R void
#define P glTexParameteri
#define J [i]
#define I [0]
#define F [1]
#define H [2]
#define K [3]
#define fo(a,b) for(a=0;a<b;a++)
#define M );
#define m },
#define S ){

G Q;GLUquadricObj *q1;GLuint g F,O[20] K={{1,4,0 m {4,9,0 m {4,5,9 m
{8,5,4 m {1,8,4 m{1,10,8 m {10,3,8 m {8,3,5 m {3,2,5 m {3,7,2 m{3,10
,7 m {10,6,7},{6,11,7 m {6,0,11 m {6,1,0 m {10,1,6 m {11,0,9 m {2,11
,9 m {5,2,9 m {11,2,7 m};E cI[64][64][4];int i;G a,B;G ai;R Y(E a,G\
 *v S switch(a){case 1:glVertex3fv(v M case 2:glTexCoord2fv(v M case
3:glNormal3fv(v M}}R d(G*v1,G*v2,G*v3 S glBegin(0x0004 M Y(3,v1 M Y\
(2,v1 M Y(1,v1 M Y(3,v2 M Y(2,v2 M Y(1,v2 M Y(3,v3 M Y(2,v3 M Y(1,v\
3 M glEnd( M}R n(G v K S G d=sqrt(v I*v I+v F*v F+v H*v H M v I/=d;v
F/=d; v H/=d;}R s(G*v1,G*v2,G*v3 S G V1 K,V2 K,V3 K;GLint i;fo(i,3){
V1 J=(v1 J+v2 J)/2;V2 J=(v2 J+v3 J)/2;V3 J=(v3 J+v1 J)/2;}n(V1 M n(\
V2 M n(V3 M d(v1,V1,V3 M d(v2,V2,V1 M d(v3,V3,V2 M d(V1,V2,V3 M}R D(
S G z=sin(Q/60)*.3,x=sin(Q/50)*.3,c=sin(Q/70)*.2,A[20] K={{-X+c,0+z,
Z+x m {X+c,0+z,Z+x m{-X+c,0+z,-Z+x m {X+c,0+z,-Z+x m{0+z,Z+x,X+c m{\
0+z,Z+x,-X+c m{0+z,-Z+x,X+c m{0+z,-Z+x,-X+c m{Z+x,X+c,0+z m{-Z+x,X+c
,0+z m{Z+x,-X+c,0+z m{-Z+x,-X+c,0+z m{-6.3,4.7,0 m {6.3,4.7,0 m{6.3,
-4.7,0 m{-6.3,-4.7,0 m{0,1 m{1,1 m{1,0 m{0,0 m};glClear(65<<8|0x000\
00400 M glLoadIdentity(M glEnable(0x0B90 M glStencilOp(0x1E01,0x1E01
,0x1E01 M glStencilFunc(0x0207,1,1 M glTranslatef(0.0-sin(Q/500)*2,\
0.0+sin(Q/400)*2,-7.0 M glEnable(0x0DE1 M glColor3f(0.0, 0.0,0.0 M \
glEnable(0x0B71 M glDisable(0x0BE2 M glBegin(0x0007 M glTexCoord2f(\
0.0,1.0 M glVertex3f(-0.8,0.8,0.0 M glTexCoord2f(1.0,1.0 M glVertex\
3f(0.8,0.8,0.0 M glTexCoord2f(1.0,0.0 M glVertex3f(0.8,-0.8,-0.0 M \
glTexCoord2f(0.0,0.0 M glVertex3f(-0.8,-0.8,-0.0 M glEnd( M glColor\
3f(1.0,1.0,1.0 M glDisable(0x0DE1 M glLineWidth(2 M glBegin(0x0002 M
glTexCoord2f(0.0,1.0 M glVertex3f(-0.8,0.8,0.0 M glTexCoord2f(1.0,1\
.0 M glVertex3f(0.8,0.8,0.0 M glTexCoord2f(1.0,0.0 M glVertex3f(0.8,
-0.8,-0.0 M glTexCoord2f(0.0,0.0 M glVertex3f(-0.8,-0.8,-0.0 M glEn\
d(M glColor3f(0,0,0 M glLoadIdentity(M glTranslatef(sin(Q/330)*2,si\
n(Q/260)*1.2,-6.0 M glStencilFunc(0x0202,1,1 M glStencilOp(0x1E00,0\
x1E00,0x1E00 M glRotatef(Q/10,0.0,1.0,0.2 M glEnable(0x0DE1 M fo(i,\
20){s(&A[O J I ] I,&A[O J F ] I,&A[O J H ] I);}glColor3f(1.0,1.0,1.0
M glPolygonMode(0x0408,0x1B01 M glDisable(0x0DE1 M fo(i,20){s(&A[O J
I ] I,&A[O J F ] I,&A[O J H ] I);}glEnable(0x0DE1 M glPolygonMode(0\
x0408,0x1B02 M glDisable(0x0B90 M glLoadIdentity( M glTranslatef(si\
n(Q/330)*2,sin(Q/260)*1.2,-6.0 M glRotatef(Q/10,0.0,1.0,0.2 M glCol\
or3f(1.0, 0.5, 0.0 M fo(i,20){s(&A[O J I ] I,&A[O J F ] I,&A[O J H ]
I);}glLoadIdentity( M glTranslatef(0,0,-10 M glColor3f(0,.3,.5 M gl\
Begin(0x0007 M Y(2,A[16] M Y(1,A[12] M Y(2,A[17] M Y(1,A[13] M Y(2,\
A[18] M Y(1,A[14] M Y(2,A[19] M Y(1,A[15] M glEnd( M glDisable(0x0B\
71 M glEnable(0x0BE2 M glColor3f(0.1,0.1, 0.1 M for(a=0;a<6;a+=0.2 S
for(B=0;B<5;B+=0.2 S glLoadIdentity(M glTranslatef(-3.0+a, -2.5+B,-4
M glScalef(1.0+sin(B*3+Q/130)*0.43, 1.0+sin(B*3+Q/130)*0.43, 0 M gl\
Rotatef(45,0,0,1 M glBegin(0x0007 M glVertex3f(-0.1,0.1,0.0 M glVer\
tex3f(0.1,0.1,0.0 M glVertex3f(0.1,-0.1,-0.0 M glVertex3f(-0.1,-0.1,
-0.0 M glEnd(M}}glDisable(0x0BE2 M  glutSwapBuffers( M}R T( S static
int time;Q=glutGet(700)/3;glutTimerFunc(0,T,0 M glutPostRedisplay( M
}R e(int w,int h S glViewport(0,0,w,h M glMatrixMode(0x1701 M glLoa\
dIdentity( M gluPerspective(50,(G)w/(G)h,.1,100 M glMatrixMode(0x17\
00 M}R k(E a,int x,int y S exit(0 M}int main(int c,char*a[] S int i,j,
C;glutInit(&c, a M glutInitDisplayMode(2|16|0|32 M glutCreateWindow(
"" M glutReshapeFunc(e M glutTimerFunc(0,T,0 M glBlendFunc(GL_SRC_A\
LPHA,GL_ONE M fo(i,64){fo(j,64){C=(((i&0x8)==0)^((j&0x8)==0))*255;cI
J [j] I=C;cI J [j] F=C;cI J [j] H=C;cI J [j] K=255;}}glPixelStorei(\
0x0CF5,1 M glGenTextures(1,g M glBindTexture(W,g I M P(W,0x2802,0x0\
CF5 M P(W,0x2803,0x2900 M P(W,0x2801,0x2600 M glTexImage2D(W,0,0x19\
08,64,64,0,0x1908,0x1401,cI M glutDisplayFunc(D M glutKeyboardFunc(k
M glutFullScreen(M glutMainLoop(M return 0;}
