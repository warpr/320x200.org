
Lollipop hogwagen - tonic's entry to #demoscene 4k source compo.
(Mar 2003)

I started a bit late with putting it together, so I had to take
some old effect and just modify it a bit for the compo. I also put
some music-like noise to background as well, which is based on a
composition by Tense. I ran out of time, so I didn't put any more
stuff in it, even I still had plenty of space within the size
limits.

  -- tonic (of Armada, Grin, sYmptom, ..)

http://iki.fi/jetro/ - jetro at iki (no spam) dot fi
