
          _____                                       |:::::::::::::|
         /    /\    _____                             |:::::::::::::|
        /    / / __/__  /\                            |:::::::::::::|        
       /    / / /    /\/ / ____     _____             |:::::::::::::|
      /    /_/_/    /__ / /   /\   _\ __/\            |:::::::::::::|
     /                /\_/   / /  /___\_\/            |:::::::::::::|
    /________     ___/ /  __/ /  / - _/\              |:::::::::::::|
    \_______/    /\  \/   \_\/  /_/\_\_/______  ___________  :::::::|
           /____/  \__\    \   /  __/ _  /    \/  _  / _  /\  ::::::|
           \    \  /  /____/\ /____/____/_/_/_/_/---/____/ /  ::::::|
            \____\/   \____\/ \_________________\/--\____\/  :::::::|
                                                            ::::::::|
     . #demoscene . 4k source compo . readme.txt .    |:::::::::::::|
                                                      |:::::::::::::|
                                                      |:::::::::::::|
> intro <                                             |:::::::::::::|
                                                      |:::::::::::::|
   Hi!                                                |:::::::::::::|
                                                      |:::::::::::::|
   You are reading the README.txt for the 4k source   |:::::::::::::|
   compo release pack.                                |:::::::::::::|
                                                      |:::::::::::::|
   This file contains all the entries in the compo,   |:::::::::::::|
   accompanied with a vote sheet you should fill in   |:::::::::::::|
   before friday next week.                           |:::::::::::::|
                                                      |:::::::::::::|
   Win32 binaries have been included in the win32/    |:::::::::::::|
   directory,  and in the linux directory you will    |:::::::::::::|
   find a Makefile for GNU/Linux.                     |:::::::::::::|
                                                      |:::::::::::::|
                                                      |:::::::::::::|
> quick start <                                       |:::::::::::::|
                                                      |:::::::::::::|
   You're  probably  itching to go see  the entries   |:::::::::::::|
   right now, so  go ahead.  There's only a  boring   |:::::::::::::|
   disclaimer below --- and some  notes on building   |:::::::::::::|
   the win32 executables.                             |:::::::::::::|
                                                      |:::::::::::::|
   Don't forget to mail  in your votesheet.txt when   |:::::::::::::|
   you are done!                                      |:::::::::::::|
                                                      |:::::::::::::|
                                           -- warp.   |:::::::::::::|
                                                      |:::::::::::::|
                                                      |:::::::::::::|
> disclaimer <                                        |:::::::::::::|
                                                      |:::::::::::::|
   Even though  the rules state only  valid ANSI C    |:::::::::::::|
   code is allowed - it is very difficult to check    |:::::::::::::|
   that.  I built the entries with gcc's -pedantic    |:::::::::::::|
   and -std=c9x, which should catch most mistakes.    |:::::::::::::|
                                                      |:::::::::::::|
   Some of these mistakes have been discovered and    |:::::::::::::|
   subsequently fixed  by the participants,  but I    |:::::::::::::|
   cannot be sure all the entries are 100% ANSI C.    |:::::::::::::|
                                                      |:::::::::::::|
   4 entries were submitted for the compo, none of    |:::::::::::::|
   them were disqualified.                            |:::::::::::::|
                                                      |:::::::::::::|
                                                      |:::::::::::::|
> notes on building the win32 executables <           |:::::::::::::|
                                                      |:::::::::::::|
   I have used a cross  compiling mingw to produce    |:::::::::::::|
   the win32 binaries.  mingw/msys should be easy     |:::::::::::::|
   too, an untesded Makefile is included which you    |:::::::::::::|
   can use as a starting point.  If you want to       |:::::::::::::|
   use MSVC to build the entries, you're on your      |:::::::::::::|
   own. sorry.                                        |:::::::::::::|
                                                      |:::::::::::::|
                                                      |:::::::::::::|
> notes on cross compiling with mingw32 <             |:::::::::::::|
                                                      |:::::::::::::|
   The biggest  problem I had when using a mingw32    |:::::::::::::|
   cross compiler to build the entries was to find    |:::::::::::::|
   the appropriate glut.h.  You probably will need    |:::::::::::::|
   to edit it to have it include <windows.h>.  SDL    |:::::::::::::|
   doesn't seem to give any trouble, but YMMV.        |:::::::::::::|
                                                      |:::::::::::::|
   To crosscompile, edit the Makefile in win32/.      |:::::::::::::|                                                      |:::::::::::::|
                                                      |:::::::::::::|


