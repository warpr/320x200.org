#!/bin/sh
gcc -I /usr/include/SDL -lSDL -lm -W -lpthread -O hogwagen.c -o hogwagen
