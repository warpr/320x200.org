var save_url = "index.php";
var cancel_url = "index.php?cancel=1";
var delete_url = "index.php?delete=1";
var section;
var working = false;
var currentpage = "";

function handle_response () 
{
  if (http.readyState == 4)
    {
      if (http.responseText.indexOf ('invalid') == -1)
        {
          reload = http.responseText.substring(0, 1);
          saved = http.responseText.substring(1, 2);
          msg = http.responseText.substring(2);

          if (saved == "1")
            {
              document.getElementById(section+"_state").innerHTML = "<span>saved</span>";
              document.getElementById(section).innerHTML = msg;
              document.getElementById(section).style.display = 'block';
              document.getElementById(section+"_src").style.display = 'none';
              document.getElementById(section+"_edit").style.display = 'none';
              document.getElementById(section+"_func").style.display = 'block';
            }
          else if (saved == "2")
            {
              document.getElementById(section+"_state").innerHTML = "<span>cancelled</span>";
              document.getElementById(section+"_editbox").value = msg;
              document.getElementById(section).style.display = 'block';
              document.getElementById(section+"_src").style.display = 'none';
              document.getElementById(section+"_edit").style.display = 'none';
              document.getElementById(section+"_func").style.display = 'block';
            }
          else if (saved == "3")
            {
              document.getElementById(section+"_state").innerHTML = "<span>deleted</span>";
              document.getElementById(section+"_editbox").value = msg;
              document.getElementById(section).innerHTML = msg;
            }
          else if (saved == "4")
            {
              document.getElementById(section+"_state").innerHTML = "<span>refreshed</span>";
              document.getElementById(section).innerHTML = msg;
            }
          else
            {
              document.getElementById(section+"_state").innerHTML = "<span>error saving: "+msg+"</span>";
            }

          working = false;

          if (reload == "1")
            history.go (0);
        }
    }
}

function remove (page, s) 
{
  section = s;

  if (!working && (http !== false)) 
    {
      http.open("GET", delete_url 
                + '&page='+page + '&section='+section, true);
      http.onreadystatechange = handle_response;
      working = true;
      http.send(null);
    }
}

function cancel (page, s) 
{
  section = s;

  if (!working && (http !== false)) 
    {
      http.open("GET", cancel_url 
                + '&page='+page + '&section='+section, true);
      http.onreadystatechange = handle_response;
      working = true;
      http.send(null);
    }
}

function save (page, s) 
{
  section = s;

  if (!working && (http !== false)) 
    {
      var val = document.getElementById(section+"_editbox").value;
      var extra = "";
      if (section == "content")
        {
          var submenu = document.getElementById("submenu_select").value;
          extra = '&submenu='+submenu;
        }
      http.open("POST", save_url, true);
      http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      http.onreadystatechange = handle_response;
      working = true;
      http.send("save=" + encodeURIComponent(val) + "&page=" + page + extra + "&section=" + section);
    }
}

function edit (s) 
{
  section = s;

  if (!working && (http !== false)) 
    {
      document.getElementById(section).style.display = 'none';
      document.getElementById(section+"_src").style.display = 'block';
      document.getElementById(section+"_func").style.display = 'none';
      document.getElementById(section+"_edit").style.display = 'block';
    }
}

function get_http_object () {
	var xmlhttp;

	if(!xmlhttp) {
		if(window.XMLHttpRequest) {/*Mozilla*/
			try { xmlhttp = new XMLHttpRequest(); }
			catch(e) { xmlhttp = false; }
		}
		else if(window.ActiveXObject) {/*IE*/
			try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
			catch(e) { xmlhttp = false; }
		}
	}

	return xmlhttp;
}

var http = get_http_object();
