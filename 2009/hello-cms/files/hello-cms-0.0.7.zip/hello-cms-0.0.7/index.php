<?php /*

  This file is part of Hello! CMS, a lightweight personal content
  management system.
  Copyright (C) 2005  Kuno Woudt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/* NOTES                                                    Hello! CMS
   -------------------------------------------------------------------
   
   NOTE: some of this file should be refactored into OOP code;
   for now, time constraints have forced me to keep it as is.

   -------------------------------------------------------- */ ?><?php

ini_set ("track_errors", "1");

/* GLOBAL                                                   Hello! CMS
   -------------------------------------------------------------------
   
   global variables, settings and whatnot.

   -------------------------------------------------------- */ ?><?php

$use_mod_rewrite = false;
define ("PASSWORD", "olleH");
define ("ROOT_INDEX", "/hello/");
define ("VERSION", "0.0.7");
define ("RAW_SUFFIX", ".html");
define ("WIKI_SUFFIX", ".wiki");
define ("LINK_TITLE_SUFFIX", ".links");
//$class = array ("menu", "title", "submenu");

/* MISC                                                     Hello! CMS
   -------------------------------------------------------------------
   
   miscellaneous functions.

   -------------------------------------------------------- */ ?><?php

/**
 * a little helper when debugging.
 */
function pre_r ($title, $x)
{
  $ret = "<h3>$title</h3>\n<pre>\n";

  ob_start ();
  print_r ($x);
  $ret .= ob_get_contents ();
  ob_end_clean ();

  return $ret."</pre>\n";
}

/**
 * clean up the title of a page
 */
function clean_name ($name)
{
  $replace_this = array ("/ /", "/[^A-Za-z0-9-]/");
  $with_that = array ("-", "");

  return preg_replace ($replace_this, $with_that, $name);
}

/* LINK TITLE                                               Hello! CMS
   -------------------------------------------------------------------
   
   a tiny automatic link title caching system.
   FIXME: should be oop probably... 
   FIXME: should use register_shutdown_function to write cache file.

   -------------------------------------------------------- */ ?><?php

/**
 * read link title cache.
 */
function &link_title_read_cache ()
{
  global $link_title_cache, $current_page;

  if (is_array ($link_title_cache))
    return $link_title_cache;

  if (!is_readable ($current_page.LINK_TITLE_SUFFIX))
    {
      $link_title_cache = array ();
      return $link_title_cache;
    }

  $link_title_cache =
    unserialize (join ("", file ($current_page.LINK_TITLE_SUFFIX)));

  if (!is_array ($link_title_cache))
    $link_title_cache = array ();
  return $link_title_cache;
}

/**
 * write link title cache.
 */
function link_title_write_cache ()
{
  global $current_page;

  $cache =& link_title_read_cache ();
  
  $handle = @fopen($current_page.LINK_TITLE_SUFFIX, 'w');
  if(!$handle)
    return false;

  $r = fwrite($handle, serialize ($cache));
  fclose ($handle);
      
  return $r;
}

/**
 * actually fetch the title for a link.
 */
function link_title_fetch ($link)
{
  $handle = @fopen ($link, 'r');
  if (!$handle)
    return $link;

  $done = false;
  $contents = '';
  while (!feof($handle))
    {
      $contents .= fread($handle, 8192);
      $pos = strpos (strtolower ($contents), "</title>");
      if ($pos !== false)
        break;
    }
  fclose($handle);

  if (!preg_match (",<title>(.*)</title>,i", $contents, $matches))
    return $link;

  return $matches[1];
}

/**
 * update the title for a link.
 */
function link_title_update ($link, $update = FALSE)
{
  global $link_title_write;

  $cache =& link_title_read_cache ();

  if (!$update)
    {
      if (!array_key_exists ($link, $cache))
        $cache[$link] = array ("title" => $link, "age" => time ());

      return;
    }

  // don't update if the existing title was fetched not too long ago.
  if (array_key_exists ($link, $cache)
      and (time () - $cache[$link]["age"] < 60*60*24*7))
    return;

  $cache[$link] = array ("title" => link_title_fetch ($link),
                         "age" => time ());

  $link_title_write = true;
}

/**
 * fetch the title for a link.
 */
function link_title ($link)
{
  global $logged_in;

  link_title_update ($link, $logged_in);

  $cache =& link_title_read_cache ();

  return $cache[$link]["title"];
}


/* CONTENT                                                  Hello! CMS
   -------------------------------------------------------------------
   
   functions related to loading and saving content.

   -------------------------------------------------------- */ ?><?php

/**
 * load raw content (not wiki formatted).
 */
function content_load_raw ($file)
{
  return join (file ($file.RAW_SUFFIX));
}

/**
 * content for a new page. 
 */
function content_newpage ()
{
  $content_first_heading = "new page";
  return "(This page doesn't exist yet, if you are"
    ." the admin of this site please login to create it)";
}

/**
 * get the selected submenu for this page.
 */
function content_get_submenu ($page)
{
  $files = content_gather_files ();

  if (array_key_exists ($page, $files["content"])
      and array_key_exists ("submenu", $files["content"][$page]))
    return $files["content"][$page]["submenu"];

  return "";
}


/**
 * read a page, or create a new one if this page
 * doesn't exist yet.
 */
function content_load ($file, $section)
{
  global $content_first_heading;

  $files = content_gather_files ();
  $new_page = false;

  if (array_key_exists ($file, $files[$section]))
    {
      /* FIXME: this needs a bit of a cleanup. */
      $filename = content_encode_filename ($file, $section, $files[$section][$file]);

      if (is_readable ($filename))
        return join (file ($filename));

      if (!file_exists ($filename))
        $new_page = true;
    }
  else
    {
        $new_page = true;
    }

  if ($new_page)
    return content_newpage ();

  // FIXME: warning/error handling.
  return "Error loading/creating $file.";
}

/**
 * delete a page
 */
function content_delete ($file, $section)
{
  $files = content_gather_files ();

  if (array_key_exists ($file, $files[$section]))
    {
      $filename = content_encode_filename ($file, $section, $files[$section][$file]);

      unlink ($filename);

      if (file_exists ($filename))
        return "Error deleting $file.";
    }

  return true;
}

/**
 * write the contents of a page to a file.
 */
function content_write ($file, $section, $submenu, $data, &$reload)
{
  $files = content_gather_files ();

  if (array_key_exists ($file, $files[$section]))
    $old_filename = content_encode_filename ($file, $section, $files[$section][$file]);

  content_update_file ($file, $section, $submenu);

  $files = content_gather_files ();
  $filename = content_encode_filename ($file, $section, $files[$section][$file]);

  if (!empty ($old_filename) and $old_filename !== $filename)
    $reload = true;

  $handle = @fopen ($filename, "wb");
  if ($handle)
    {
      $ret = @fwrite ($handle, $data);
      fclose ($handle);

      if ($ret == strlen ($data))
        {
          if (!empty ($old_filename) and $old_filename !== $filename)
            unlink ($old_filename);

          return true;
        }
    }

  return $php_errormsg." for $filename.";
}


/**
 * created response for edit.js.php.
 */
function content_edit_response ($force_reload, $state, $msg)
{
  $r = $force_reload ? "1" : "0";

  switch ($state)
    {
    case "error" : $r .= "0"; break;
    case "save"  : $r .= "1"; break;
    case "cancel": $r .= "2"; break;
    case "delete": $r .= "3"; break;
    case "reload": $r .= "4"; break;
    }

  echo $r.$msg;

  return true;
}

/**
 * save a page.
 * FIXME: and some more stuff,.. this name is misleading.
 */
function content_save ($file)
{
  global $logged_in;

  $action = "";
  if (!empty ($_GET['cancel']))
    $action = "cancel";
  else if (!empty ($_GET['delete']))
    $action = "delete";
  else if (!empty ($_GET['save']))
    $action = "save";
  else
    return false;
           
  $section = @$_GET['section'];
  if (empty ($section))
    $section = "content";

  if ($action === "cancel")
    return content_edit_response (false, $action, content_load ($file, $section));

  if ($logged_in !== true)
    return content_edit_response (false, "error", "not logged in");

  if ($action === "delete")
    {
      $ret = content_delete ($file, $section);
      
      if ($ret !== true)
        return content_edit_response (false, "error", $ret);

      return content_edit_response (false, $action, content_newpage ());
    }

  $save = @$_GET['save'];
  if (empty ($save))
    return false;

  if (get_magic_quotes_gpc ())
    $save = stripslashes ($save);
 
  $submenu = @$_GET['submenu'];

  $reload = false;
  $ret = content_write ($file, $section, $submenu, $save, $reload);
  if ($ret !== true)
    return content_edit_response ($reload, "error", $ret);

  return content_edit_response ($reload, $action, 
                                render_content (content_load ($file, $section)));
}

/**
 * create the filename for a bit of content.
 *
 * FIXME: this needs a bit of a cleanup.
 */
function content_encode_filename ($filename, $section, $options)
{
  foreach ($options as $key => $val)
    $filename .= '+'.$key.'='.$val;
  if ($section !== "content")
    $filename .= ".".$section;
  $filename .= WIKI_SUFFIX;

  return $filename;
}

/**
 * decode metadata in the filename.
 */ 
function content_decode_filename ($file)
{
  $tmp = split ("\.", $file);
  $ret = array ();
  $ret["section"] = "content";
  
  if (array_pop ($tmp) !== "wiki")
    return false;

  if (count ($tmp) == 2)
    $ret["section"] = $tmp[1];

  $layout = split ("\+", $tmp[0]);
  $ret["page"] = array_shift ($layout);
  $ret["subitems"] = array ();
  foreach ($layout as $val)
    {
      $subitem = split ("=", $val);
      $ret["subitems"][$subitem[0]] = $subitem[1];
    }

  return $ret;
}

/**
 * add a file to the gathered files variable, or update the options
 * of an existing file.
 * 
 * this is a kludge to make sure the directory doesn't have to be
 * read again (which tends to be slightly buggy in php for some reason).
 */
function content_update_file ($file, $section, $submenu)
{
  global $content_gathered_files;

  if (!empty ($submenu) and $submenu !== "none")
    $content_gathered_files[$section][$file] = array ("submenu" => $submenu);
  else
    $content_gathered_files[$section][$file] = array ();
}

/**
 * get a list of all the files which contain content for this page.
 */
function content_gather_files ()
{
  global $content_gathered_files;

  if (!empty ($content_gathered_files))
    return $content_gathered_files;

  /* get a list of *.wiki files in this directory. */
  $cwd = opendir (".");
  // FIXME: error/warning.
  if (!$cwd)
    return;

  $files = array (
                  "content" => array (),
                  "submenu" => array (),
                  "menu" => array (),
                  "title" => array (),
                  );

  while (($file = readdir ($cwd)) !== false) 
    {
      $tmp = content_decode_filename ($file);
      if (!empty ($tmp))
        $files[$tmp["section"]][$tmp["page"]] = $tmp["subitems"];
    }
  closedir ($cwd);

  $content_gathered_files = $files;

  return $files;
}

/* RENDER                                                   Hello! CMS
   -------------------------------------------------------------------
   
   functions related to rendering the html parts of a page.

   -------------------------------------------------------- */ ?><?php

/**
* nice filesizes.
*/
function render_pretty_size ($size)
{
    $sizes = array('B', 'KB', 'MB', 'GB', 'TB');

    $i = 0;
    while ($size >= 1024 and $i < count($sizes) - 1)
      {
        $size /= 1024;
        $i++;
      }

    return sprintf("%01.0f%s", $size, $sizes[$i]);
}

/**
 * simple dirlisting of files in a directory.
 */
function render_dirlisting ($dir, $re)
{
  $here = @opendir ($dir) or fatal ("cannot read $dir");
  $files = array ();

  while ($file = readdir ($here))
  {
    if (!is_dir ($dir.$file) and preg_match ($re, $file))
      $files[$file] =
        array ("name" => '<a href="'.$dir.$file.'">'.$file.'</a>',
               "date" => date ("Y:m:d H:i:s", filemtime ($dir.$file)),
               "size" => render_pretty_size (filesize ($dir.$file)));
  }

  ksort ($files);
  reset ($files);

  $ret = "<p>"
      .'<table><tr><td class="dirfilename">filename</td><td class="dirsize">size</td>'
      .'<td class="dirlastmod">last modified</td></tr>'
      ."<tr><td colspan=\"3\"><hr></td></tr>\n";

  foreach ($files as $val)
  {
    $ret .= "<tr><td class=\"dirfilename\">".$val["name"]
        ."</td><td class=\"dirsize\">".$val["size"]
        ."</td><td class=\"dirlastmod\">".$val["date"]
        ."</td></tr>\n";
  }

  return $ret."</table></p>\n";
}


/**
 * simple replace for templates, replace $this with $that.
 * ($this is a regex).
 */
function render_template_replace ($this, $that)
{
  global $template;

  $template = preg_replace ($this, $that, $template, 1);
}

/**
 * render doctype, title, script and css includes, etc.. 
 */
function render_head ($name)
{
  global $content_title_heading, $content_first_heading, $logged_in;

  $ret = '
  <title>'.$content_title_heading.', '
    .$content_first_heading.'</title>';

  if ($logged_in)
      $ret .= '
  <script language="javascript" type="text/javascript" src="edit.js.php"></script>
';
      /*
    {
      $ret .= '
  <script language="javascript"  type="text/javascript">
';
      ob_start ();
      include ("edit.js.php");
      $ret .= ob_get_contents ();
      ob_end_clean ();

      $ret .= "  </script>\n";
    }
*/

  render_template_replace (",</head>,", $ret."</head>");
}

/**
 * render content
 *
 * just a wrapper for wiki_render now.
 * (in case i want to replace the wiki stuff
 *  with htmlarea or something later on).
 */
function render_content ($page)
{
  return wiki_render ($page);
}

/**
 * render the edit/save/options menu for a chunk of content.
 *
 * $s is section.
 */
function render_edit_menu ($page, $s)
{
  global $logged_in;
  if (!$logged_in)
    return '';

  $ret = '
  <div class="funcbar" id="'.$s.'_func">
    <a href="javascript:remove (\''.$page.'\', \''.$s.'\');">delete</a>
    <a href="javascript:edit (\''.$s.'\');">edit</a><br />
  </div>
  <div class="editbar" id="'.$s.'_edit" style="display: none">';

  if ($s === "content")
      $ret .= 'submenu: <input name="submenu_select" id="submenu_select" '.
        'value ="'.content_get_submenu ($page).'" size="20" />';

  $ret .= '
    <a href="javascript:cancel (\''.$page.'\', \''.$s.'\');">cancel</a>
    <a href="javascript:save (\''.$page.'\', \''.$s.'\');">save</a>
  </div>
  <div class="statebar" id="'.$s.'_state"><span></span></div>
';

  return $ret;
}

/**
 * render one div of the page
 *
 * sets a global $content_first_heading if a <h1></h1>
 * is found.
 */
function render_section ($pagename, $section = "content")
{
  global $content_first_heading, $content_title_heading;

  $page = content_load ($pagename, $section);

  $content = render_content ($page);

  if (preg_match (",<h1>(.*)</h1>,", $content, $matches))
    $first_heading = $matches[1];

  if ($section === "content" and !empty ($first_heading))
    $content_first_heading = $first_heading;

  if ($section === "title" and !empty ($first_heading))
    $content_title_heading = $first_heading;

  $ret = '
  <div class="'.$section.'_wrap" id="'.$section.'_wrap">
    '.render_edit_menu ($pagename, $section).'
    <div class="'.$section.'" id="'.$section.'">
      '.$content.'
    <div class="'.$section.'_end"></div>
    </div>
';

  $ret .= '
    <div class="'.$section.'" id="'.$section.'_src" style="display: none;">
      <form action="post">
        <textarea name="editbox" id="'.$section.'_editbox">'
        .$page.'</textarea>
      </form>
    </div>
';

  $ret .= '
  </div>
';

  return $ret;
}

/**
 * render the body, including top banner, menu and content.
 */
function render_page ($pagename)
{
  global $logged_in, $current_page, $use_mod_rewrite;

  $files = content_gather_files ();
  $sections = array ();

  if (array_key_exists ($pagename, $files["content"]))
    $sections = $files["content"][$pagename];

  /* use some defaults for these sections. */
  if (!array_key_exists ("menu", $sections) or empty ($sections["menu"]))
    $sections["menu"] = "index";
  if (!array_key_exists ("title", $sections) or empty ($sections["title"]))
    $sections["title"] = "index";

  foreach ($sections as $key => $val)
    render_template_replace (",<div class=\"$key\"[^<]*</div>,m",
                             render_section ($val, $key));

  render_template_replace (",<div class=\"content\"[^<]*</div>,m", 
                           render_section ($pagename));


  $page = "";
  if (!$use_mod_rewrite)
    $page = "page=".$current_page."&";

  $str = $logged_in
    ? '<a href="?'.$page.'logout=1" class="login">logout</a>'
    : '<a href="?'.$page.'login=1" class="login">login</a>';
  render_template_replace (",<span class=\"login\"[^<]*</span>,m", 
                           $str);

}


/* WIKI                                                     Hello! CMS
   -------------------------------------------------------------------
   
   functions related to the wiki-like functionality of hello! cms.

   -------------------------------------------------------- */ ?><?php

/**
 * de-camel, convert a CamelCase string to .. erm.. not camel case.
 */
function wiki_decamel ($str)
{
  return strtolower (preg_replace ("/([a-z0-9])([A-Z])/", "$1 $2", $str));
}

/**
 * render link
 */
function wiki_render_link ($wiki_link, $desc)
{
  global $suffix, $use_mod_rewrite;

  $name = clean_name ($wiki_link);
  $class = file_exists ($name.WIKI_SUFFIX)
    ? "wikilink"
    : "new";

  $page = $use_mod_rewrite ? $name.'.html' : '?page='.$name;

  if ($page === "index.html")
    $page = ROOT_INDEX;

  return '<a class="'.$class.'" href="'.$page.'">'.$desc.'</a>';
}

/**
 * render a directory listing.
 */
function wiki_render_dir ($link)
{
  return render_dirlisting ($link, "/^[^\.]/");
}

/**
 * render img tag
 */
function wiki_render_img ($link, $desc, $float_left)
{
  $class = $float_left ? "left" : "right";

  $ret = '<img class="'.$class.'" src="'.$link.'"';

  if ($link !== $desc)
    $ret .= ' alt="'.$desc.'"';

  return $ret.">\n";
}

/**
 * convert a wiki-syntax link into a <a href>.
 */
function wiki_link_callback ($data)
{
  $link = "";
  $desc = "";

  switch (count ($data))
    {
    case 2:
      $link = wiki_decamel ($data[1]);
      $desc = $link;
      break;
    case 3:
      $link = $data[2];
      $desc = $data[2];
      break;
    case 4:
      $link = $data[2];
      $desc = empty ($data[3]) ? $data[2] : $data[3];
      break;
    case 5:
      $link = $data[4];
      $desc = $data[4];
      break;
    case 6:
      $link = $data[4];
      $desc = $data[5];
      break;
    case 7:
      $link = $data[6];
      $desc = substr ($data[6], 7);
      break;
    case 8:
      $link = $data[6];
      $desc = $data[7];
      break;
    }

  if (preg_match ("/\.(png|gif|jpg|jpeg)$/im", $link))
    {
      $float_left = substr ($link, 0, 1) === "^";
      if ($float_left)
        $link = substr ($link, 1);
      return wiki_render_img ($link, $desc, $float_left);
    }

  if (substr ($link, 0, 4) === "http"
      or substr ($link, 0, 6) === "mailto")
    {
      if ($link === $desc)
        $desc = link_title ($link);
      return '<a class="link" href="'.$link.'">'.$desc.'</a>';
    }

  if (preg_match (",/$,im", $link))
    return wiki_render_dir ($link);

  return wiki_render_link ($link, $desc);
}

/**
 * render wiki table syntax to html.
 */
function wiki_tables ($p)
{
  $c = substr ($p, 0, 1);
  if ($c != "|")
    return $p;

  $ret = "<table>\n";
  $lines = split ("\n", $p);

  foreach ($lines as $val)
    {
      $line = preg_replace ("/\|([^\|]*)/", "<td>$1</td>", $val);
      $ret .= "<tr>".$line."</tr>\n";
    }
  
  return $ret."</table>\n";
}

/**
 * render wiki list syntax to html.
 * NOTE: parsing here takes some shortcuts, which hopefully
 * shouldn't be a problem in practice.
 */
function wiki_lists ($p)
{
  $c = substr ($p, 0, 1);
  if ($c != "*" and $c != "#")
    return $p;

  $ret = "";
  $depth = 0;
  $prefix = "";
  $close = array ();
  $lines = split ("\n", $p);

  $good = 0;
  for ($i = 0; $i < count($lines); $i++)
    {
      $c = (substr ($lines[$i], 0, 1));
      if ($c == "*" or $c == "#")
        {
          $good = $i;
        }
      else
        {
          $lines[$good] .= " ".$lines[$i];
          unset ($lines[$i]);
        }
    }

  foreach ($lines as $val)
    {
      if (empty ($val))
          continue;
      preg_match ("/^([#|\*]+)[ \t\n]*(.*)/", $val, $matches);
      if (empty ($matches))
        continue;

      $len = strlen ($matches[1]);

      while ($len > $depth)
        {
          $l = (substr ($matches[1], -1, 1) == "#") ? "ol" : "ul";
          $depth++;
          $ret .= $prefix."<".$l.">\n";
          array_push ($close, "</".$l.">\n");
          $prefix .= "  ";
        }

      while ($len < $depth)
        {
          $prefix = substr ($prefix, 2);
          $depth--;
          $ret .= $prefix.array_pop ($close);
        }

      $ret .= $prefix."<li>".trim ($matches[2])."</li>\n";
    }

  while ($depth)
    {
      $prefix = substr ($prefix, 2);
      $depth--;
      $ret .= $prefix.array_pop ($close);
    }

  return $ret;
}

/**
 * render miscellaneous wiki syntax to html.
 */
function wiki_syntax ($p)
{
  $rules = array
    (
     // bold, underline.
     "/\*([A-Za-z0-9].*?[A-Za-z0-9])\*/m", "<strong>$1</strong>",
     "/_([A-Za-z0-9].*?[A-Za-z0-9])_/m", "<em>$1</em>",
     // monospace.
     "/\{([A-Za-z0-9].*?[A-Za-z0-9])\}/m", "<code>$1</code>",
     /* quotes, <q> support in IE 6 is seriously lacking, so instead of
        surrounding quotes with <q>, we will substitute the proper english
        quote characters ourselves. 
        More or less equivalent to the following stylesheet:

           Q { quotes: "\201C" "\201D" "\2018" "\2019" }
           Q:before { content: open-quote }
           Q:after  { content: close-quote }

        But add a <span> around it anyway so styles can be applied.
     */
     "/`([A-Za-z0-9\(][^`]*?[A-Za-z0-9\)\.])`/m", '<span class="quote">&#x201C;$1&#x201D;</span>',
     "/`([A-Za-z0-9\(][^`]*?[A-Za-z0-9\)\.])`/m", '<span class="quote">&#x2018;$1&#x2019;</span>',
     // headings.
     "/^======[\t ]*(.+?)[\t ]*======/m", "<h6>$1</h6>\n",
     "/^=====[\t ]*(.+?)[\t ]*=====/m", "<h5>$1</h5>\n",
     "/^====[\t ]*(.+?)[\t ]*====/m", "<h4>$1</h4>\n",
     "/^===[\t ]*(.+?)[\t ]*===/m", "<h3>$1</h3>\n",
     "/^==[\t ]*(.+?)[\t ]*==/m", "<h2>$1</h2>\n",
     "/^=[\t ]*(.+?)[\t ]*=/m", "<h1>$1</h1>\n",
     "/^&lt;&lt;&lt;/m", "<blockquote>",
     "/^&gt;&gt;&gt;/m", "</blockquote>",
     "/^{{{/m", "<pre>",
     "/^}}}/m", "</pre>",
     );

  $patterns = array ();
  $replacements = array ();
  while (list($key, $val) = each($rules)) 
    {
      $patterns[] = $val;
      list($key, $val) = each($rules);
      $replacements[] = $val;
    }  

  // remaining wiki syntax to html conversion.
  $p = preg_replace ($patterns, $replacements, $p);

  return $p;
}

/**
 * render wiki syntax to html.
 */
function wiki_render ($content)
{
  if (preg_match ("/^<html>/", $content))
    {
      // this page has raw html code, no wiki syntax.
      return preg_replace (array (",<html>,", ",</html>,"),
                           array ("",""), $content);
    }

  $content = htmlspecialchars ($content, ENT_QUOTES, 'UTF-8');

  // fix up newlines.
  $content = preg_replace (array ("/\r\n/", "/\r/"), 
                           array ("\n", "\n"), $content);

  // split into paragraphs.
  $paragraphs = preg_split ("/(^|\n)[\t ]*($|\n)/s", $content);

  foreach ($paragraphs as $key => $val)
    {
      // remove whitespace around paragraph.
      $p = trim ($val);
      if (empty ($p))
        {
          unset ($paragraphs[$key]);
          continue;
        }

      // parse wiki links.
      $p = preg_replace_callback
        (",([A-Z][a-z0-9]+[A-Z][A-Za-z0-9]+"
         ."|\[(\^?[A-Za-z0-9/\. ]+)(?:\|([^\]]*))?\]"
         ."|\[(http://[^ \t\n|]*)(?:\|([^\]]*))?\]"
         ."|\[(mailto:[^ \t\n|]*)(?:\|([^\]]*))?\]"
         ."|http://[^ \t\n]*),ms",
         "wiki_link_callback", $p);

      // remaining wiki syntax to html conversion.
      $p = wiki_syntax ($p);
      $p = wiki_lists ($p);
      $p = wiki_tables ($p);

      // if no existing blocklevel tag exists, make it a <p>.
      if (!preg_match ("/^<(P|H1|H2|H3|H4|H5|H6|UL|OL|PRE"
                       ."|DL|DIV|NOSCRIPT|BLOCKQUOTE|FORM"
                       ."|HR|TABLE|FIELDSET|ADDRESS)/i", $p))
        $p = "<p>".$p."</p>\n";

      $paragraphs[$key] = $p;
    }

  return join ("", $paragraphs);
}


/* MAIN                                                     Hello! CMS
   -------------------------------------------------------------------
   
   ...

   -------------------------------------------------------- */ ?><?php

/**
 * check login.
 */
function check_login ()
{
  $logout = @$_GET['logout'];
  if (!empty ($logout))
    {
      setcookie ("NOLOGINPLZ", "1");
      return false;
    }

  if (empty($_COOKIE["NOLOGINPLZ"])
      and @$_SERVER['PHP_AUTH_PW'] === PASSWORD)
    return true;

  $login = @$_GET['login'];
  if (!empty ($login))
    {
      setcookie ("NOLOGINPLZ", FALSE);
      header('WWW-Authenticate: Basic realm="hello! cms"');
      header('HTTP/1.0 401 Unauthorized');
      return false;
    }

  return false;
}

/**
 * tie everything together.
 */
function main ()
{
  global $current_page, $link_title_write, $template, $logged_in;

  $logged_in = check_login ();

  $name = @$_GET['page'];
  if (empty ($name))
    $name = "index";

  $current_page = clean_name ($name);

  if (content_save ($current_page))
    return;

  $template = join ("", file ("template.html"));

  render_page ($current_page);

  /* do render_head later, so it can pick up on any
     headings found by render_page() and use them
     for the <title>. */
  render_head ($current_page);

  echo $template;

  if ($link_title_write)
    link_title_write_cache ();
}

/**
 * report version if invoked with cli, for make dist.
 */
function version ()
{
  echo VERSION."\n";
}


if (@$_SERVER["argc"] == 2 and @$_SERVER["argv"][1] === "--version")
  version ();
else
  main ();
