<?php /*

  This file (byld_utility.php) is part of byld, a dynamic photo album.
  byld is copyright 2004 by Kuno Woudt <kuno@frob.nl>,

  This program is free software; you can redistribute it and/or
  modify it under the terms of the Affero General Public License as
  published by Affero, Inc.; either version 1 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty
  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  Affero General Public License for more details.

  You should have received a copy of the Affero General Public
  License along with this program; if not, write to Affero, Inc.,
  510 Third Street, Suite 225, San Francisco, CA 94107 USA.

*/

/* UTILITY FUNCTIONS                                              byld
   -------------------------------------------------------------------

   General utility functions which could possibly be used in other php
   files without significant changes.

   -------------------------------------------------------- */ ?><?php

/**
 * for php < 4.3.0.
 */
if (!function_exists ("html_entity_decode"))
{
  function html_entity_decode ($string)
  {
    $trans_tbl = get_html_translation_table(HTML_ENTITIES);
    $trans_tbl = array_flip($trans_tbl);
    return strtr($string, $trans_tbl);
  }
}

/**
 * complements the php builtin nl2br ().
 */
function br2nl ($str)
{
  return preg_replace('/<br.*?>/i', "\n", $str);
}

/**
 * remove possible surrounding quotes from a str
 */
function remove_quotes ($str)
{
  if ((substr ($str, 0, 1) == "'" and substr ($str, -1, 1) == "'")
      or (substr ($str, 0, 1) == '"' and substr ($str, -1, 1) == '"'))
    return substr ($str, 1, -2);

  return $str;
}

/**
 * decodes an image geometry string like 640x480, where either width,
 * or height or both width and height are specified.
 *
 * @return array an array containing width at index 0, and height
 *               at index 1.
 */
function decode_geometry ($str)
{
  preg_match ('/^([0-9]*)x?([0-9]*)/', $str, $matches);

  return array ($matches[1], $matches[2]);
}

/**
* nice filesizes.
*/
function pretty_size ($size)
{
    $sizes = array('B', 'KB', 'MB', 'GB', 'TB');

    $i = 0;
    while ($size >= 1024 and $i < count($sizes) - 1)
      {
        $size /= 1024;
        $i++;
      }

    return sprintf("%01.0f%s", $size, $sizes[$i]);
}

/**
 * array_merge_recursive2()
 *
 * Similar to array_merge_recursive but keyed-valued are always
 * overwritten.
 * Priority goes to the 2nd array.
 *
 * @param $a1 array
 * @param $a2 array
 * @return array
 */
function array_merge_recursive2 ($a1, $a2)
{
   if (!is_array($a1) or !is_array($a2))
     return $a2;

   foreach ($a2 as $key2 => $val2)
     $a1[$key2] = array_merge_recursive2 (@$a1[$key2], $val2);

   return $a1;
}

/**
 * a little helper to create decent looking paths.
 */
function merge_path ()
{
  $args = func_get_args ();
  $ret = "";

  foreach ($args as $elem)
    {
      if ($elem == '.' or $elem == './')
        continue;

      if (!empty ($ret) and substr ($ret, -1, 1) != '/')
        $ret .= '/';

      $ret .= $elem;
    }

  if (empty ($ret))
    return './';

  return $ret;
}

/**
 * a little helper when debugging.
 */
function pre_r ($title, $x)
{
  $ret = "<h3>$title</h3>\n<pre>\n";

  ob_start ();
  print_r ($x);
  $ret .= ob_get_contents ();
  ob_end_clean ();

  return $ret."</pre>\n";
}

/**
 * write_ini_file, to complement php's builtin parse_ini_file.
 */
function write_ini_file ($file, $arr, $prepend = "")
{
  $data = $prepend;

  $content = "";
  foreach($arr as $key => $item)
    {
      if(!is_array($item))
        {
          if(!is_bool($item))
            $item = '"'.$item.'"';

          $content .= $key." = ".$item."\n";
        }
      else
        {
          $data .= "\n[".$key."]\n";

          foreach ($item as $key2 => $item2)
            {
              if (!is_bool($item2))
                $item2 = '"'.$item2.'"';

              $data .= $key2." = ".$item2."\n";
            }
        }
    }

  if(!$handle = @fopen($file, 'w'))
    {
      warning ("cannot create $file, or open it for writing");
      return false;
    }

  if(!fwrite($handle, $data))
    return false;

  fclose($handle);
  return true;
}

/**
 * encode characters which cannot be used in .ini file values
 */
function ini_encode ($str)
{
  $s = array ("".chr(10), "".chr(13), '"');
  $r = array ('', '', '&#x22;');

  $ret = str_replace ($s, $r, nl2br ($str));

  return $ret;
}

/**
 * decode characters which cannot be used in .ini file values
 */
function ini_decode ($str)
{
  return br2nl (str_replace ('&#x22;', '"', $str));
}

/**
 * a class for creating zipfiles.
 *
 * original version from:
 *
 * Creating Zip Files Dynamically
 * By John Coggeshall (2001)
 *
 * http://www.zend.com/zend/spotlight/creating-zip-files1.php
 * http://www.zend.com/zend/spotlight/creating-zip-files2.php
 * http://www.zend.com/zend/spotlight/creating-zip-files3.php
 *
 * NOTE: file dates are not inserted properly, i do not consider this
 * a problem for how this class is being used in byld.
 */
class zipfile
{
  var $datasec = array();
  var $ctrl_dir = array();
  var $eof_ctrl_dir = "\x50\x4b\x05\x06\x00\x00\x00\x00";
  var $old_offset = 0;

  function add_file($path, $filename, $name = '')
    {
      $handle = @fopen (merge_path ($path, $filename), "rb")
        or fatal ("cannot read $name.");
      $data = @fread ($handle, filesize ($filename))
        or fatal ("cannot read $name.");
      fclose ($handle);

      if (empty ($name))
        $name = $filename;

      $name = str_replace("\\", "/", $name);
      $unc_len = strlen($data);
      $crc = crc32($data);
      $zdata = gzcompress($data);
      $zdata = substr ($zdata, 2, -4);
      $c_len = strlen($zdata);

      $fr = "\x50\x4b\x03\x04";
      $fr .= "\x14\x00";
      $fr .= "\x00\x00";
      $fr .= "\x08\x00";
      $fr .= "\x00\x00\x00\x00";
      $fr .= pack("V",$crc);
      $fr .= pack("V",$c_len);
      $fr .= pack("V",$unc_len);
      $fr .= pack("v", strlen($name) );
      $fr .= pack("v", 0 );
      $fr .= $name;
      $fr .= $zdata;
      $fr .= pack("V",$crc);
      $fr .= pack("V",$c_len);
      $fr .= pack("V",$unc_len);

      $this -> datasec[] = $fr;
      $new_offset = strlen(implode("", $this->datasec));

      $cdrec = "\x50\x4b\x01\x02";
      $cdrec .="\x00\x00";
      $cdrec .="\x14\x00";
      $cdrec .="\x00\x00";
      $cdrec .="\x08\x00";
      $cdrec .="\x00\x00\x00\x00";
      $cdrec .= pack("V",$crc);
      $cdrec .= pack("V",$c_len);
      $cdrec .= pack("V",$unc_len);
      $cdrec .= pack("v", strlen($name) );
      $cdrec .= pack("v", 0 );
      $cdrec .= pack("v", 0 );
      $cdrec .= pack("v", 0 );
      $cdrec .= pack("v", 0 );
      $cdrec .= pack("V", 32 );
      $cdrec .= pack("V", $this -> old_offset );

      $this -> old_offset = $new_offset;

      $cdrec .= $name;
      $this -> ctrl_dir[] = $cdrec;
    }

  function file()
    {
      $data = implode("", $this -> datasec);
      $ctrldir = implode("", $this -> ctrl_dir);

      return
        $data.
        $ctrldir.
        $this -> eof_ctrl_dir.
        pack("v", sizeof($this -> ctrl_dir)).
        pack("v", sizeof($this -> ctrl_dir)).
        pack("V", strlen($ctrldir)).
        pack("V", strlen($data)).
        "\x00\x00";
    }
}

/* ERROR HANDLING                                                 byld
   -------------------------------------------------------------------
   
   all error/warning related functions.

   -------------------------------------------------------- */ ?><?php

/**
 * collects warnings and displays them in a warning <div> at the end of the
 * page.
 */
function warning ($msg)
{
  global $collect_warnings;

  $collect_warnings .= $msg."<br />\n";
}

/**
 * display a fatal error message.
 */
function fatal ($msg)
{
  warning ("ERROR: ".$msg);
  display_warnings ();
  exit (1);
}

/**
 * display all collected warnings.
 */
function display_warnings ()
{
  global $collect_warnings;

  if (empty ($collect_warnings))
    return;

  // use inline style for warnings, so they are displayed regardless
  // of style sheet.
  echo '<div style="
   position: absolute;
   right: 20px;
   top: 40px;
   border: 2px solid #800000;
   background-color: #C04040;
   color: #FFFFFF;
   font-family: monospace;
   font-size: 110%;
   padding: 1em;
   margin: 0;"><p>errors and warnings:</p><p>'
    .$collect_warnings."</p></div>\n";
}

/**
 * user error handler :).
 */
function user_error_handler ($errno, $errstr,
                             $errfile, $errline, $errcontext)
{
  // surpress @ prefixed stuff.
  if(!error_reporting())
    return;

  $prefix = '';
  if ($errno == E_ERROR)
    $prefix = 'ERROR: ';
  else if ($errno == E_WARNING)
    $prefix = 'WARNING: ';
  else if ($errno == E_NOTICE)
    $prefix = 'NOTICE: ';

  warning ($prefix."line $errline: $errstr");
}

