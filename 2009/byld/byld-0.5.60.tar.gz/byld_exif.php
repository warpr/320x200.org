<?php /*

  This file (byld_exif.php) is part of byld, a dynamic photo album.
  byld is copyright 2004 by Kuno Woudt <kuno@frob.nl>,

  This program is free software; you can redistribute it and/or
  modify it under the terms of the Affero General Public License as
  published by Affero, Inc.; either version 1 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty
  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  Affero General Public License for more details.

  You should have received a copy of the Affero General Public
  License along with this program; if not, write to Affero, Inc.,
  510 Third Street, Suite 225, San Francisco, CA 94107 USA.

*/

/* EXIF FUNCTIONS                                                 byld
   -------------------------------------------------------------------

   exif reading/parsing functions which read only a tiny subset of
   exif, but do not need exif support compiled into php.

   -------------------------------------------------------- */ ?><?php

define ("IFD0_EXIFOFFSET", 0x8769);

function exif_hex ($n)
{
  return sprintf ("0x%04x", $n);
}

function exif_read ($len)
{
  global $exif_handle, $exif_pos;

  $exif_pos += $len;

  if ($len <= 0)
    warning ("0 bytes to read at exif_pos $exif_pos");
  return fread ($exif_handle, $len);
}

function exif_dword ()
{
  global $exif_handle, $exif_intel;

  $data = exif_read (4);

  if ($exif_intel)
    return ord ($data{3}) << 0x18
      | ord ($data{2}) << 0x10
      | ord ($data{1}) << 0x08
      | ord ($data{0});

  return ord ($data{0}) << 0x18
    | ord ($data{1}) << 0x10
    | ord ($data{2}) << 0x08
    | ord ($data{3});
}

function exif_word ()
{
  global $exif_handle, $exif_intel;

  $data = exif_read (2);

  if ($exif_intel)
    return ord ($data{1}) << 0x08 | ord ($data{0});

  return ord ($data{0}) << 0x08 | ord ($data{1});
}

function exif_ifd_directory ()
{
  $entries = exif_word ();

  $looking = array();
  $field = array ();
  for ($i = 0; $i < $entries; $i++)
    {
      $tag = exif_word ();
      $fmt = exif_word ();
      $num = exif_dword ();
      $dat = exif_dword ();

      if ($fmt == 2 or $tag == IFD0_EXIFOFFSET)
        {
          if ($fmt == 2 and $num <= 4)
            continue;
          $looking[] = $dat;
          $field[] = array ("tag" => $tag, "fmt" => $fmt,
                            "length" => $num, "offset" => $dat);
        }
    }

  asort ($looking);
  reset ($looking);

  $ret = array ();
  foreach ($looking as $key => $val)
    $ret[] = $field[$key];

  return $ret;
}

function exif_find_ifd_data ()
{
  global $exif_pos, $exif_file;

  $looking = exif_ifd_directory ();

  $str = array ();
  foreach ($looking as $field)
  {
    // skip to some data we're still looking for.
    $skip = $field["offset"] - $exif_pos;
    if ($skip > 1024*1024)
      {
        warning ("possibly broken exif header in $exif_file, skipping.");
        return array ();
      }
    if ($skip > 0) exif_read ($skip);

    if ($field["tag"] == IFD0_EXIFOFFSET)
      {
        $str = array_merge ($str, exif_find_ifd_data ());
        continue;
      }

    $size = $field["length"]-1;
    if ($size > 0)
      {
        $tmp = rtrim (exif_read ($size));
        $len = strcspn ($tmp, chr (0));

        if ($len > 0)
          $str[exif_hex ($field["tag"])] = substr ($tmp, 0, $len);
      }
  }

  return $str;
}

function exif_parse ()
{
  global $exif_handle, $exif_intel, $exif_pos;

  $exif_pos = 0;

  // skip exif/tiff headers, and check if the file uses
  // motorola or intel byte order for the EXIF header.
  $HDR = fread ($exif_handle, 6);
  if ($HDR != "Exif\x00\x00")
    return array ();
  $tmp = exif_read (4);
  $exif_intel = ($tmp{0} == 'I');

  $ifd0_pos = -8 + exif_dword ();
  if ($ifd0_pos > 0) // skip to IFD0 start.
    exif_read ($ifd0_pos);

  return exif_find_ifd_data ();
}

function simple_exif ($file)
{
  global $exif_handle, $exif_file;

  $exif_handle = fopen ($file, "r");
  $exif_file = $file;

  $ret = array ();
  $soi = fread ($exif_handle, 2);
  if ($soi == "\xFF\xD8")
    while (!feof ($exif_handle))
      {
        $marker = fread ($exif_handle, 4);
        $chunksize = ord ($marker{2}) * 0x100 + ord ($marker{3});

        // is this an EXIF chunk?
        if ($marker{1} == "\xE1")
          {
            $ret = exif_parse ();
            break;
          }

        // skip chunks we don't care about. (perhaps try to use fseek here,
        // and fall back to fread if it cannot be used on the file).
        if ($chunksize-2 > 0)
          fread ($exif_handle, $chunksize-2);
      }

  fclose ($exif_handle);

  return $ret;
}


