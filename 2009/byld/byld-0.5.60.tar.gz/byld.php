<?php /*

  This file (byld.php) is part of byld, a dynamic photo album.
  byld is copyright 2004 by Kuno Woudt <kuno@byld.org>,

  This program is free software; you can redistribute it and/or
  modify it under the terms of the Affero General Public License as
  published by Affero, Inc.; either version 1 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty
  of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  Affero General Public License for more details.

  You should have received a copy of the Affero General Public
  License along with this program; if not, write to Affero, Inc.,
  510 Third Street, Suite 225, San Francisco, CA 94107 USA.

*/

header ("Content-type: text/html; charset=utf-8");

error_reporting(E_ALL);

/* READ THIS NOW                                                  byld
   -------------------------------------------------------------------
   
   If   you   change   the   source   in  any   way,   please   update
   $program["version"] here to inform users this is not the canonical
   version.  E.g.  suffix it with your username,  nick or organization
   name:
                                                                    */
$program["name"] = "byld";
$program["version"] = "0.5.60";
$program["copyright"] = 'copyright 2004 by Kuno Woudt.';

/*  -------------------------------------------------------- */ ?><?php


/* TODO:                                                          byld
   ------------------------------------------------------------------- */
$todo = <<<TODOEND

   I was  not happy with  the split made  in the previous  version, so
   most of  it is  back now.  Over  time I  will hopefully be  able to
   refactor some  parts to be more  modular and write a  clean API for
   them, so that they can be moved into seperate files.

   Currently  most  functions  do  not  have  clear  APIs,  and  share
   undocumented internal structures without restriction :)

   0.5.5x (i want these fixed before a public release..):

   - add nick+date to user comment feed?
   - easy way for superuser to delete comments

   0.5.6x:

   - there are bugs with entering UTF8 (e.g. korean) characters in some
     fields (noticed atleast for nick when adding comments).
   - add option for album albums to have thumbnails.
   - per directory/album ordering (abc vs date)
   - add anchor links to the parent directory in render_path (album list)
   - add anchor links to current directory in render_path (image view)
   - clean up stylesheets.
   - parse EXIF dates, have a single date output function, eliminate
     seconds from it :)
   - wrap fopen+fwrite and such?  some code duplication is going on :)

   0.5.7x

   - on setup, provide a wizard like interface for common options.
   - autodetect location of imagemagick, by guessing /usr/bin,
        /usr/local/bin and looking in PATH.
   - provide an alternative way to specify image dimensions, e.g.
     max width + max height.

   more ideas which should eventually get implemented:

   - choose between automatic covers
     (first in list, useful when having folders sorted by date,
      to which images are added over time) and manual.
   - manual ordering of items
   - slideshow feature
   - template output?
   - remove tables from forms?
     see: http://www.quirksmode.org/css/forms.html

TODOEND;
/* -------------------------------------------------------- */ ?><?php

/* NOTES                                                          byld
   -------------------------------------------------------------------

   Some notes on the conventions used throughout this file.
   
   This project started  out as a single .php file,  it has since been
   split up  into smaller files, as  a result, some  functions are not
   located in the proper file yet.   Use tags or grep to find your way
   around the source :)
   
   Sections are preceded with comment  blocks like these to group more
   or less related functions.

   2) comment block convention

   As you may have noticed, these  comment blocks are ended with a php
   open/close tag.  This is to prevent emacs' hideshow.el from folding
   the block with subsequent comment blocks.  I consider that a bug in
   hideshow.el, but  I have  been too lazy  to investigate  the matter
   further.  I  assume this doesn't  have any noticable effect  on the
   time it  takes PHP to  parse this file.   I will work  around other
   emacs parsing  bugs in  a similar fashion,  hence you may  see some
   other peculiar things occasionally.

   3) some function prefixes

   render_*  functions return a string, and never echo anything.
   display_* functions echo stuff, and do not return anything.

   you will find most of these in byld_display.php.

   -------------------------------------------------------- */ ?><?php

/* GLOBAL VARIABLES                                               byld
   -------------------------------------------------------------------

   The most  important global variable  is $settings, which  keeps all
   the stuff which  can be configured by the  user.  It is initialized
   in set_defaults () and can  be configured by choosing 'setup' after
   logging in.

   The stuff that remains here  should not be changed, unless you know
   what you are doing :)
 
   -------------------------------------------------------- */ ?><?php

$ini_filename = 'byld.ini.php';
$htxs_filename = dirname (__FILE__)."/.htaccess";
$suffix_regexp = '(\.jpeg|\.jpg|\.png|\.gif)$';
$skip_regexp = '/(\.thumb|\.cover|\.album|\.view)'.$suffix_regexp.'/i';

// NOTE: this is the same as the dates returned by EXIF.
// for sort to work properly that is required, i consider this a bug,
// some day parsing EXIF dates will be neccesary.
$date_format = "Y:m:d H:i:s";

/* ttl for the rss feed. */
$syndicate_ttl = 240;
$syndicate_text = array ();

$logged_in = false;
$editable = false;
$edit_current_item = 0;

/* LOAD MODULES                                                   byld
   -------------------------------------------------------------------
   
   byld  used to  be  a single  .php  file, but  at  140kbyte, it  was
   becoming  rather big.   So  nowadays  it consists  of  a number  of
   modules, which are loaded here.

   -------------------------------------------------------- */ ?><?php

require_once ("byld_exif.php");
require_once ("byld_utility.php");
require_once ("byld_license.php");

/* CREATIVE COMMONS                                               byld
   -------------------------------------------------------------------
   
   creative commons related functions.

   -------------------------------------------------------- */ ?><?php

/**
 * display metadata (rdf) about the copyright license under which
 * images are licensed.
 */
function display_metadata ()
{
  global $settings;

  if ($settings["copyright"]["use"]
      and !empty ($settings["copyright"]["metadata"]))
    echo "<!--\n".ini_decode ($settings["copyright"]["metadata"])
      ."\n-->\n";
}

/**
 * get rdf metadata for the sampling licenses.
 */
function creativecommons_rdf ($license)
{
  if ($license == "Sampling")
    return '
<rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<Work rdf:about="">
   <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
   <license rdf:resource="http://creativecommons.org/licenses/sampling/1.0/" />
</Work>

<License rdf:about="http://creativecommons.org/licenses/sampling/1.0/">
   <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
   <requires rdf:resource="http://web.resource.org/cc/Attribution" />
   <requires rdf:resource="http://web.resource.org/cc/Notice" />
   <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
</License>

</rdf:RDF>
';

  if ($license == "Sampling Plus")
    return '
<rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<Work rdf:about="">
   <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
   <license rdf:resource="http://creativecommons.org/licenses/sampling+/1.0/" />
</Work>

<License rdf:about="http://creativecommons.org/licenses/sampling+/1.0/">
   <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
   <requires rdf:resource="http://web.resource.org/cc/Attribution" />
   <requires rdf:resource="http://web.resource.org/cc/Notice" />
   <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
   <permits rdf:resource="http://web.resource.org/cc/Sharing" />
</License>

</rdf:RDF>
';

  if ($license == "Noncommercial Sampling Plus")
    return '
<rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<Work rdf:about="">
   <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
   <license rdf:resource="http://creativecommons.org/licenses/nc-sampling+/1.0/" />
</Work>

<License rdf:about="http://creativecommons.org/licenses/nc-sampling+/1.0/">
   <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
   <requires rdf:resource="http://web.resource.org/cc/Attribution" />
   <requires rdf:resource="http://web.resource.org/cc/Notice" />
   <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
   <permits rdf:resource="http://web.resource.org/cc/Distribution" />
   <prohibits rdf:resource="http://web.resource.org/cc/CommercialUse" />
</License>

</rdf:RDF>
';

}


/**
 * redirect the user to creative commons, to select a license.
 */
function creativecommons_select ($button)
{
  global $home, $path, $settings;

  $url = "";
  if ($button == 'select license')
    {
      $url = "";
      $lnk = make_link ('return_from_cc', $home, false, true);
      $sep = strchr ($lnk, '?') ? '&' : '?';

      $lnk .= $sep.'license_url=[license_url]&license_name=[license_name]';
      $url = 'http://creativecommons.org/license/?partner=byld&exit_url='
        .urlencode ($lnk);
    }
  else
    {
      $settings["copyright"]["license_name"] = $button;
      if ($button == "Sampling")
        $settings["copyright"]["license_url"] =
          'http://creativecommons.org/licenses/sampling/1.0/';
      else if ($button == "Sampling Plus")
        $settings["copyright"]["license_url"] =
          'http://creativecommons.org/licenses/sampling+/1.0/';
      else if ($button == "Noncommercial Sampling Plus")
        $settings["copyright"]["license_url"] =
          'http://creativecommons.org/licenses/nc-sampling+/1.0/';

      $settings["copyright"]["metadata"] =
        ini_encode (creativecommons_rdf ($button));

      write_ini ();

      $url = make_link ('', $home.$path, false, true);
    }

  header ("Location: ".$url);

  /* just in case the redirect doesn't work. */
  echo '<html><head>
        <meta http-equiv="refresh" content="0; URL='.$url.'">
        </head></html>';

  exit ('');
}

/**
 * process the selected license.
 */
function action_return_from_cc ()
{
  global $settings;

  if (!array_key_exists ("license_url", $_REQUEST)
      or !array_key_exists ("license_name", $_REQUEST))
    {
      warning ("error, did not receive license details from "
               ."creativecommons (".$_SERVER["REQUEST_URI"].")");
      return;
    }

  $settings["copyright"]["license_url"] = $_REQUEST["license_url"];
  $settings["copyright"]["license_name"] = $_REQUEST["license_name"];

  $get_rdf = 'http://creativecommons.org/license/get-rdf?license_url='
    .$settings["copyright"]["license_url"].'&format=image'
    .'&copyright_holder='.$settings["copyright"]["holder"]
    .'&copyright_year='.$settings["copyright"]["year"];

  /* if we get here, apparantly there is no trouble reaching
     creativecommons.org, so let's just risk fetching this without
     too much error checking ;) */
  $settings["copyright"]["metadata"] =
    ini_encode (implode ('', file ($get_rdf)));

  write_ini ();
}

/* RSS                                                            byld
   -------------------------------------------------------------------
   
   all rss related functions.

   -------------------------------------------------------- */ ?><?php

/**
 * set some syndicate values.
 */
function set_syndicate ()
{
  global $settings, $syndicate_text;


  $syndicate_text = array ();
  $syndicate_text["new"] =
    array ($settings["main"]["title"]." images and albums",
           "new images and albums added to ".$settings["main"]["title"]);
  $syndicate_text["comment"] =
    array ($settings["main"]["title"]." user comments",
           "user comments submitted to ".$settings["main"]["title"]);
}

/**
 * render links for our feeds.
 */
function display_syndicate ()
{
  global $home, $syndicate_text;

  set_syndicate ();

  if (file_exists (dirname (__FILE__)."/new.xml"))
    echo '<link rel="alternate" title="'.$syndicate_text["new"][0].'"
      type="application/rss+xml"
      href="'.make_file_link ('new.xml', $home, false, true).'" />
  ';

  if (file_exists (dirname (__FILE__)."/comments.xml"))
    echo '<link rel="alternate" title="'.$syndicate_text["comment"][0].'"
     type="application/rss+xml"
     href="'.make_file_link ('comments.xml', $home, false, true).'" />
  ';
}

/**
 * write rss for byld user comments.
 */
function write_rss_file ($title, $help, $file, $items)
{
  global $home, $path, $settings, $program, $syndicate_ttl;

  $rss = '<?xml version="1.0"?>
<rss version="2.0">
   <channel>
      <title>'.$title.'</title>
      <link>'.make_link ('', $home, false, true)
    .'</link>
      <description>'.$help.'</description>
      <pubDate>'.gmstrftime("%a, %d %b %Y %T %Z", time ()).'</pubDate>
      <lastBuildDate>'.gmstrftime("%a, %d %b %Y %T %Z", time ())
    .'</lastBuildDate>
      <docs>http://blogs.law.harvard.edu/tech/rss</docs>
      <generator>'.$program["name"].' '.$program["version"].'</generator>
      <webMaster>'.$_SERVER["SERVER_ADMIN"].'</webMaster>
      <ttl>'.$syndicate_ttl.'</ttl>
';

  $item_str = '';
  foreach ($items as $val)
    {
      $tmp = '      <item>
         <link>'.$val["link"].'</link>
         <guid>'.$val["link"].'</guid>
         <title>'.$val["title"].'</title>';

      if (array_key_exists ("nick", $val))
        $tmp .= '
         <author>'.$val["nick"].' &lt;nospam@example.com&gt;</author>';

      $item_str = $tmp.'
         <description><![CDATA['
        .nl2br (ini_decode ($val["text"]))
        .']]></description>
         <pubDate>'.gmstrftime("%a, %d %b %Y %T %Z",
                             exifdate_to_timestamp ($val["date"]))
        .'</pubDate>
      </item>
'.$item_str;
    }

  $data = $rss.$item_str.'   </channel>
</rss>
';

  if(!$handle = @fopen($file, 'w'))
    {
      warning ("cannot create $file, or open it for writing");
      return false;
    }

  if(!fwrite($handle, $data))
    return false;

  fclose($handle);
  return true;
}

/**
 * convert an exif date ('2004:12:05 20:33:32') to a unix timestamp.
 */
function exifdate_to_timestamp ($str)
{
  $str{10} = ':';
  list ($year, $month, $day, $hour, $min, $sec) = explode (':', $str);
  return mktime ($hour, $min, $sec, $month, $day, $year);
}

/**
 * clean up the comments if there are more than 10.
 */
function clean_feed ($items)
{
  global $syndicate_ttl;

  if (count($items) > 10)
    {
      reset ($items);
      while (list ($key, $val) = each ($items))
        {
          $item = exifdate_to_timestamp ($val["date"]);

          /* remove items which are older than the ttl set for this feed. */
          if (((time () - $item) / 60.0) > $syndicate_ttl)
            unset ($items[$key]);
        }
    }

  return $items;
}

/**
 * updates the new item rss feed with a new album or image.
 */
function syndicate_item ($type, $loc, $file_ini)
{
  global $home, $path, $date_format, $settings,
    $syndicate_ttl, $syndicate_text;

  if (!$settings["features"]["use_rss"])
    return;

  set_syndicate ();

  $ini = dirname (__FILE__)."/new.ini";
  $rss = dirname (__FILE__)."/new.xml";

  $items = array ();
  if (is_file ($ini) and is_readable ($ini))
    $items = parse_ini_file ($ini, true);

  $items = clean_feed ($items);

  $desc = "";
  $title = "";
  if ($type == "album")
    {
      $img_ini = read_image_ini
        (merge_path ($loc, $file_ini["album"]["cover"]));
      $title = $file_ini["album"]["title"];
      $desc = '<p>'.render_thumbnail
        (merge_path (basename ($loc), $file_ini["album"]["cover"]),
         $img_ini, "view", true)
        .' </p><p>'.$file_ini["album"]["description"].'</p>';
    }
  else
    {
      $title = render_path (false, false, $loc);
      $desc = '<p>'.render_thumbnail
        (basename ($loc), $file_ini["image"], "view", true)
        .' </p><p>'.$file_ini["image"]["description"].'</p>';

    }

  $items = array_merge
    ($items,array (array (
     "date" => date ($date_format),
     "text" => ini_encode ($desc),
     "title" => $title,
     "link" => make_link ('', $home.$loc, false, true))));

  write_ini_file ($ini, $items);
  write_rss_file ($syndicate_text["new"][0],
                  $syndicate_text["new"][1], $rss, $items);
}

/**
 * updates the rss feed with a new user comment.
 */
function syndicate_comment ($nick, $date, $text, $title,
                            $path, $anchor, $image_ini)
{
  global $home, $path, $settings, $syndicate_ttl, $syndicate_text;

  if (!$settings["features"]["use_rss"])
    return;

  set_syndicate ();

  $ini = dirname (__FILE__)."/comments.ini";
  $rss = dirname (__FILE__)."/comments.xml";

  $comments = array ();
  if (is_file ($ini) and is_readable ($ini))
    $comments = parse_ini_file ($ini, true);

  $comments = clean_feed ($comments);

  $description = '<p>'.render_thumbnail ("", $image_ini, "view", true)
    .' </p><p>'.$text.'</p>';

  $comments = array_merge
    ($comments, array (array (
     "nick" => $nick,
     "date" => $date,
     "text" => ini_encode ($description),
     "title" => $title,
     "link" => make_link ('', $home.$path, false, true, $anchor))));


  write_ini_file ($ini, $comments);
  write_rss_file ($syndicate_text["comment"][0],
                  $syndicate_text["comment"][1], $rss, $comments);
}

/* READING A DIRECTORY                                            byld
   -------------------------------------------------------------------

   some functions related to reading directories.

   -------------------------------------------------------- */ ?><?php

/**
 * get album date.
 */
function get_album_date ($album)
{
  $dir = read_sub_dir ($album);

  // check for images in the album, if there are some, use the date
  // of the most recent image as our album date.
  if (count ($dir["thumbs"]))
    {
      $dates = array ();
      foreach ($dir["thumbs"] as $image)
        $dates[] = @$image["stats"]["date"];

      asort ($dates);
      return array_pop ($dates);
    }

  if (count ($dir["albums"]))
    {
      $dates = array ();
      foreach ($dir["albums"] as $key => $alb)
        $dates[] = get_album_date (merge_path ($album, $key));

      asort ($dates);
      return array_pop ($dates);
    }

  return "";
}


/**
 * sort a directory listing of albums.
 */
function sort_albums ($dirs, $dir)
{
  global $settings, $path;

  //  warning ("sort_albums path: $path, dir: $dir");

  $ini = array ();
  // load .ini information for each album
  foreach ($dirs as $album)
    $ini[$album] = read_album_ini ($album);

  $list = array ();
  // fill an array with values to be sorted on, based on user
  // preference.
  if ($settings["sort"]["album_type"] == "date")
    {
      foreach ($dirs as $album)
        $list[$album] = get_album_date (merge_path ($dir, $album));
    }
  else
    {
      foreach ($dirs as $album)
        $list[$album] = $album;
    }

  // sort the array.
  if ($settings["sort"]["album_reverse"])
    arsort ($list);
  else
    asort ($list);
  reset ($list);

  // put the information from the ini files in $list.
  foreach ($list as $key => $val)
    $list[$key] = $ini[$key];

  return $list;
}

/**
 * sort a directory listing of images.
 *
 * a side effect is that all kinds of information about images is
 * gathered.
 */
function sort_images (&$imgs, $dir)
{
  global $settings, $date_format;

  if (!count ($imgs))
    return array ();

  $ini = array ();
  $stats = array ();
  // load .ini and read stats for each image
  foreach ($imgs as $image)
    {
      $ini[$image] = read_image_ini (merge_path ($dir, $image));
      $stats[$image] = read_image_stats (merge_path ($dir, $image));
    }

  $list = array ();
  // fill an array with values to be sorted on, based on user
  // preference.
  if ($settings["sort"]["thumb_type"] == "date")
    {
      foreach ($imgs as $image)
        $list[$image] = $stats[$image]["date"];
    }
  else
    {
      foreach ($imgs as $image)
        $list[$image] = $image;
    }

  // sort the array.
  if ($settings["sort"]["thumb_reverse"])
    arsort ($list);
  else
    asort ($list);

  reset ($list);

  // put the information from stats and .ini files in $list.
  foreach ($list as $key => $val)
    {
      $list[$key] = array ();
      $list[$key]["ini"] = $ini[$key];
      $list[$key]["stats"] = $stats[$key];
    }

  return $list;
}

/**
 * don't use this.  use read_dir () instead.
 */
function read_dir_helper ($dir)
{
  global $suffix_regexp, $skip_regexp, $edit;

  $ret["directories"] = array ();
  $ret["images"] = array ();
  $ret["stylesheets"] = array ();
  $ret["source"] = array ();

  $ini = read_album_ini ($dir);
  $hide = convert_album_hidden ($ini);

  $here = @opendir ($dir) or fatal ("cannot read $dir");
  while ($file = readdir ($here))
  {
    if (preg_match ($skip_regexp, $file))
      continue;

    if (!$edit and array_key_exists ($file, $hide))
      continue; /* hide this directory. */

    if (is_dir (merge_path ($dir, $file))
        && (substr ($file, 0, 1) !== "."))
      {
        $ret["directories"][] = $file;
      }
    else if (preg_match ('/'.$suffix_regexp.'/i', $file))
      {
        $ret["images"][] = $file;
      }
    else if (preg_match ('/css$/i', $file))
      {
        $ret["stylesheets"][] = $file;
      }
    else if (preg_match ('/^byld_.*\.php$/i', $file))
      {
        $ret["source"][] = $file;
      }
  }

  return $ret;
}

/**
 * read some info from a directory
 */
function read_sub_dir ($dir)
{
  global $path, $skip_regexp, $read_sub_dir_cache;

  if (!is_array ($read_sub_dir_cache))
    $read_sub_dir_cache = array ();

  if (array_key_exists ($dir, $read_sub_dir_cache))
    return $read_sub_dir_cache[$dir];

  $ret = read_dir_cache ($dir);

  if (empty ($ret))
    {
      $ret = read_dir ($dir);
      echo '<div class="create">Caching '.$dir." album ... </div>\n";
      flush ();
      write_dir_cache ($dir, $ret);
    }

  $read_sub_dir_cache[$dir] = $ret;
  return $ret;
}

/**
 * read basic directory info from a cache file.
 */
function read_dir_cache ($dir)
{
  $cache_file = merge_path ($dir, "cache.ini");

  if (!is_file ($cache_file) or !is_readable ($cache_file))
    return array ();

  $ret = array ();
  $ret["thumbs"] = array ();
  $ret["albums"] = array ();

  $cache = parse_ini_file ($cache_file, true);
  if (array_key_exists ("thumbs", $cache))
    foreach ($cache["thumbs"] as $key => $val)
    {
      $ret["thumbs"][$key]["stats"]["date"] = $val;
      $ret["thumbs"][$key]["stats"]["filename"] = $key;
    }
  if (array_key_exists ("albums", $cache))
    foreach ($cache["albums"] as $key => $val)
      $ret["albums"][$key] = array ();

  return $ret;
}

/**
 * write basic directory info to a cache file.
 */
function write_dir_cache ($dir, $arr)
{
  $cache_file = merge_path ($dir, "cache.ini");

  $cache = array ();
  foreach ($arr["thumbs"] as $key => $val)
    $cache["thumbs"][$key] = $val["stats"]["date"];
  foreach ($arr["albums"] as $key => $val)
    $cache["albums"][$key] = "";

  write_ini_file ($cache_file, $cache, "");
}

/**
 * read directory
 *
 * this is also the place where files are sorted according to
 * preference.
 */
function read_dir ($dir = "")
{
  global $path, $skip_regexp, $read_dir_cache;

  if (!is_array ($read_dir_cache))
    $read_dir_cache = array ();

  if (array_key_exists ($dir, $read_dir_cache))
    return $read_dir_cache[$dir];

  $ret = read_dir_helper ($dir);

  $ret["albums"] = sort_albums ($ret["directories"], $dir);
  $ret["thumbs"] = sort_images ($ret["images"], $dir);

  $read_dir_cache[$dir] = $ret;
  write_dir_cache ($dir, $ret);

  return $ret;
}

/* GENERAL PAGE RENDERING FUNCTIONS                               byld
   -------------------------------------------------------------------
   
   functions which handle the common parts of a page, including header
   (stylesheets), footer  and other parts commonly seen  on most pages
   of the photo album.

   -------------------------------------------------------- */ ?><?php

/**
 * render the current path
 *
 * @param bool $use_html if true, render each element as a seperate html
 *      link; use plain text if false.
 * @return string rendered string
 */
function render_path ($use_html = true, $navbar = false,
                      $newpath = false, $force_root = false)
{
  global $settings, $home, $path;

  $sep = $ret = $current = $root = '';
  $elements = array ();

  $p = $newpath ? $newpath : $path;

  $root = $settings["main"]["root"];
  $sep = $settings["main"]["seperator"];

  // FIXME: hack,.. API for this should be cleaner.
  if (!is_bool ($force_root))
    $root = $force_root;

  $elements = split ("/", $navbar ? dirname ($p) : $p);

  $ret = !$use_html ? $root : make_link (false, $home, $root);
  $current = merge_path ($current, $home);

  foreach ($elements as $elem)
    {
      if (empty ($elem) or $elem == '.') continue;
      if (!$use_html)
        {
          $ret .= $sep.$elem;
          continue;
        }

      if (!empty ($ret))
        $ret .= $sep;

      $current = merge_path ($current, $elem);
      $ret .= make_link (false, $current, $elem);
    }

  return $ret;
}

/**
 * load selected stylesheet.
 */
function display_load_stylesheet ()
{
  global $settings, $home;

  $css_file = $settings["style"]["stylesheet"];

  if (!is_readable ($css_file))
    return '';

  $js_file = get_companion_js_file ($css_file);

  if ($settings["misc"]["inline_css"])
    {
      echo "    <style type=\"text/css\">\n"
        .join ("", file ($css_file))
        ."\n    </style>\n";

      if (!empty ($js_file))
        echo "    <script type=\"text/javascript\">\n"
          .join ("", file ($js_file))
          ."\n    </script>\n";
    }
  else
    {
      echo '  <link href="'.make_file_link ($css_file, $home).'"'
        .' rel="stylesheet" type="text/css" title="byld default">
        ';

      if (!empty ($js_file))
        echo '    <script type="text/javascript" src="'
          .make_file_link ($js_file, $home)
          .'"></script>
        ';
    }

  return empty ($js_file) ? '' : basename ($js_file, '.js').' ();';
}

/**
 * display the page header
 */
function display_header ($page, $focus = "")
{
  global $settings;

  $onload = array ();

  echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>'.render_path (false, false, false,
                        $settings["main"]["title"])."</title>\n";

  display_syndicate ();

  $stylejs = display_load_stylesheet ();
  if (!empty ($stylejs))
    $onload[] = $stylejs;

  $js = '';
  if (!empty ($focus))
    {
      $js .= 'function sf () { '.$focus.".focus(); }\n\n";
      $onload[] = 'sf ();';
    }

  if (count ($onload))
    {
      $js .= "function init ()\n{\n";
      foreach ($onload as $val)
        $js .= "  ".$val."\n";
      $js .= "}\n";
    }

  if (!empty ($js))
    echo " <script type=\"text/javascript\">\n".$js."\n</script>\n";

  echo "\n</head>\n<body";
  if (count ($onload))
    echo ' onload="init ();"';
  echo '><div class="'.$page.'page">';
}

/**
 * display the page footer
 */
function display_footer ()
{
  global $settings, $program, $logged_in, $editable, $path, $home;

  echo '
      <div class="footer"><table><tr>
        <td class="copyright"><small>'
    .make_link ("about", $home.$path, $program["name"])
    .' '.$program["copyright"];

  if ($settings["copyright"]["use"])
    {
      $holder = $settings["copyright"]["holder"];
      if (!empty ($settings["copyright"]["link"]))
        $holder = '<a href="'.$settings["copyright"]["link"].'">'
          .$holder.'</a>';

      echo ' Images copyright '
        .$settings["copyright"]["year"].' by '.$holder.', ';

      if ($settings["copyright"]["terms"])
        echo stripslashes (html_entity_decode
                           ($settings["copyright"]["terms"]));
      else
        echo 'licensed under a <a rel="license"'
          .' href="'.$settings["copyright"]["license_url"].'">'
          .'Creative Commons License</a>
         (except where otherwise noted).';
    }

  echo '
        </small></td>
        <td class="options"><small>';

  if ($logged_in)
    {
      if ($editable)
        echo make_link ("edit", $home.$path, "edit").'&nbsp;|&nbsp;';
      echo make_link ("setup", $home.$path, "setup").'&nbsp;|&nbsp;'
        .make_link ("logout", $home.$path, "log&nbsp;out");
    }
  else
    {
      echo make_link ("login", $home.$path, "log&nbsp;in");
    }

  echo '
        </small></td>
      </tr></table>
    </div>
';

  display_warnings ();

  echo '
  </body>
</html>';
}

/**
 * display the location bar
 */
function display_location ($custom = "", $title = false)
{
  global $settings, $home, $path;

  $root = $settings["main"]["root"];

  if (is_bool ($title))
    $title = $settings["main"]["title"];

  $loc = empty ($custom)
    ? render_path (true)
    : make_link (false, $home.$path, $settings["main"]["root"])
    .' | '.$custom;

  if (empty ($custom) and !empty ($settings["main"]["link"]))
    $title = '<a href="'.$settings["main"]["link"].'">'.$title.'</a>';

  echo '<div class="location">
  <table><tr>
    <td class="title">'.$title.'</td>
    <td class="location">'.$loc.'</td>
  </tr></table></div>
';
}

/**
 * generic display.
 */
function display_generic ($header, $location, $content)
{
  display_header ($header);
  display_location ($location);
  echo $content;
  display_footer ();
}


/* ALBUM RENDERING FUNCTIONS                                      byld
   -------------------------------------------------------------------
   
   functions  which  handle  all  the  details  involving  a  list  of
   albums.

   -------------------------------------------------------- */ ?><?php

/**
 * display a seperator between album and thumbnail lists.
 */
function display_seperator ()
{
  echo '<div class="seperator">&nbsp;</div>';
}

/**
 * if the album cover changes, all the old album thumbnails should be
 * removed.
 */
function delete_album_files ()
{
  global $path, $suffix_regexp;

  $here = @opendir ($path) or fatal ("cannot read $path");
  while ($file = readdir ($here))
  {
    if (preg_match ('/\.album'.$suffix_regexp.'/i', $file))
      unlink ($path.$file);
  }
}

/**
 * album description + stats.
 */
function render_album_description ($album, $ini, $dir, $hide)
{
  global $path, $home, $edit, $settings, $edit_current_item;

  $ret = "";
  if ($edit)
    {
      $cols = $settings["edit"]["cols"];
      $rows = $settings["edit"]["rows"];

      $checked = array_key_exists ($album, $hide) ? ' checked' : '';

      $ret .= '  <input type="hidden" name="filename_'
        .$edit_current_item.'" value="'.$album.'" />
  <p class="albuminfo">'.$album.'</p>
    <input class="text" type="text" name="title_'.$edit_current_item.'"
       value="'.@$ini["album"]["title"].'"'
        .($cols ? " size=\"$cols\"" : "").'>
    <br />
    <textarea'
        .($cols ? " cols=\"$cols\"" : "")
        .($rows ? " rows=\"$rows\"" : "")
        .' name="description_'.$edit_current_item.'">'
        .@$ini["album"]["description"]."</textarea><br />\n"
        ."hide this album: "
        .'<input type="checkbox" name="hide_'.$edit_current_item
        .'" '.$checked.">\n";
    }
  else
    {
      $title = $desc = $stats = '';

      if (array_key_exists ("title", $ini["album"]))
        $title = '  <p class="title">'.
          make_link (false, $home.$path.$album,
                     $ini["album"]["title"])."</p>\n";

      if (array_key_exists ("description", $ini["album"]))
        $desc = '  <p class="description">'
          .nl2br ($ini["album"]["description"])
          ."</p>\n";

      $dirc = count ($dir["albums"]);
      $imgc = count ($dir["thumbs"]);

      $stats .= '<p class="albuminfo">'
        .make_link (false, $home.$path.$album, $album)."<br />\n";

      if ($dirc) $stats .= $dirc." album".($dirc == 1 ? '' : 's');
      if ($dirc and $imgc) $stats .= ", ";
      if ($imgc) $stats .= $imgc." picture".($imgc == 1 ? '' : 's');
      if ($dirc or $imgc) $stats .= "<br />\n";

      $stats .= get_album_date ($path.$album);

      if ($settings["features"]["hitcount"])
        {
          $hits = array_key_exists ("hitcount", $ini["album"])
            ? $ini["album"]["hitcount"]
            : 0;
          $stats .= '<br />('.$hits.' hit'.($hits == 1 ? '' : 's').")\n";
        }

      $stats .= "</p>\n";

      if ($settings["style"]["info_order"])
        $ret = $title.$stats.'<div class="statsfirst">&nbsp;</div>'.$desc;
      else
        $ret = $title.$desc.'<div class="statslast">&nbsp;</div>'.$stats;
    }

  $edit_current_item++;
  return $ret;
}

/**
 * choose a cover image for this album.
 * FIXME: select random cover instead of first?
 */
function select_cover ($album, $dir)
{
  if (array_key_exists ("thumbs", $dir)
      and count ($dir["thumbs"]))
    {
      $img = current ($dir["thumbs"]);
      return $img["stats"]["filename"];
    }

  return "";
}

/**
 * update cover selects a cover image for an album if a cover hasn't
 * been selected yet, and saves this in album.ini
 */
function update_cover ($album, &$ini, $dir)
{
  global $path;

  /* if a cover is not set .. */
  if (!array_key_exists ("cover", $ini["album"])
      /* .. or the cover image file is not readable. */
      or !is_file (merge_path ($path, $album, $ini["album"]["cover"]))
      or !is_readable (merge_path ($path, $album, $ini["album"]["cover"])))
    {
      /* select a cover and save it. */
      $ini["album"]["cover"] = select_cover ($album, $dir);
      if (!empty ($ini["album"]["cover"]))
        write_album_ini ($ini, $album);
    }
}

/**
 * display albums in this directory.
 */
function display_albums ($dirs, $album_ini)
{
  global $settings, $path, $home, $render_thumbnail_size, $edit;

  $hide = false;
  if ($edit)
    $hide = convert_album_hidden ($album_ini);

  echo "\n<div class=\"albums\">\n";

  /* === display === */
  list ($width, $height) = decode_geometry ($settings["thumb"]["album"]);

  foreach ($dirs as $album => $ini)
    {
      $dir = read_sub_dir (merge_path ($path, $album));

      update_cover ($album, $ini, $dir);

      $dim = array ();
      if (!empty ($ini["album"]["cover"]))
        {
          $img = merge_path ($album, $ini["album"]["cover"]);
          $img_ini = read_image_ini ($path.$img);
          $thumb = render_thumbnail ($img, $img_ini["image"], "album");
          $dim = $render_thumbnail_size;
        }
      else
        {
          $thumb = render_broken_image_div ($settings["thumb"]["album"]);
          $dim[0] = $width ? $width : $height*4/3;
        }

      $style = '';
      $imgwidth = $width ? $width : $dim[0];
      if ($settings["style"]["album_width"] != '')
        {
          $imgwidth += $settings["style"]["album_width"];
          $style = ' style="width: '.$imgwidth.'px"';
        }

      echo '
  <div class="albumitem"'.$style.">\n"
        .make_link (false, $home.$path.$album, $thumb)."\n"
        .render_album_description ($album, $ini, $dir, $hide).'
    <div class="clearer">&nbsp;</div>
  </div>';
    }

  echo "</div>\n";
}

/* IMAGE VIEW RENDERING FUNCTIONS                                 byld
   -------------------------------------------------------------------
   
   functions which handle all the details of viewing a single image.

   -------------------------------------------------------- */ ?><?php

/**
 * render navbar links
 */
function render_navbar_links ()
{
  global $home, $path, $settings, $navbar_cache;

  if (!empty ($navbar_cache))
    return $navbar_cache;

  $prev = '';
  $next = '';
  $idx = dirname ($path);
  $current = basename ($path);

  $dir = read_sub_dir ($idx);
  $idx = merge_path ($home, $idx, ''); // force trailing slash.

  $curidx = false;
  reset ($dir["thumbs"]);
  $prev = key ($dir["thumbs"]);
  while (list($key, $val) = each($dir["thumbs"]))
    {
      if ($key == $current)
        {
          $curidx = $key;
          break;
        }

      $prev = $key;
    }
  $next = key ($dir["thumbs"]);

  if ($curidx == $prev) $prev = '';
  if ($curidx == $next) $next = '';

  $ret = array
    (
     empty ($prev)
     ? '<span class="disabled">'.$settings["navbar"]["prev"].'</span>'
     : make_link (false, $idx.$prev, $settings["navbar"]["prev"]),

     render_path (true, true),

     empty ($next)
     ? '<span class="disabled">'.$settings["navbar"]["next"].'</span>'
     : make_link (false, $idx.$next, $settings["navbar"]["next"]),
     );

  $navbar_cache = $ret;

  return $ret;
}

/**
 * render image comments
 */
function render_comments ($ini)
{
  $comments = array();

  $ret = '';

  foreach ($ini as $key => $val)
    {
      $idx = substr ($key, 4);
      if (!array_key_exists ($idx, $comments))
        $comments[$idx] = array ();

      $comments[$idx][substr ($key, 0, 4)] = $val;
    }

  foreach ($comments as $val)
    $ret .= '
  <p class="author"><span class="nick">'
    .htmlentities ($val["nick"]).'</span>
    <span class="date">('.$val["date"].')</span>
  </p>
  <p class="comment">'.nl2br (htmlentities ($val["text"])).'
  </p>
';

  return $ret;;
}

/**
 * display image description + user comments
 */
function display_comments ($ini)
{
  global $path, $home, $settings;

  echo '<div class="description">
  <p class="description">';

  if (array_key_exists ("description", $ini["image"])
      and !empty ($ini["image"]["description"]))
    echo nl2br ($ini["image"]["description"]);
  else
    echo basename ($path);

  echo "  </p>\n</div>\n";

  if (!$settings["features"]["comments"])
    return;

  echo '<div class="comments">';

  if (array_key_exists ("comments", $ini))
    echo render_comments ($ini["comments"]);

  echo '<div class="addbutton">
  <a href="#" onclick="'."show('addform'); return false;"
    .'">add comment</a>
</div>
<div class="addform0">
<div id="addform" class="addform">
  <form name="f" action="'.make_link
    ("submit_comment", $home.$path).'" method="post">
    <table class="addform">
      <tr><td class="addnick0">name:</td>
          <td class="addnick1"><input type="text" name="nick" /></td></tr>
      <tr><td class="addtext0">comment:</td>
          <td class="addtext1">
          <textarea rows="5" name="text"></textarea></td></tr>
      <tr><td colspan="2" class="addsubmit">
          <input type="submit" name="submit" value="submit"></td></tr>
    </table>
  </form>
</div>
</div>
</div>
';
}

/**
 * display navigation links
 */
function display_navbar ($width, $pos)
{
  global $settings;

  list ($prev, $idx, $next) = render_navbar_links ();

  echo '<div class="navbar '.$pos.'">
  <table class="navbar"><tr>
    <td class="prev">'.$prev.'</td>
    <td class="index">'.$idx.'</td>
    <td class="next">'.$next.'</td>
  </tr></table>
</div>';
}

/* THUMBNAIL RENDERING FUNCTIONS                                  byld
   -------------------------------------------------------------------
   
   functions  which  handle  all  the  details  involving  a  list  of
   thumbnails.

   -------------------------------------------------------- */ ?><?php

/**
 * compares the current size setting to the size of a thumbnail.
 * presumably the thumbnail needs to be recreated if that differs.
 *
 * @return bool returns true if the size matches, false otherwise.
 */
function check_size ($str, $arr)
{
  list ($width, $height) = decode_geometry ($str);

  if (!empty ($width) and ($width != $arr[0]))
    return false;

  if (!empty ($height) and ($height != $arr[1]))
    return false;

  return true;
}

/**
 * compares the date of the thumbnail with the date of the image.
 * if the image is newer, it is assumed the thumbnail is old,
 * and needs to be recreated.
 *
 * @return bool returns false if the thumbnail is old, false
 *              otherwise.
 */
function check_date ($thumb, $image)
{
  return (filemtime ($thumb) > filemtime ($image));
}

/**
 * delete thumbnail for image
 */
function delete_thumbnail ($file, $type)
{
  $f = get_thumbnail_filename ($file, $type);
  if (file_exists ($f))
    @unlink ($f) or warning ("cannot delete thumbnail: $f");
}

/**
 * delete thumbnails for image
 */
function delete_thumbnails ($file)
{
  delete_thumbnail ($file, 'thumb');
  delete_thumbnail ($file, 'album');
  delete_thumbnail ($file, 'cover');
  delete_thumbnail ($file, 'view');
}

/**
 * create thumbnail for image
 */
function create_thumbnail ($size, $rotate, $dst, $src)
{
  global $settings;

  echo '<div class="create">Creating thumbnail for '
    .basename ($src)." ... \n";
  flush ();

  if (!is_file ($src) or !is_readable ($src))
    {
      echo "error reading file.</div>\n";
      return;
    }

  create_thumbnail_magick ($size, $rotate, $dst, $src);

  echo "</div>";
}

/**
 * create thumbnail using imagemagick
 */
function create_thumbnail_magick ($size, $rotate, $dst, $src)
{
  global $settings;

  /*
     NOTE: because strings here get passed to a system() like function,
     we need to be extra careful not to allow user stuff in there.

     The geometry string parts are forced to integers with +0,
     and the rotate string isn't used at all.
  */

  $rot = '';
  if ($rotate == 90) $rot = '-rotate 90';
  if ($rotate == 180) $rot = '-rotate 180';
  if ($rotate == 270) $rot = '-rotate 270';
  if ($rotate == -90) $rot = '-rotate 270';

  list ($width, $height) = decode_geometry ($size);

  $scale = '';
  if ($width+0)
    $scale .= $width+0;
  if ($height+0)
    $scale .= 'x'.($height+0);

  if ($scale == 'x')
    {
      warning ("$size is not a valid geometry description.");
      return;
    }

  $convert = escapeshellcmd ($settings["misc"]["convert"]);

  if (!preg_match ('/^[^\ ]*convert(\.exe)?$/', $convert)
      or !is_executable ($convert)
      or is_writable ($convert))
    {
      warning ("$convert does not look like an imagemagick executable.");
      return;
    }

  $cmd = $convert.' "'.$src.'" '.$rot.' -scale '.$scale.' "'.$dst.'"';

  if (file_exists ($dst))
    unlink ($dst);

  exec ($cmd);

  if (!file_exists ($dst))
    warning ("command failed to create thumbnail file: $cmd");
}

/**
 * determine comment count.
 */
function count_comments ($comments)
{
  $count = 0;
  foreach ($comments as $key => $val)
    {
      $entry = substr ($key, 4);
      if ($entry > $count)
        $count = $entry;
    }

  return $count+1;
}

/**
 * render stats and bits from the exif data in an image
 */
function render_stats ($image, $data)
{
  global $home, $path, $settings;

  $file = $path.$image;
  $ret = '<p class="fileinfo">';

  $stats = $data["stats"];
  $ini = $data["ini"];

  $ret .= make_link (false, $home.$path.$image, $stats["filename"]).'<br />'
    .$stats["width"].'x'.$stats["height"].', '
    .pretty_size ($stats["filesize"]).'<br />'.$stats["date"].'<br />';

  if (!empty ($stats["camera"]))
    $ret .= $stats["camera"]."<br />\n";

  $hit = "";
  if ($settings["features"]["hitcount"])
    {
      $hits = array_key_exists ("hitcount", $ini["image"])
        ? $ini["image"]["hitcount"]
        : 0;

      $hit = $hits.' hit'.($hits == 1 ? '' : 's');
    }

  $com = "";
  if ($settings["features"]["comments"])
    {
      $comments = array_key_exists ("comments", $ini)
        ? count_comments ($ini["comments"])
        : 0;

      $com = $comments.' comment'.($comments == 1 ? '' : 's');
    }

  if (!empty ($hit) and !empty ($com))
    $ret .= '('.$hit.', '.$com.')';
  else if (!empty ($hit))
    $ret .= '('.$hit.')';
  else if (!empty ($com))
    $ret .= '('.$com.')';

  return $ret.'</p>';
}

/**
 * get a list of hidden albums from the supplied album ini
 */
function convert_album_hidden ($ini)
{
  $hide = array ();
  if (array_key_exists ("hide", $ini))
    foreach ($ini["hide"] as $val)
      $hide[$val] = true;

  return $hide;
}

/**
 * read exif data and other stats for image.
 */
function read_image_stats ($file)
{
  global $date_format;

  $stats = array ();

  if (!is_file ($file) or !is_readable ($file))
    {
      warning ("error reading $file.");
      return;
    }

  $exif = simple_exif ($file);

  if (array_key_exists ("0x0110", $exif))
    $stats["camera"] = $exif["0x0110"]; // IFD0 Model

  if (array_key_exists ("0x9003", $exif))
    $stats["date"] = $exif["0x9003"]; // SubIFD DateTimeOriginal

  /* get basic info with getimagesize (); */
  list ($stats["width"], $stats["height"],
        $stats["type"],  $stats["str"]) = getimagesize ($file);
  $stats["filename"] = basename ($file);
  $stats["filesize"] = filesize ($file);

  if (empty ($stats["date"]))
    $stats["date"] = date ($date_format, filemtime ($file));

  return $stats;
}

/**
 * a little helper for render_thumbnail_description ()
 */
function render_thumbnail_rotatebutton ($rotate, $str, $ini)
{
  global $edit_current_item;

  return '  <input type="radio" name="rotate_'.$edit_current_item
    .'" value="'.$rotate.'"'
    .(($ini["rotate"] == $rotate) ? ' checked' : '')." /> ".$str."\n";
}

/**
 * render the description+filestats for a thumbnail
 */
function render_thumbnail_description ($data)
{
  global $edit, $settings, $edit_current_item;

  $ini = $data["ini"]["image"];
  $image = $data["stats"]["filename"];

  $ret = "";
  if ($edit)
    {
      $cols = $settings["edit"]["cols"];
      $rows = $settings["edit"]["rows"];

      $album = read_album_ini ();
      $checked = (array_key_exists ("cover", $album["album"])
                  and $album["album"]["cover"] == $image) ? ' checked' : '';

      $ret .= '  <input type="hidden" name="filename_'
        .$edit_current_item.'" value="'.$image.'" />';
      $ret .= '  <textarea'
        .($cols ? " cols=\"$cols\"" : "")
        .($rows ? " rows=\"$rows\"" : "")
        .' name="description_'.$edit_current_item.'">'
        .@$ini["description"]."</textarea><br />\n";

      if (!array_key_exists ("rotate", $ini)
          or ($ini["rotate"] != 90
              and $ini["rotate"] != 180
              and $ini["rotate"] != 270))
        $ini["rotate"] = 0;

      $ret .= "rotate (cw):\n"
        .render_thumbnail_rotatebutton (0,   "0",   $ini)
        .render_thumbnail_rotatebutton (90,  "90",  $ini)
        .render_thumbnail_rotatebutton (180, "180", $ini)
        .render_thumbnail_rotatebutton (270, "-90", $ini)
        ."<br />\n"
        ."use this as album cover: "
        .'<input type="radio" name="album_cover" value="'
        .$image.'"'.$checked.">\n";
    }
  else
    {
      $desc = '';
      $stats = '';

      if (array_key_exists ("description", $ini)
          and !empty ($ini["description"]))
        $desc .= '  <p class="description">'
          .nl2br ($ini["description"])
          ."</p>\n";

      $stats .= render_stats ($image, $data);

      if ($settings["style"]["info_order"])
        $ret = $stats.'<div class="statsfirst">&nbsp;</div>'.$desc;
      else
        $ret = $desc.'<div class="statslast">&nbsp;</div>'.$stats;
   }

  $edit_current_item++;
  return $ret;
}

/**
 * determine thumbnail filename for an image.
 */
function get_thumbnail_filename ($file, $type = "thumb")
{
  global $suffix_regexp;

  return preg_replace ('/'.$suffix_regexp.'/i', '.'.$type.'$1', $file);
}

/**
 * render a div as a stub for a missing thumbnail.
 */
function render_broken_image_div ($size)
{
  list($width, $height) = decode_geometry ($size);

  $ret = '<div class="broken" style="'
    .($width ? 'width: '.$width : 'height: '.$height)
    .'px">&nbsp;</div>';

  return $ret;
}

/**
 * renders a thumbnails, also creates thumbnails on demand.
 */
function render_thumbnail ($image, $ini, $type = "thumb", $full = false)
{
  // render_thumbnail_size is a workaround, i had trouble
  // using references on 4.1.x, so this will have to do.
  global $path, $home, $settings, $render_thumbnail_size;

  $key = ($type == "thumb") ? "image" : $type;
  $our_size = $settings["thumb"][$key];

  $thumbfile = get_thumbnail_filename ($path.$image, $type);

  $rotate = 0;
  if (array_key_exists ("rotate", $ini))
    $rotate = $ini["rotate"];

  if (is_file ($thumbfile) and is_readable ($thumbfile))
    $size = getimagesize ($thumbfile);

  if (!is_file ($thumbfile)
      or !is_readable ($thumbfile)
      or !check_size ($our_size, $size)
      or !check_date ($thumbfile, $path.$image))
    {
      create_thumbnail ($our_size, $rotate, $thumbfile, $path.$image);
    }

  if (is_file ($thumbfile) and is_readable ($thumbfile))
    {
      $size = getimagesize ($thumbfile);
      $render_thumbnail_size = $size;
      return '<img class="'.$type.'" '.$size[3].' src="'
        .make_file_link (basename ($thumbfile),
                         $home.dirname ($thumbfile), false, $full).'" />';
    }

  warning ("error creating or reading thumbnail (".$thumbfile.")\n");

  // FIXME: what was this for?
  //  $render_thumbnail_size = $size;
  return render_broken_image_div ($our_size);
}

/**
 * display thumbnails of images in this directory.
 */
function display_thumbnails ($imgs)
{
  global $settings, $path, $home, $render_thumbnail_size;

  echo "\n<div class=\"thumbnails\">\n";

  /* === display === */
  list ($width, $height) = decode_geometry ($settings["thumb"]["image"]);

  foreach ($imgs as $image => $data)
    {
      $style = '';
      $imgtag = render_thumbnail ($image, $data["ini"]["image"]);
      $dim = $render_thumbnail_size;

      $imgwidth = $width ? $width : $dim[0];
      if ($settings["style"]["thumb_width"] != '')
        {
          $imgwidth += $settings["style"]["thumb_width"];
          $style = ' style="width: '.$imgwidth.'px"';
        }

      echo '
  <div class="thumbitem"'.$style.">\n"
        .make_link (false, $home.$path.$image, $imgtag)."\n"
        .render_thumbnail_description ($data).'
    <div class="clearer">&nbsp;</div>
  </div>';
    }

  echo "</div>\n";
}

/**
 * display cover
 */
function display_cover ($data)
{
  global $settings, $path, $home, $render_thumbnail_size;

  echo "\n<div class=\"cover\">\n";

  list ($width, $height) = decode_geometry ($settings["thumb"]["cover"]);

  $file = $data["stats"]["filename"];
  $ini = $data["ini"]["image"];

  $style = '';
  $imgtag = render_thumbnail ($file, $ini, "cover");
  $dim = $render_thumbnail_size;

  $imgwidth = $width ? $width : $dim[0];
  if ($settings["style"]["cover_width"] != '')
    {
      $imgwidth += $settings["style"]["cover_width"];
      $style = ' style="width: '.$imgwidth.'px"';
    }

  echo '
  <div class="coveritem"'.$style.">\n"
    .make_link (false, $home.$path.$file, $imgtag)."\n"
    .render_thumbnail_description ($data).'
    <div class="clearer">&nbsp;</div>
  </div>';

  echo "</div>\n";
}

/* ACTION FUNCTIONS                                               byld
   -------------------------------------------------------------------

   action_* functions are the actions called from main ().

   -------------------------------------------------------- */ ?><?php

/**
 * provide a .zip file with the code.
 */
function action_download ()
{
  global $program;

  $file = $_SERVER["SCRIPT_FILENAME"];
  $path = dirname ($file);

  $zip = new zipfile;
  $zip->add_file ('', $file, "byld.php");

  $php = list_source ();
  $css = list_stylesheets ();

  foreach ($php as $val)
    $zip->add_file ($path, $val);

  foreach ($css as $val)
    {
      $js = get_companion_js_file ($val);

      $zip->add_file ($path, $val);
      if (!empty ($js))
        $zip->add_file ($path, $js);
    }

  header ('Content-type: application/octet-stream');
  header ('Content-disposition: attachment; filename="byld-'
          .$program["version"].'.zip"');
  header ('Content-Transfer-Encoding: binary');

  echo $zip->file ();
}

/**
 * login screen
 */
function action_login ()
{
  global $settings, $path, $home;

  display_header ("login", "document.f.password");
  display_location ("log in");

  echo '<div class="login">
  <form name="f" action="'.make_link
    ("login2", $home.$path).'" method="post">
  Please enter password:<br />
    <input name="password" type="password" size="20" />
    <input type="submit" name="submit" value="submit" />
  </form>
</div>
';

  display_footer ();
}

/**
 * about screen
 */
function action_about ()
{
  global $program;

  display_header ("about");
  display_location ("about", $program["name"].' '.$program["version"]);
  echo render_about ();
  display_footer ();
}


/**
 * display a photo album page
 */
function action_album ()
{
  global $edit, $home, $path;

  $ini = hit ();

  if (!$ini)
    $ini = read_album_ini ();

  display_header ("album");

  $dir = read_dir ($path);

  display_location ();

  if ($edit)
    echo '<form name="f" action="'
      .make_link ("submit_albumview", $home.$path).'" method="post">';

  $order = decode_sectionorder ();
  $first = true;
  foreach ($order as $val)
    {
      if ($val == 'cover')
        if (count ($dir["images"]) == 1)
          {
            if (!$first) display_seperator (); $first = false;
            display_cover (current ($dir["thumbs"]));
          }


      if ($val == 'thumb')
        if (count ($dir["images"]) and count ($dir["images"]) != 1)
          {
            if (!$first) display_seperator (); $first = false;
            display_thumbnails ($dir["thumbs"]);
          }

      if ($val == 'album')
        if (count ($dir["albums"]))
          {
            if (!$first) display_seperator (); $first = false;
            display_albums ($dir["albums"], $ini);
          }

    }

  if ($edit)
      echo '  <div class="buttons">
    <input type="submit" name="cancel" value="cancel">
    <input type="submit" name="submit" value="save">
  </div></form>
';

  display_metadata ();
  display_footer ();
}

/**
 * display an image page
 */
function action_image ()
{
  global $path, $home, $settings;

  $ini = hit ();
  if (!$ini)
    $ini = read_image_ini ();

  display_header ("image");

  list ($width, $height) = decode_geometry ($settings["thumb"]["view"]);

  echo '<div class="image"'
    .(($settings["style"]["view_width"] != '' and $width)
      ? ' style="width: '.($width+$settings["style"]["view_width"]).'px">'
      : '>');

  display_navbar ($ini, "top");

  echo make_file_link
    (basename ($path), $home.dirname ($path),
     render_thumbnail ("", $ini["image"], $type = "view"));

  display_comments ($ini);
  display_navbar ($ini, "bottom");

  echo '</div>
    </div>
';

  display_warnings ();
  display_metadata ();

  echo '
  </body>
</html>';
}

/**
 * store submitted changes.
 */
function action_submit_albumview ()
{
  global $path, $settings;

  if (array_key_exists ("cancel", $_POST))
    return;

  $album_ini = read_album_ini ();
  $album_ini["hide"] = array ();

  foreach ($_POST as $key => $filename)
    {
      if ($key == "album_cover")
        {
          if (@$album_ini["album"]["cover"] != $filename)
            {
              $album_ini["album"]["cover"] = $filename;
              delete_album_files ();
            }
          continue;
        }

      if (substr ($key, 0, 8) != "filename")
        continue;

      $ini = array ();
      $count = substr ($key, 9);

      if (@$_POST["hide_".$count] == "on")
        {
          if (!array_key_exists ("hide", $album_ini))
            $album_ini["hide"] = array ();

          /* ==== hide album === */
          $album_ini["hide"][] = $filename;
          continue;
        }

      if (array_key_exists ("title_".$count, $_POST))
        {
          /* ==== submit album === */
          $ini["album"]["description"] = $_POST["description_".$count];
          $ini["album"]["title"] = $_POST["title_".$count];

          if (get_magic_quotes_gpc ())
            {
              $ini["album"]["description"] =
                stripslashes($ini["album"]["description"]);
              $ini["album"]["title"] =
                stripslashes($ini["album"]["title"]);
            }

          $ini_file = merge_path ($path, $filename, "album.ini");

          $old_ini = array ();
          if (is_file ($ini_file) and is_readable ($ini_file))
            $old_ini = read_album_ini ($filename);

          $ini["album"]["cover"] = @$old_ini["album"]["cover"];

          if (!array_key_exists ("description", $old_ini["album"]))
            $old_ini["album"]["description"] = '';
          if (!array_key_exists ("title", $old_ini["album"]))
            $old_ini["album"]["title"] = '';

          if (empty ($old_ini["album"]["description"])
              and empty ($old_ini["album"]["title"])
              and (!empty ($ini["album"]["description"])
                   or (!empty ($ini["album"]["title"]))))
            syndicate_item ("album", merge_path ($path, $filename), $ini);

          write_album_ini ($ini, $filename);
        }
      else
        {
          /* ==== submit thumb === */
          $ini["image"] = array ();
          $ini["image"]["rotate"] = $_POST["rotate_".$count];
          $ini["image"]["description"] = $_POST["description_".$count];

          if (get_magic_quotes_gpc ())
            $ini["image"]["description"] =
              stripslashes($ini["image"]["description"]);

          $old_ini = array ();
          if (is_file ($path.$filename)
              and is_readable ($path.$filename))
            $old_ini = read_image_ini ($path.$filename);

          if (!array_key_exists ("rotate", $old_ini["image"]))
            $old_ini["image"]["rotate"] = 0;

          if ($old_ini["image"]["rotate"] != $ini["image"]["rotate"])
            delete_thumbnails ($path.$filename);

          if (array_key_exists ("comments", $old_ini))
            $ini["comments"] = $old_ini["comments"];

          if (!array_key_exists ("description", $old_ini))
            $old_ini["description"] = '';

          if (empty ($old_ini["image"]["description"])
              and !empty ($ini["image"]["description"]))
            syndicate_item ("image", merge_path ($path, $filename), $ini);

          if (is_file ($path.$filename))
            write_image_ini ($ini, $path.$filename);
        }
    }

  write_album_ini ($album_ini);
}

/**
 * store submitted changes.
 */
function action_submit_comment ()
{
  global $path, $date_format;

  $addr = $_SERVER["REMOTE_ADDR"];
  $nick = $_POST["nick"];
  $text = $_POST["text"];
  $date = date ($date_format);

  if (get_magic_quotes_gpc ())
    {
      $nick = stripslashes ($nick);
      $text = stripslashes ($text);
    }

  if (empty ($nick) or empty ($text))
    {
      warning ("empty nick or comment");
      return;
    }

  $ini = read_image_ini ();

  $count = 0;
  if (!array_key_exists ("comments", $ini))
    $ini["comments"] = array ();
  else
    $count = count_comments ($ini["comments"]);

  $ini["comments"]["date".$count] = $date;
  $ini["comments"]["nick".$count] = $nick;
  $ini["comments"]["text".$count] = $text;
  $ini["comments"]["addr".$count] = $addr;

  write_image_ini ($ini);

//  syndicate_comment ($nick, $date, $text, render_path (false),
  syndicate_comment ($nick, $date, $text, basename ($path),
                     $path, "comment".$count, $ini);
}

/**
 * store submitted changes.
 */
function action_submit_setup ()
{
  global $settings, $date_format;

  /* cancel. */
  if (array_key_exists ("cancel", $_POST))
    return;

  /* reset to defaults. */
  if (array_key_exists ("reset", $_POST))
    {
      $password = $settings["main"]["password"];
      set_defaults ();
      $settings["main"]["password"] = $password;
      $settings["changed"] = array ();
      $settings["changed"]["addr"] = $_SERVER["REMOTE_ADDR"];
      $settings["changed"]["date"] = date ($date_format, time ());
      $settings["main"]["first_install"] = false;
      write_ini ();
      return;
    }

  /* change password. */
  if (!empty ($_POST["password0"]))
    {
      if ($settings["main"]["password"] != md5 ($_POST["password0"]))
        fatal ('invalid password, please click '
               .'<a href="javascript:back()">back</a> and try again.');

      if ($_POST["password1"] != $_POST["password2"])
        fatal ("passwords don't match, please click "
               .'<a href="javascript:back()">back</a> and try again.');

      $settings["main"]["password"] = md5 ($_POST["password1"]);
    }

  /* process rest of settings. */
  foreach ($_POST["main"] as $key => $val)
    $settings["main"][$key] = htmlentities ($val);

  foreach ($_POST["features"] as $key => $val)
    $settings["features"][$key] = $val;

  foreach ($_POST["copyright"] as $key => $val)
    {
      if ($key == 'use')
        $settings["copyright"][$key] = $val;
      else
        $settings["copyright"][$key] = htmlentities ($val);
    }

  if (!empty ($settings["copyright"]["terms"]))
    {
      $settings["copyright"]["license_name"] = "none";
      $settings["copyright"]["license_url"] = "";
      $settings["copyright"]["metadata"] = "";
    }

  foreach ($_POST["thumb"] as $key => $val)
    $settings["thumb"][$key] = $val;

  foreach ($_POST["sort"] as $key => $val)
    $settings["sort"][$key] = $val;

  foreach ($_POST["style"] as $key => $val)
    $settings["style"][$key] = $val;

  foreach ($_POST["misc"] as $key => $val)
    $settings["misc"][$key] = $val;

  foreach ($_POST["rewrite"] as $key => $val)
    $settings["rewrite"][$key] = $val;

  if ($settings["rewrite"]["dump_htaccess"])
    {
      if (!dump_htaccess ())
        $settings["rewrite"]["enable"] = false;
      unset ($settings["rewrite"]["dump_htaccess"]);
    }

  if (!$settings["rewrite"]["enable"])
    delete_htaccess ();

  $settings["changed"] = array ();
  $settings["changed"]["addr"] = $_SERVER["REMOTE_ADDR"];
  $settings["changed"]["date"] = date ($date_format, time ());
  $settings["main"]["first_install"] = false;

  $submit = @$_POST["submit"];

  if ($submit == 'select license'
      or $submit == "Sampling"
      or $submit == "Sampling Plus"
      or $submit == "Noncommercial Sampling Plus")
    {
      $settings["copyright"]["terms"] = "";
      write_ini ();
      creativecommons_select ($submit);
    }
  else
    {
      write_ini ();
    }
}

/* SETUP FUNCTIONS                                                byld
   -------------------------------------------------------------------

   Functions to edit byld.ini.php

   -------------------------------------------------------- */ ?><?php

/**
 * render an edit box for the setup page.
 */
function render_editbox ($label, $section, $key, $size)
{
  global $settings;

  return '<tr><td class="label">'.$label.'</td>
      <td class="input">
        <input type="text" name="'.$section.'['.$key.']"
         size="'.$size.'" value="'
    .$settings[$section][$key].'" /></td></tr>
';
}

/**
 * render a textarea for the setup page.
 */
function render_textarea ($label, $section, $key, $cols, $rows)
{
  global $settings;

  return '<tr><td class="label">'.$label.'</td>
      <td class="input">
        <textarea name="'.$section.'['.$key.']"
         cols="'.$cols.'" rows="'.$rows.'">'
    .$settings[$section][$key].'</textarea/></td></tr>
';
}

/**
 * render a password edit box for the setup page.
 */
function render_password ($label, $name, $size)
{
  global $settings;

  return '<tr><td class="label">'.$label.'</td>
      <td class="input">
        <input type="password" name="'.$name.'"
         size="'.$size.'" value="" /></td></tr>
';
}

/**
 * render radio buttons for a boolean.
 */
function render_boolean ($label, $section, $key, $labeltrue, $labelfalse)
{
  global $settings;

  $true = $settings[$section][$key] ? ' checked' : '';
  $false = !$settings[$section][$key] ? ' checked' : '';

  return '<tr><td class="label">'.$label.'</td>
      <td class="input">
      <input type="radio" name="'.$section.'['.$key.']"
         value="1"'.$true.' /> '.$labeltrue.'
      <input type="radio" name="'.$section.'['.$key.']"
         value="0"'.$false.' /> '.$labelfalse.'
     </td></tr>
';
}

/**
 * render a dropdown box
 */
function render_dropdown ($label, $section, $key, $options)
{
  global $settings;

  if (!count ($options))
    return '';

  $ret = '<tr><td class="label">'.$label.'</td>
      <td class="input">
        <select size="1" name="'.$section.'['.$key.']">
';

  $sel = $settings[$section][$key];
  if (array_key_exists ($sel, $options))
    {
      $ret .= '<option value="'.$options[$sel].'" selected>'
        .$options[$sel]."</option>\n";
      unset ($options[$sel]);
    }

  foreach ($options as $val)
    $ret .= '<option value="'.$val.'"'
    .($settings[$section][$key] == $val ? ' selected' : '')
    .'>'.$val."</option>\n";

  $ret .= "        </select>\n      </td></tr>\n";

  return $ret;
}

/**
 * display the setup page
 */
function render_setup ()
{
  global $settings, $path, $home;

  $ret = '';

  $ret .= '<div class="setup">
  <form name="f" action="'
    .make_link ("submit_setup", $home.$path).'" method="post">';

  $ret .= '
  <div class="setupsection">
  <h3>change password</h3>
  <p>Enter both old and new passwords if you wish to change
    the password.</p>

  <table class="setup">
'.render_password ("old password:", "password0", 20).'
'.render_password ("new password:", "password1", 20).'
'.render_password ("once more:", "password2", 20).'
  </table>
  </div>

  <div class="setupsection">
  <h3>main</h3>
  <table class="setup">
'.render_editbox ("Photo Album title:", "main", "title", 32).'
  <tr><td colspan="2">&nbsp;<br />
    If your photo album is part of a larger site, you can specify an
    url here so visitors can return to your site.
  </td></tr>
'.render_editbox ("url", "main", "link", 32).'
'.render_editbox ("root album name:", "main", "root", 16).'
'.render_editbox ("path seperator:", "main", "seperator", 6).'
  </table>
  </div>

  <div class="setupsection">
  <h3>copyright</h3>
  <table class="setup">
'.render_boolean
    ("add copyright notice:", "copyright", "use", "yes", "no").'
'.render_editbox ("copyright holder:", "copyright", "holder", 32).'
  <tr><td colspan="2">&nbsp;<br />
    If wish to link to your home page or email, specify a mailto: or
    http:// url here.
  </td></tr>
'.render_editbox ("link:", "copyright", "link", 32).'
'.render_editbox ("copyright date:", "copyright", "year", 32).'
  <tr><td colspan="2">&nbsp;<br />
  <p>
  To license your work, you can:
  </p>
  &bull; select a standard creative commons license:
  </td></tr>
  <tr><td>&nbsp;</td><td>
    <input type="submit" name="submit" value="select license" />
  </td></tr>
  <tr><td colspan="2">&nbsp;<br />
  &bull; select one of the <a
        href="http://creativecommons.org/license/sampling?format=image"
        >creative commons sampling licenses</a>:
  <tr><td>&nbsp;</td><td>
   <input type="submit" name="submit" value="Sampling" /><br />
   <input type="submit" name="submit" value="Sampling Plus" /><br />
   <input type="submit" name="submit" value="Noncommercial Sampling Plus" />
  </td></tr>
  <tr><td colspan="2">&nbsp;</td></tr>
  '.render_editbox
    ("&bull; or enter the license terms:", "copyright", "terms", 32).'
';

  if (empty ($settings["copyright"]["terms"]))
    $ret .= '<tr><td colspan="2">&nbsp;<br />
   Currently selected creative commons license: '
      .$settings["copyright"]["license_name"].'
  </td></tr>';

$ret .= '
  </table>
  </div>

  <div class="setupsection">
  <h3>features</h3>
  <table class="setup">
'.render_boolean
    ("hitcounter:", "features", "hitcount", "enable", "disable").'
  <tr><td colspan="2">&nbsp;<br />
    If you enable comments, visitors of your photo album will be able
    to leave comments to pictures.
  </td></tr>
'.render_boolean
    ("enable comments:", "features", "comments", "enable", "disable").'
  <tr><td colspan="2">&nbsp;<br />
    If you enable rss, two rss feeds will be available:
    <ul>
    <li>'.make_file_link ('new.xml', $home, 'new.xml', true).' is used
    to let visitors know about new pictures on your photo album, a picture
    or album is added to this feed the first time a description is
    entered for it.</li>
    <li>'.make_file_link ('comments.xml', $home, 'comments.xml', true).'
    is used when a user adds a comment anywhere on your photo album,
    this is to let you know when visitors have added comments.</li>
    </ul>
  </td></tr>
'.render_boolean
    ("enable rss:", "features", "use_rss", "enable", "disable").'
  </table>
  </div>


  <div class="setupsection">
  <h3>thumbnail sizes</h3>
  <p>Sizes are in the WIDTHxHEIGHT format, either is optional.<br />
   examples:</p>
  <pre>
   400x300   - thumbnails will always be resized to 400x300.
   400       - thumbnails are 400 pixels wide, and maintain aspect ratio.
   x300      - thumbnails are 300 pixels high, and maintain aspect ratio.
   </pre>

  <table class="setup">
'.render_editbox ("image list (images):", "thumb", "image", 8).'
'.render_editbox ("image list (albums):", "thumb", "album", 8).'
'.render_editbox ("image view:", "thumb", "view", 8).'
'.render_editbox ("album cover:", "thumb", "cover", 8).'
  </table>
  </div>

  <div class="setupsection">
  <h3>sort order</h3>

  <table class="setup">
'.render_dropdown ("album sort type:", "sort", "album_type",
                   array ("filename", "date")).'
'.render_boolean ("reverse order:", "sort", "album_reverse", "yes", "no").'
'.render_dropdown ("image sort type:", "sort", "thumb_type",
                   array ("filename", "date")).'
'.render_boolean ("reverse order:", "sort", "thumb_reverse", "yes", "no").'

  </table>
  </div>

  <div class="setupsection">
  <h3>formatting</h3>

  <table class="setup">

  <tr><td colspan="2">&nbsp;<br />
    A stylesheet defines how the photo album looks, it is recommended
    that you write your own.  However, a few options are provided which
    you can use.
    <ul>
    <li>photo.css is a fairly straightforward style, somewhat similar to
        the old photo.php design.</li>
    <li>grid.css is a grid layout, which in my opinion is much nicer :).
      The only reason it is not the default setting is because your
      visitors will need javascript enabled in their browser.</li>
    </ul>
    More choices may be available, feel free to try them to see if
    they suite your taste.
  </td></tr>
'.render_dropdown ("stylesheet:", "style", "stylesheet",
                   list_stylesheets ()).'

  <tr><td colspan="2">&nbsp;<br />
    A cover page in byld is any album which contains just
    one picture.  If you enable <i>use covers</i> below, the album
    list will be shown differently if the album contains a single
    picture.
  </td></tr>
'.render_boolean ("use covers:", "style", "cover", "yes", "no").'

  <tr><td colspan="2">&nbsp;<br />
    Please select the order of the various sections.  Note that
    only the cover or thumb section will be shown on any given
    page, they will never appear both.
  </td></tr>
'.render_dropdown ("section order:", "style", "order",
                   list_sectionorder ()).'
'.render_boolean ("description order:", "style", "info_order",
                   "stats first", "stats last").'
  </table>
  </div>

  <div class="setupsection">
  <h3>miscellaneous</h3>
  <table class="setup">
  <tr><td colspan="2">
    <p>You need imagemagick to use this photo album,
       GD is no longer supported.</p>
    <p>Path to the imagemagick convert utility.</p>
  </td></tr>
'.render_editbox ("convert:", "misc", "convert", 20).'
  </table>
  </div>

  <div class="setupsection">
  <h3>debugging</h3>

  <table class="setup">
  <tr><td colspan="2">&nbsp;<br />
    Inline css can be useful if you are making small tweaks to
    the .css file, and the browser insists on caching it.  You
    could also enable it if you happen to be using an ISP which
    sends the wrong mime-type for .css files.
  </td></tr>
'.render_boolean ("inline css:", "misc", "inline_css", "yes", "no").'

  </table>
  </div>

  <div class="setupsection">
  <h3>experimental</h3>

  <table class="setup">
'.render_editbox ("root url:", "rewrite", "home", 32).'

  <tr><td colspan="2">&nbsp;<br />
    WARNING: url rewriting support is in development, and needs a lot
    of testing.  It should in theory work in most situations, but
    probably does not in yours.
  </td></tr>
'.render_boolean ("use rewrite:", "rewrite", "enable", "yes", "no").'
'  /* FIXME: change this to a checkbox: */
.render_boolean ("write .htaccess:", "rewrite",
                 "dump_htaccess", "yes", "no").'
  </table>
  </div>

  <div class="setupbuttons">
    <input type="submit" name="reset" value="reset to defaults" />
    <input type="submit" name="cancel" value="cancel" />
    <input type="submit" name="submit" value="save" />
  </div>
</form>
</div>
';

  return $ret;
}

/* AUTHENTICATION FUNCTIONS                                       byld
   -------------------------------------------------------------------

   Currently authentication is very  simple.  Only a password needs to
   be supplied by the user.   The password is md5()'ed and compared to
   the stored md5(password) in byld.ini.php.
   
   If  there  is  no  byld.ini.php  or no  password  is  specified  in
   byld.ini.php,  an attempt  will be  made  to save  the password  to
   byld.ini.php.
   
   -------------------------------------------------------- */ ?><?php

/**
 * check to see if this is a new installation, which still needs to be
 * configured.
 */
function check_first_install ($a)
{
  global $settings;

  /* ok,.. you can go to setup.. */
  if ($a == "setup" or $a == "login" or $a == "submit_setup")
    return false;

  /* redirect to welcome page on first install. */
  if (@$settings["main"]["first_install"])
    return true;

  return false;
}

/**
 * render a string with information on the current user and
 * the groups we're member of.
 */
function render_current_user ()
{
  if (!function_exists ("posix_getgid"))
    return basename ($_SERVER["PHP_SELF"]);

  $gid = posix_getgrgid (posix_getgid ());
  $uid = posix_getpwuid (posix_getuid ());
  return "user ".$uid["name"]." or group ".$gid["name"];
}

/**
 * check to see if any login credentials are supplied, and if so,...
 * that they are correct.
 *
 * returns false if the new install page should be shown.
 */
function check_login ($a)
{
  global $home, $path, $settings, $logged_in, $ini_filename;

  $logged_in = false;

  $attempt = array_key_exists ("password", $_REQUEST)
    ? md5 ($_REQUEST["password"]) : "";


  /* no password configured, assume new installation. */
  if ($settings["main"]["password"] == "EMPTY")
    {
      /* no password supplied, so show new installation screen. */
      if (empty ($attempt))
        return false;

      /* password supplied, so save password and show welcome screen. */
      $settings["main"]["password"] = $attempt;
      $settings["main"]["first_install"] = true;
      if (write_ini ())
        display_generic
          ("login", "new user", '<div class="message">'
           .'<p>NOTE: new installation detected, password saved to '
           .$ini_filename.'</p><p>Please '
           .make_link ("login", $home.$path, "log in").'.</p></div>');
      else
        fatal ("cannot write configuration file, please make sure "
                 .realpath ($path)." is writable by "
                 .render_current_user ().".<br />\nCheck the "
                 .make_link ("about", $home.$path, "about")
                 ." page for more information.");

      exit ('');
    }

  /* check for password in cookie. */
  if (empty ($attempt))
    {
      if (array_key_exists ("passwd", $_COOKIE)
          and $settings["main"]["password"] == $_COOKIE["passwd"])
        $logged_in = true;

      return true;
    }

  /* check for password in querystring. */
  if ($settings["main"]["password"] == $attempt)
    {
      $logged_in = true;
      setcookie ("passwd", $attempt, 0, "/");
      return true;
    }

  display_generic
    ("login", "login failed", '<div class="error">Login failed.</div>');

  exit ('');
}

/* URL FUNCTIONS                                                  byld
   -------------------------------------------------------------------

   both make...link functions will render a full <a href> link if
   $title is specified.  The current album path will be used if
   $newpath is not specified.  Always use a full path for $newpath,
   use $home and/or $path to make one :)

   make_link takes an action as a first argument.
   make_file_link takes a filename relative to the selected path.

   -------------------------------------------------------- */ ?><?php

/**
 * render a link to a file.
 */
function make_file_link ($file, $newpath = false,
                         $title = false, $full = false)
{
  global $path, $home, $settings;

  $err = '';

  if (is_bool ($newpath))
    $newpath = $home.$path;

  if (substr ($newpath, 0, 1) != '/')
    fatal ("internal error in ".__FUNCTION__);

  $ret = merge_path ($newpath, $file);

  $ret = str_replace ('/./', '/', $ret);

  //  if ($settings["rewrite"]["enable"])
  //    warning ("unsupported (make_file_link result: $ret).");

  if ($full)
    $ret = 'http://'.$_SERVER["SERVER_NAME"].$ret;

  if (is_bool ($title))
    return $ret;

  return '<a href="'.$ret.'">'.$title.'</a>';
}

/**
 * render a link with specified action and path.
 *
 * please always specify a full path as $newpath, you can use
 * $home (root) and/or $path (pwd) prefixes to form a full path.
 */
function make_link ($action = '', $newpath = false,
                    $title = false, $full = false, $anchor = false)
{
  global $path, $home, $settings;
  $ret = "";

  if (is_bool ($newpath))
    $newpath = $home.$path;

  if (substr ($newpath, 0, strlen ($home)) != $home)
    fatal ("internal error in ".__FUNCTION__);

  $newpath = str_replace ('/./', '/', $newpath);
  $newpath = substr ($newpath, strlen ($home));

  if ($settings["rewrite"]["enable"])
    {
      if (is_dir (merge_path (dirname (__FILE__), $newpath)))
        // adding an empty string makes sure there is a trailing
        // slash on newpath.
        $newpath = merge_path ($newpath, '');
      else if (empty ($action))
        $newpath = $newpath.'.html';

      // FIXME: make these relative links some day.
      $ret = merge_path ($home, $newpath);

      if (!empty ($action))
        $ret = merge_path ($ret, $action.".html");
    }
  else
    {
      $ret = $home.basename ($_SERVER["PHP_SELF"]);
      $sep = '?';

      if (!empty ($action))
        {
          $ret .= $sep."a=".$action;
          $sep = '&amp;';
        }

      if (!empty ($newpath))
        $ret .= $sep."path=". urlencode ($newpath);
    }

  if (!is_bool ($anchor))
      $ret .= '#'.$anchor;

  if ($full)
    $ret = 'http://'.$_SERVER["SERVER_NAME"].$ret;

  if (is_bool ($title))
    return $ret;

  return '<a href="'.$ret.'">'.$title.'</a>';
}

/* INI FUNCTIONS                                                  byld
   -------------------------------------------------------------------

   read album or image .ini files.

   -------------------------------------------------------- */ ?><?php

/**
 * get the filename of the .ini which goes with an image.
 */
function get_ini_filename ($image)
{
  global $suffix_regexp;

  return preg_replace ('/'.$suffix_regexp.'/i', '', $image).'.ini';
}

/**
 * read the .ini file for an album.
 */
function read_album_ini ($album = "")
{
  global $path;

  $album_ini = merge_path ($path, $album, "album.ini");

  $ret = array ();
  $ret["album"] = array ();
  if (is_file ($album_ini)
      and is_readable ($album_ini))
    $ret = parse_ini_file ($album_ini, true);

  if (array_key_exists ("description", $ret["album"]))
    $ret["album"]["description"] =
      ini_decode ($ret["album"]["description"]);

  if (array_key_exists ("title", $ret["album"]))
    $ret["album"]["title"] = ini_decode ($ret["album"]["title"]);

  return $ret;
}

/**
 * write the .ini file for an album.
 */
function write_album_ini ($ini, $album = "")
{
  global $path;

  if (array_key_exists ("description", $ini["album"]))
    $ini["album"]["description"] =
      ini_encode ($ini["album"]["description"]);

  if (array_key_exists ("title", $ini["album"]))
    $ini["album"]["title"] = ini_encode ($ini["album"]["title"]);

  $album_ini = merge_path ($path, $album, "album.ini");

  if (!file_exists ($album_ini)
      or (is_file ($album_ini) and is_writable ($album_ini)))
    write_ini_file ($album_ini, $ini);
  else
    fatal ("cannot write ".$path.$album_ini.".");
}

/**
 * read the .ini file for an image.
 */
function read_image_ini ($image = '')
{
  global $path;

  if (empty ($image))
    $image = $path;

  $image_ini = get_ini_filename ($image);

  $ret = array ();
  if (is_file ($image_ini)
      and is_readable ($image_ini))
    $ret = parse_ini_file ($image_ini, true);

  if (!array_key_exists ("image", $ret))
    $ret["image"] = array ();

  if (array_key_exists ("description", $ret["image"]))
    $ret["image"]["description"] =
      ini_decode ($ret["image"]["description"]);

  if (array_key_exists ("comments", $ret))
    foreach ($ret["comments"] as $key => $val)
      if (substr ($key, 0, 4) != "date")
        $ret["comments"][$key] = ini_decode ($val);

  return $ret;
}

/**
 * write the .ini file for an image.
 */
function write_image_ini ($ini, $image = '')
{
  global $path;

  $blurb = '
; Please note that thumbnails will not be automatically regenerated if
; you change the rotate option manually.  Changing this option in the
; online interface is recommended.
';

  if (empty ($image))
    $image = $path;

  $image_ini = get_ini_filename ($image);

  if (array_key_exists ("description", $ini["image"]))
    $ini["image"]["description"]=ini_encode ($ini["image"]["description"]);

  if (array_key_exists ("comments", $ini))
    foreach ($ini["comments"] as $key => $val)
      if (substr ($key, 0, 4) != "date")
        $ini["comments"][$key] = ini_encode ($val);

  if (!file_exists ($image_ini)
      or (is_file ($image_ini) and is_writable ($image_ini)))
    write_ini_file ($image_ini, $ini, $blurb);
  else
    warning ("could not write $image_ini");
}


/* DOCUMENTATION                                                  byld
   -------------------------------------------------------------------
   
   Functions dealing with documentation.

   -------------------------------------------------------- */ ?><?php

/**
 * display about/readme page
 */
function render_about ()
{
  global $home;

  return '
<div class="generic">
  <h2>About</h2>
  <p>
    byld is a photo album written in php.
  </p>
  <p>
    For more information visit
    <a href="http://www.byld.org">www.byld.org</a>. You will also
    find the latest version
    <a href="http://www.byld.org/download.html">there</a>.
  </p>
  <p>You can download a <a href="'.make_link ("download", $home)
    .'">.zip file</a> of this particular version right
    <a href="'.make_link ("download", $home).'">here</a>.
    Or have a look
    at its <a href="'.make_link ("ChangeLog").'">ChangeLog</a>
    or <a href="'.make_link ("todo").'">todo</a> list.
  </p>
  <h2>License</h2>
  <p>
    byld is copyright 2004 by Kuno Woudt
     &lt;<a href="mailto:kuno@byld.org">kuno@byld.org</a>&gt;,
  </p>
  <p>
    This program is free software; you can redistribute it and/or
    modify it under the terms of the <a href="'
    .make_link ("license").'">Affero General Public License</a> as
    published by Affero, Inc.; either version 1 of the License, or
    (at your option) any later version.
  </p>
  <p>
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty
    of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    Affero General Public License for more details.
  </p>
  <p>
    You should have received a copy of the Affero General Public
    License along with this program; if not, write to Affero, Inc.,
    510 Third Street, Suite 225, San Francisco, CA 94107 USA.
  </p>
</div>
';

}

/**
 * display ChangeLog
 */
function render_changelog ()
{
  return '<div class="changelog">

<h2>ChangeLog</h2>

<pre>
2004-12-19 kuno@byld.org
0.5.60     - cleaned up the about page, moving most of that to
             www.byld.org

0.5.59     - oops, only the superuser was allowed to make comments.
           - small change to &lt;title&gt;

0.5.58     - was not happy with the split, merged most stuff back.
             look in the TODO for this version for more info.
           - did some cleaning of the code:
             - removed GD support, I doubt it would ever be used.
             - removed useless navbar settings from setup.
           - added link options for album title and copyright holder.

2004-12-18 kuno@byld.org
0.5.57     - split the code up into several source files.
           - changed action_download () to pack all source files.

0.5.56     - added an option to hide albums.
           - very subtle tweaks to the copyright notice :)
           - copyright notice did not work properly in php < 4.3.0
           - added utf8 content-type header.

2004-12-17 kuno@byld.org
0.5.55     - Small updates to the about text.
           - two bug fixes to the EXIF code.

2004-12-14 kuno@byld.org
0.5.54     - Fixed some bugs in the exif reader.

2004-12-13 kuno@byld.org
0.5.53     - You can now enter your license terms on the setup page,
             for convenience, creative commons licenses can be selected
             through the setup interface.

2004-12-12 kuno@byld.org
0.5.52     - added an option to disable commenting entirely.
           - and an option to disable rss
           - only provide &lt;link&gt; to rss feeds when the .xml files exist
           - use just image filename as title in user comment feed
           - added rss to the list of features on the about page

2004-12-08 kuno@byld.org
0.5.51     - fixed a small bug in the rss feeds.

2004-12-07 kuno@byld.org
0.5.50     - added rss feed for images and albums, an image or album is
             syndicated the first time a description for it is entered
             by the administrator.

2004-12-06 kuno@byld.org
0.5.49     - changed some of the setup defaults.

2004-12-05 kuno@byld.org
0.5.48     - added rss feed for submitted comments.
0.5.47     - changed the style of grid.css to be similar to photo.css
           - fixed a bug in morbuz.css which caused IE to make some mistakes.
0.5.46     - sorting images by date did not use the EXIF date, fixed.
           - mod_rewrite bug fixed, see check_path () for more information.
0.5.45     - exif_find_ifd_data () did not strip trailing NUL bytes.
           - delete_album_files () was not using the suffix regex.
           - better error checking for non-writable directories
             on first install.
           - changing directory logged out the user, fixed.

2004-12-03 kuno@byld.org
0.5.44     - some directory info is cached, this greatly speeds up
             rendering of directories which contain lots of albums.
           - some bugs in the stylesheets fixed.
0.5.43     - fixed a bug in the EXIF parser.
0.5.42     - some small changes to the setup proceduce for new installations.

2004-12-01 kuno@byld.org
0.5.41     - name changed from hello! photo to byld.

</pre>

<h3>Hello! Photo ChangeLog</h2>
<pre>

2004-11-20 kuno@frob.nl
0.5.40     - added photo.css, a style somewhat similar to the old photo.php
             layout.  no javascript required.
           - removed hello.css, its rendering was too buggy in IE, and
             photo.css will act as a replacement.
           - fixed a bug where only album or image descriptions were
             changed on edit (not both).
0.5.39     - added a builtin EXIF parser, it only reads a tiny subset
             of exif, but enough for our needs.

2004-11-13 kuno@frob.nl
0.5.38     - forgot to update some code for adding comments, fixed.
           - .jpeg should work now.

2004-11-12 kuno@frob.nl
0.5.37     - prev/next links adhere to sort order now.
0.5.36     - surpressed a silly warning when adding comments on php 4.1.x
0.5.35     - cleaned up errors/warnings a bit, new warning display.
           - replaced die()s with fatal(), fatal uses new warning display.
           - reimplemented mod_rewrite support.
           - various small bugfixes and code cleanup.

2004-11-05 kuno@frob.nl
0.5.34     - many small bugfixes to mod_rewrite code.
0.5.32     - albums can have titles now.
           - small cosmetic change to stats first vs
             stats last code.
0.5.31     - mod_rewrite support, somewhat experimental.
0.5.30     - Added an Installation section to the manual.
           - Cleaned up the url_* and link_* functions in
             anticipation of mod_rewrite support.
0.5.29     - implemented sort by date, and ascending/descending
             for any sort option.

2004-11-04 kuno@frob.nl
0.5.28     - the cover page feature is back, and implemented
             properly.
           - you can now choose the order of album/image lists.
           - you can now choose the order of stats/description.
0.5.27     - Fixed a bug related to using references on 4.1.x
           - Added a method by which stylesheets can force
             configuration options, this will help keep the
             setup page clean of useless details.
           - Added morbuz.css, a grid layout stylesheet
             requested by Erlend Hamberg.
0.5.26     - Fixed the grid layout style to set both width
             and height of &lt;div&gt;s.
0.5.25     - Recieved reports of hit counts dissapearing,
             removed the code to unlink empty .ini files,
             hopefully that solves the problem.
0.5.24     - Aaargh, really fixed now, honest! (I assumed
             apache would not let the world see 0700, files).
             The problem was fixed by saving to a .php file,
             with some command at the top to halt processing.
0.5.23     - Chmod the .ini file after writing, which was a
             rather big security hole in the previous
             versions :)
0.5.22     - Grid layout, includes some changes to the setup.

2004-11-03 kuno@frob.nl
0.5.21     - Stylesheets can now be selected through the setup
             menu.  If a foo.js exists for foo.css, that will
             be loaded too.
           - A very early prototype of a grid layout stylesheet
             is included in this version, please do not use it :)
           - Modified action_download () to include all
             stylesheets available in the menu.

2004-11-02 kuno@frob.nl
0.5.20     - Some cosmetic fixes to the image view page,
             including the option to have the navbar at the
             top, bottom or both.
           - Woops, introduced a new bug when saving .ini files
             in the previous version, fixed now.
0.5.19     - Removed the splash screen code, it was not how I
             intended covers to work, it will be reimplemented
             properly at some point.
           - Implemented workaround for php without exif.
           - Fixed a bug where new installs could not save their
             settings to hello.ini.
           - Store IP address of ppl changing adding comments
             (or changing the setup).

2004-11-01 kuno@frob.nl
0.5.18     First version with cover page support, requires
           more testing.
0.5.17     Added some security checks involving imagemagick.
           Fixed a bug where rotated thumbnails were not
           updated.  Setup page finished, and fixed cancel
           buttons everywhere.  Cleaned up hello.css.

2004-10-31 kuno@frob.nl
0.5.16     Some security fixes involving $path, /etc and ../etc :),
           also the setup page is partly finished.
0.5.15     Imagemagick support.
0.5.14     Hit counter.
0.5.12     Added download option.
0.5.11     Added license, about, and ChangeLog pages.
0.5.10     can view images and add comments.
0.5.9      can edit descriptions of albums and select cover
           images. some minor updates to the stylesheet.

2004-10-30 kuno@frob.nl
0.5.8      rotating images works, and fixed a small bug with
           image descriptions.
0.5.7      Changing image descriptions works now.
0.5.6      Restructered the sourcecode, grouped functions
           into sections.
0.5.5      First changelog entry, changes during prototype
           stage were not recorded. The current version
           still has many unfinished parts, but is steadily
           approaching completion.

           0.5.x is a full rewrite.
</pre>

<h3>photo.php ChangeLog</h2>
<pre>

2004-07-27 kuno@frob.nl
0.4.0      Collected all the hacks made to 0.3.8 in a single
           version

2002-06-29 kuno@frob.nl
0.3.8      Supports photo.ini for configuration, some fixes
           to the manual.

2002-06-28 kuno@frob.nl
0.3.4      Apache mod_rewrite support.

2002-03-27 kuno@frob.nl
0.3.2      Changed the license to Affero General Public
           License.

2002-02-09 kuno@frob.nl
0.2.4      First version which comes with a manual.

2002-02-09 kuno@frob.nl
0.2.0      Added a dutch translation for dutch, and a
           partial frisian translation.

2002-02-09 kuno@frob.nl
0.1.8      First published version.

</pre>
</div>
';
}

/* MAIN HELPER FUNCTIONS (and main is in there too)               byld
   -------------------------------------------------------------------
   
   some global functions which do not  fit in any other category and a
   few helper functions called directly from main ().

   -------------------------------------------------------- */ ?><?php

/**
 * delete .htaccess file
 */
function delete_htaccess ()
{
  global $htxs_filename;

  if (!is_file ($htxs_filename))
    return;

  if (!unlink ($htxs_filename))
    warning ("cannot delete $file");
}

/**
 * dump .htaccess file for mod_rewrite.
 */
function dump_htaccess ()
{
  global $settings, $home, $htxs_filename;

  update_home ();

  $self = merge_path ($home, basename ($_SERVER["PHP_SELF"]));
  $dir = dirname ($self);

  $htxs = '
RewriteEngine on
RewriteBase   '.$dir.'

RewriteCond	%{REQUEST_URI}    !^/cgi-bin
RewriteCond     %{REQUEST_URI}    !^'.$self.'
RewriteCond     %{REQUEST_URI}    ^'.$dir.'
RewriteRule     ^(.*)\.html$      '.$self.'?path=$1.html&%{QUERY_STRING} [L]
RewriteRule     ^$                '.$self.'?%{QUERY_STRING}              [L]

RewriteCond	%{REQUEST_URI}	  !^/cgi-bin
RewriteCond     %{REQUEST_URI}    !^'.$self.'
RewriteCond     %{REQUEST_URI}    ^'.$dir.'
RewriteCond     %{REQUEST_FILENAME}     -d
RewriteRule     ^(.*)$            '.$self.'?path=$1&%{QUERY_STRING}      [L]

';

  if(!$handle = @fopen($htxs_filename, 'w'))
    {
      warning ("cannot create $file, or open it for writing");
      return false;
    }

  if(!fwrite($handle, $htxs))
    return false;

  fclose($handle);
  return true;
}

/**
 * hit count
 */
function hit ()
{
  global $path, $settings;

  if (!$settings["features"]["hitcount"])
    return false;

  if (substr ($path, -1, 1) == '/')
    {
      $ini = read_album_ini ();
      if (!array_key_exists ("hitcount", $ini["album"]))
        $ini["album"]["hitcount"] = 0;
      $ini["album"]["hitcount"]++;
      write_album_ini ($ini);
    }
  else
    {
      $ini = read_image_ini ();
      if (!array_key_exists ("hitcount", $ini["image"]))
        $ini["image"]["hitcount"] = 0;
      $ini["image"]["hitcount"]++;
      write_image_ini ($ini);
    }

  return $ini;
}

/**
 * read css file, and parse byld init section :)
 */
function read_css ()
{
  global $settings;

  $css_file = $settings["style"]["stylesheet"];

  $lines = file ($css_file);

  $init = false;
  foreach ($lines as $line)
    {
      if ($init)
        {
          if (preg_match ('/BYLD END SECTION/', $line))
            break;

          if (preg_match ('/^(\w+)\[(\w+)\] *= *(.*)$/', $line, $matches))
            $settings[$matches[1]][$matches[2]] =
              remove_quotes ($matches[3]);
        }
      else if (preg_match ('/BYLD INIT SECTION/', $line))
        $init = true;
    }


}

/**
 * read ini file
 */
function read_ini ()
{
  global $settings, $ini_filename;

  set_defaults ();

  if (!is_file ($ini_filename) or !is_readable ($ini_filename))
    return;

  $ini = parse_ini_file ($ini_filename, true);
  $both = array_merge_recursive2 ($settings, $ini);

  $settings = $both;

  if (@empty ($settings["thumb"]["album"]))
    $settings["thumb"]["album"] = $settings["thumb"]["image"];
}

/**
 * write ini file
 */
function write_ini ()
{
  global $settings, $ini_filename;

  $title = $settings["main"]["title"];

  $blurb = '; <?php die ("move along..."); ?> '
    ."\n\n; ".$ini_filename." generated for ".$title."\n; by "
    .basename (__FILE__)."\n;\n"
    ."; feel free to make changes to this file, but comments (like these)\n"
    ."; will be lost when you change a setting within byld.php .\n\n";

  if ((is_writable ($ini_filename) or !file_exists ($ini_filename))
      and write_ini_file ($ini_filename, $settings, $blurb))
    return true;

  warning ("cannot save settings");
  return false;
}

/**
 * check for .htaccess, if it doesn't exist assume the use deleted it
 * and disable mod_rewrite just in case.
 */
function check_rewrite ()
{
  global $settings, $htxs_filename;

  if (is_file ($htxs_filename))
    return;

  $settings["rewrite"]["enable"] = false;
}

/**
 * check path for abuse (think /etc :)
 */
function check_path ()
{
  global $path;

  $realhome = dirname (__FILE__);

  $real = realpath ($path);

  if (strlen ($real) < strlen ($realhome)
      /* NOTE: the following condition is a work around for an
         unfortunate side effect of the current mod_rewrite situation
         (possibly a bug in the .htaccess file):

         if the photo album root is accessed as http://example.com/foo/
         the query_string is empty, and everything works as expected.

         if the photo album root is accessed as http://example.com/foo
         the query_string contains a path variable with the full path,
         i.e. /var/www/htdocs/foo or whereever you keep your files. */
      or $real.'/' == $path)
    {
      $path = "./";
      return;
    }

  if (strcmp (substr ($real, 0, strlen ($realhome)), $realhome))
    {
      $path = "./";
      return;
    }

  // I guess $path is ok...
}

/**
 * get companion javascript filename for a stylesheet.
 */
function get_companion_js_file ($css_file)
{
  $js_file = substr ($css_file, 0, -3).'js';

  return is_readable ($js_file) ? $js_file : '';
}

/**
 * list available stylesheets.
 */
function list_stylesheets ()
{
  $dir = read_dir (".");

  $ret = array ();

  if (!count ($dir["stylesheets"]))
    return $ret;

  foreach ($dir["stylesheets"] as $val)
    $ret[basename ($val)] = basename ($val);

  return $ret;
}

/**
 * list source files.
 */
function list_source ()
{
  $dir = read_dir (".");

  $ret = array ();

  if (!count ($dir["source"]))
    return $ret;

  foreach ($dir["source"] as $val)
    $ret[basename ($val)] = basename ($val);

  return $ret;
}

/**
 * decode a sectionorder string.
 */
function decode_sectionorder ()
{
  global $settings;

  return split (", ", $settings["style"]["order"]);
}

/**
 * list section ordering options.
 */
function list_sectionorder ()
{
  return array ("cover, album, thumb",
                "thumb, album, cover",
                "cover, thumb, album",
                "album, cover, thumb");
}

/**
 * decode a path as it is given to us by mod_rewrite.
 */
function decode_rewrite ($rewrite)
{
  global $settings;

  if (!$settings["rewrite"]["enable"])
    return array ("", $rewrite);

  if (preg_match ('#^((.*)/)?(.*).html#', $rewrite, $matches))
    {
      if (@is_file ($matches[1].$matches[3]))
        return array ("", $matches[1].$matches[3]);

      return array ($matches[3], $matches[2]);
    }

  return array ("", $rewrite);
}

/**
 * set default values.
 */
function set_defaults ()
{
  global $settings;

  $settings = array ();
  $settings["main"] = array ();
  $settings["thumb"] = array ();
  $settings["navbar"] = array ();
  $settings["style"] = array ();
  $settings["edit"] = array ();
  $settings["misc"] = array ();

  $settings["copyright"]["use"] = false;
  $settings["copyright"]["year"] = date ("Y");
  $settings["copyright"]["holder"] = "";
  $settings["copyright"]["link"] = "";
  $settings["copyright"]["license_name"] = "none";
  $settings["copyright"]["license_url"] = "";
  $settings["copyright"]["terms"] = "";
  $settings["copyright"]["metadata"] = "";

  $settings["main"]["title"] = "byld";
  $settings["main"]["link"] = "";
  $settings["main"]["root"] = "root";
  $settings["main"]["seperator"] = " / ";
  $settings["main"]["password"] = "EMPTY";

  $settings["thumb"]["image"] = "x150";
  $settings["thumb"]["album"] = "x150";
  $settings["thumb"]["cover"] = "550";
  $settings["thumb"]["view"] = "600";

  $settings["sort"]["album_type"] = "date";
  $settings["sort"]["thumb_type"] = "date";
  $settings["sort"]["album_reverse"] = true;
  $settings["sort"]["thumb_reverse"] = false;

  $settings["style"]["view_width"] = 2;
  $settings["style"]["thumb_width"] = '';
  $settings["style"]["album_width"] = '';
  $settings["style"]["cover_width"] = '';
  $settings["style"]["stylesheet"] = "photo.css";
  $settings["style"]["cover"] = true;
  $tmp = list_sectionorder ();
  $settings["style"]["order"] = $tmp[0];
  $settings["style"]["info_order"] = false;

  $settings["edit"]["cols"] = 0;
  $settings["edit"]["rows"] = 8;

  $settings["navbar"]["prev"] = " &lt;&lt; ";
  $settings["navbar"]["next"] = " &gt;&gt; ";

  $settings["rewrite"]["home"] = dirname ($_SERVER["PHP_SELF"]);
  $settings["rewrite"]["enable"] = false;
  $settings["rewrite"]["dump_htaccess"] = false;

  $settings["features"]["use_rss"] = true;
  $settings["features"]["hitcount"] = true;
  $settings["features"]["comments"] = true;

  $settings["misc"]["inline_css"] = false;

  if (is_file ('/usr/local/bin/convert'))
    $settings["misc"]["convert"] = '/usr/local/bin/convert';
  else
    $settings["misc"]["convert"] = '/usr/bin/convert';
}

/**
 * fetch current home setting and append a trailing slash if needed.
 */
function update_home ()
{
  global $home, $settings;

  $home = $settings["rewrite"]["home"];
  if (substr ($home, -1) != '/')
    $home .= '/';
}

/**
 * main
 */
function main ()
{
  global $home, $path, $settings, $logged_in, $editable, $edit, $todo;

  /*  =====  read configuration  =====  */
  read_ini ();
  read_css ();

  check_rewrite ();
  update_home ();

  $path = @$_REQUEST["path"];
  list ($action, $path) = decode_rewrite ($path);
  if ((substr ($path, -1, 1) != '/') and is_dir ($path))
    $path .= '/';

  if (empty ($path))
    $path = '/';

  check_path ();

  $a = empty ($action) ? @$_REQUEST["a"] : $action;
  $edit = false;

  /* the following actions should work wherever we are in the
     setup process, so they go before attempts to authenticate. */

  /*  =====  generic actions  =====  */
  if ($a == "about")
    {
      action_about ();
      exit ('');
    }
  else if ($a == "license")
    {
      display_generic ("license", "license", render_license ());
      exit ('');
    }
  else if ($a == "ChangeLog")
    {
      display_generic ("changelog", "ChangeLog", render_changelog ());
      exit ('');
    }
  else if ($a == "todo")
    {
      display_generic ("setup", "setup", '<div class="changelog"><pre>'
                       .$todo."</pre></div>\n");
      exit ('');
    }
  else if ($a == "download")
    {
      action_download ();
      exit ('');
    }
  /*
  else if ($a == "info")
    {
      phpinfo (); exit ('');
    }
  */


  /*  =====  authenticate user  =====  */
  if (!check_login ($a))
    $a = "login";

  if ($a == "logout")
    {
      setcookie ("passwd", "WRONG", 0, "/");
    }

  if (check_first_install ($a))
    $a = $logged_in ? "welcome" : "login";

  /*  =====  record submissions ==== */
  if ($logged_in)
    {
      if ($a == "submit_albumview") action_submit_albumview ();
      if ($a == "submit_setup")     action_submit_setup ();
      if ($a == "return_from_cc")   action_return_from_cc ();
    }

  if ($a == "submit_comment")   action_submit_comment ();

  /*  =====  enable edit ==== */
  if ($a == "edit" and $logged_in) $edit = true;

  /*  =====  real actions :)  =====  */
  if ($a == "welcome")
    {
      display_generic ("welcome", "welcome", '<div class="generic">'
                       .'Welcome to byld, please proceed to the '
                       .make_link ("setup", $home.$path, "setup")
                       .' page.</div>');
    }
  else if ($a == "setup" and $logged_in)
    {
      display_generic ("setup", "setup", render_setup ());
    }
  else if ($a == "login")
    {
      action_login ();
    }
  else
    {
      $editable = true;

      if (is_dir ($path))
        {
          action_album ();
        }
      else if (is_file ($path))
        {
          action_image ();
        }
      else
        {
          fatal ("cannot read $path");
        }
    }
}


set_error_handler ("user_error_handler");
set_defaults ();

main ();
