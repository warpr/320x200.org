function layer (name)
{
  if (document.getElementById)
    return document.getElementById(name).style;
  else if (document.all)
    return document.all[name].style;
}

function show (name)
{
  layer (name).display = "inline";
}

function setgrid (str)
{
  var divs = document.getElementsByTagName("div");

  var max_height = 0;
  var max_width = 0;

  var h = 0;
  var w = 0;
  for (var i=0; i<divs.length; i++)
    {
      if (divs[i].className == str)
        {
          if (divs[i].offsetHeight) var h = divs[i].offsetHeight;
          if (divs[i].offsetWidth)  var w = divs[i].offsetWidth;
          if (h > max_height) max_height = h;
          if (w > max_width)  max_width = w;
        }
    }

  for (var i=0; i<divs.length; i++)
    {
      if (divs[i].className == str)
        {
          if (max_height != 0) divs[i].style.height = max_height+'px';
          if (max_width != 0) divs[i].style.width = max_width+'px';
        }
    }
}


function cleardiv (str)
{
  var divs = document.getElementsByTagName("div");

  for (var i=0; i<divs.length; i++)
    {
      if (divs[i].className == str)
        divs[i].style.display = 'none';
    }
}



function morbuz ()
{
//  setgrid ('albumitem');
  setgrid ('thumbitem');
  cleardiv ('create');
}
