/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#include <iostream>
#include <memory>
#include <sys/time.h>
#include <math.h>

#include "Timing.h"
#include "libGGI.h"
#include "MikMod.h"
#include "version.h"

typedef unsigned short word;
typedef unsigned char  byte;

/***********************************************************************\
 the original source starts here,... with only minimal changes (i hope).
 only  int main(void)  has lots of init stuff changed,..
\***********************************************************************/

#define noDump     if(gfx.usert) gfx.Wait();                          \
                   else tijd.Wait();                                  

#define Dump(x)    if(gfx.usert) gfx.Wait();                          \
                   else tijd.Wait();                                  \
                   memmove(vid,x,0xFA00);

#define DumpR(x,y) if(gfx.usert) gfx.Wait();                          \
                   else tijd.Wait();                                  \
                   for(Dumpi=0;Dumpi<0xFA00;Dumpi++)                  \
                     y[0xFA00-1-Dumpi]=x[Dumpi];                      \
                   memmove(vid,y,0xFA00);

#define updateloop    frames++;                                       \
                      mod.update();                                   \
                      if(!gfx.usedb) gfx.putbox(vid);                 \
                      gfx.flush();                                    


long frames=0;

#define FALSE 0
#define TRUE  !FALSE

#define Pix(X,Y,C)        VidBuf[((int)X)+((int)Y)*320]=16-C
#define CloneObj(DST,SRC) memcpy(DST,SRC,sizeof(_Object))

#define VTSIZE   50
#define OBJLINES 80
#define DELAY    delay(10);
#define D        32
#define H        64

#define RES_X 320
#define RES_Y 200
#define RESS_X 320
#define RESS_Y 200

#define Redh   3                       // Dit wordt gebruikt om het palette
#define Grnh   1                       // te generen uit de eerste 64 kleuren
#define Bluh   7                       // 1. dit is voor Spark's alita kop.

#define Redi   5                       // Dit wordt gebruikt om het palette
#define Grni   5                       // te generen uit de eerste 64 kleuren
#define Blui   9                       // 2. dit is voor het BG texture.

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;


typedef struct
{
  long X,Y,Z;
} _Vertex;

typedef struct
{
  long A,B;
} _Line;

typedef struct
{
  unsigned short NoVerteces;
  _Vertex *Vertex;

  unsigned short NoLines;
  _Line Line[OBJLINES];

/*  long  X,Y,Z;                / / position
  float aX,aY,aZ;             / / orientation */
} _Object;

typedef struct
{
  long dx, dy, dz;
  float ax, ay, az;
} _Frame;

/* Global Shit */
long g=15;
byte VidBuf[0xFA00];

word Dumpi;

bool toggle=false;

byte Radius[64000];
byte Angle2[64000];
byte AddS320[320];
byte AddE320[200];
byte AddS256[256];
byte AddE256[256];
byte Gaten[0x10000];
byte MirTex[0x10000];
byte Bufter[0xFA00];
byte Bufter2[0xFA00];
byte WaazNRLE[0xFA00];
byte Ooze1[0x10000];
byte Front[0x10000];
byte Back[0x10000];
byte Ooze1Pal[768];
byte Frontback[768];
byte v3pal[768];
byte Sun[0x10000];
byte SunPal[768];
byte verspiegeld[0x10000];
byte Textuur[65535];
byte Waaz[65535];
byte Circle[33*32];
byte Paula[768];
byte Alita[256*150];
byte V1[0xFA00];
byte V2[0xFA00];
byte V3[0xFA00];

byte Angle =0, AngInc=0;
byte Offset=0, OfsInc=0;

_Object TRObj, SObj, Flat;
_Vertex VT1[VTSIZE],VT2[VTSIZE];
_Frame* frame;
short c, noframes;

int random2(int x);
void kroket(byte *Target, byte *Source);
void MirrorEgg(byte *Tex);
void exithandler(void);
void Inittexture(byte *Target, byte *Source);
void Gatenkaas(byte *Target, byte *Source);
void NRLEadd(byte *Target, byte *Source, byte* NRLE);
void HalfPalette(byte *Paula);
void Palette(byte *Paula);
void InitPalette(byte *Paula);
void DoWobbel(byte *Target, byte *Source, byte AddXtex, byte AddYtex, word Resx, word Resy);
void GenuinePaprikaChips(word IncX, word IncY, byte *Bufter, byte *verspiegeld);
void spihCakirpaPeniuneG(word IncX, word IncY, byte *Bufter, byte *Texture);
void Sines(byte Amp, word Freq, byte *Tabel, word Res);
void ShowPic(byte *Buffer, byte *Pic, word xs, word ys);
void InitPolar(void);
void Polar(byte Ang, byte Ofs, byte *Bufter, byte *verspiegeld);
short LoadBin(char *File, void *Buffer);
long FileLength(FILE *fs);
void God_init(_Object *Obj, _Frame *Frame, short NoFrames);
void God();
void TRot(_Object *DST,_Object SRC,
         long dX,long dY,long dZ,
         float aX,float aY,float aZ);
void Perspective(_Object *DST, _Object SRC);
void Display(_Object Obj);
void Line(int X1,int Y1,int X2,int Y2);
void PutPixel(int x,int y,char c);

// The Fat Of The Land


libGGI gfx(320, 200);

MikMod mod("data/nothing.xm");
Timing tijd(70);

unsigned char*   vid;  

int
main(void)
{
  std::cout << "\n" << ver << ".\n\n";

    _Vertex Vtex[]=
  {

    { -20,  60, 2},  // 0
    { -10,  50, 2},
    { -10,  10, 2},
    { -50,  10, 2},
    { -60,  20, 2},
    { -70,-100, 2},
    { -50, -10, 2},
    { -10, -10, 2},
    { -10, -50, 2},
    { -20, -60, 2},
    {   0,-170, 2},  // 9: den o zo scherpen punt.
    {  20, -60, 2},
    {  10, -50, 2},
    {  10, -10, 2},
    {  50, -10, 2},  // 12
    {  70,-100, 2},
    {  60,  20, 2},
    {  50,  10, 2},
    {  10,  10, 2},
    {  10,  50, 2},
    {  20,  60, 2},  // 19


    { -20,  60, 22},  // 0
    { -10,  50, 22},
    { -10,  10, 22},
    { -50,  10, 22},
    { -60,  20, 22},
    { -70,-100, 22},
    { -50, -10, 22},
    { -10, -10, 22},
    { -10, -50, 22},
    { -20, -60, 22},
    {   0,-170, 22},  // 9: den o zo scherpen punt.
    {  20, -60, 22},
    {  10, -50, 22},
    {  10, -10, 22},
    {  50, -10, 22},  // 12
    {  70,-100, 22},
    {  60,  20, 22},
    {  50,  10, 22},
    {  10,  10, 22},
    {  10,  50, 22},
    {  20,  60, 22}   // 19

  };

  _Object Obj;
  _Frame Frame[]=
  {
//     dx   dy dz   x    y    z
    { -20, -50,30, 0.1, 0.0, 3.0},      /* 1  */
    { -20, -50,30, 0.1, 0.1, 3.0},      /* 2  */
    { -20, -50,30, 0.1, 0.2, 3.0},      /* 3  */
    { -20, -50,30, 0.1, 0.3, 3.0},      /* 4  */
    { -20, -50,30, 0.1, 0.4, 3.0},      /* 5  */
    { -20, -50,30, 0.1, 0.5, 3.0},      /* 6  */
    { -20, -50,30, 0.1, 0.6, 3.0},      /* 7  */
    { -20, -50,30, 0.1, 0.7, 3.0},      /* 8  */
    { -20, -50,30, 0.1, 0.8, 3.0},      /* 9  */
    { -20, -50,30, 0.1, 0.9, 3.0},      /* 10 */
    { -20, -50,30, 0.1, 1.0, 3.0},      /* 11 */
    { -20, -50,30, 0.1, 1.1, 3.0},      /* 12 */
    { -20, -50,30, 0.1, 1.2, 3.0},      /* 13 */
    { -20, -50,30, 0.1, 1.3, 3.0},      /* 14 */
    { -20, -50,30, 0.1, 1.4, 3.0},      /* 15 */
    { -20, -50,30, 0.1, 1.5, 3.0},      /* 16 */

    { -20, -50,30, 0.1, 1.6, 3.0},      /* 17 */
    { -20, -50,30, 0.1, 1.7, 3.0},      /* 18 */
    { -20, -50,30, 0.1, 1.8, 3.0},      /* 19 */
    { -20, -50,30, 0.1, 1.9, 3.0},      /* 20 */
    { -20, -50,30, 0.1, 2.0, 3.0},      /* 21 */
    { -20, -50,30, 0.1, 2.1, 3.0},      /* 22 */
    { -20, -50,30, 0.1, 2.2, 3.0},      /* 23 */
    { -20, -50,30, 0.1, 2.3, 3.0},      /* 24 */
    { -20, -50,30, 0.1, 2.4, 3.0},      /* 25 */
    { -20, -50,30, 0.1, 2.5, 3.0},      /* 26 */
    { -20, -50,30, 0.1, 2.6, 3.0},      /* 27 */
    { -20, -50,30, 0.1, 2.7, 3.0},      /* 28 */
    { -20, -50,30, 0.1, 2.8, 3.0},      /* 29 */
    { -20, -50,30, 0.1, 2.9, 3.0},      /* 30 */
    { -20, -50,30, 0.1, 3.0, 3.0},      /* 31 */
    { -20, -50,30, 0.1, 3.1, 3.0},      /* 32 */

    { -20, -50,30, 0.1, 3.2, 3.0},      /* 33 */
    { -20, -50,30, 0.1, 3.3, 3.0},      /* 34 */
    { -20, -50,30, 0.1, 3.4, 3.0},      /* 35 */
    { -20, -50,30, 0.1, 3.5, 3.0},      /* 36 */
    { -20, -50,30, 0.1, 3.6, 3.0},      /* 37 */
    { -20, -50,30, 0.1, 3.7, 3.0},      /* 38 */
    { -20, -50,30, 0.1, 3.8, 3.0},      /* 39 */
    { -20, -50,30, 0.1, 3.9, 3.0},      /* 40 */

    { -20, -50,30, 0.1, 4.0, 3.0},      /* 41 */
    { -20, -50,30, 0.1, 4.1, 3.0},      /* 42 */
    { -20, -50,30, 0.1, 4.2, 3.0},      /* 43 */
    { -20, -50,30, 0.1, 4.3, 3.0},      /* 44 */
    { -20, -50,30, 0.1, 4.4, 3.0},      /* 45 */
    { -20, -50,30, 0.1, 4.5, 3.0},      /* 46 */
    { -20, -50,30, 0.1, 4.6, 3.0},      /* 47 */
    { -20, -50,30, 0.1, 4.7, 3.0},      /* 48 */
    { -20, -50,30, 0.1, 4.8, 3.0},      /* 49 */
    { -20, -50,30, 0.1, 4.9, 3.0},      /* 30 */
    { -20, -50,30, 0.1, 5.0, 3.0},      /* 51 */
    { -20, -50,30, 0.1, 5.1, 3.0},      /* 52 */
    { -20, -50,30, 0.1, 5.2, 3.0},      /* 53 */

    { -20, -50,30, 0.1, 5.3, 3.0},      /* 54 */
    { -20, -50,30, 0.1, 5.4, 3.0},      /* 55 */
    { -20, -50,30, 0.1, 5.5, 3.0},      /* 56 */
    { -20, -50,30, 0.1, 5.6, 3.0},      /* 57 */
    { -20, -50,30, 0.1, 5.7, 3.0},      /* 58 */
    { -20, -50,30, 0.1, 5.8, 3.0},      /* 59 */
    { -20, -50,30, 0.1, 5.9, 3.0},      /* 60 */
    { -20, -50,30, 0.1, 6.0, 3.0}       /* 61 */
  };

  byte Count=0;
  word i;
  word IncX=0x0000;
  word IncY=0x0000;

  //  byte Key=0xFF, Quit=FALSE;
  float Degree=0.0;

  //  float C;
  //  union REGS r;

  //  printf("%d\n", random2(100));
  //  getch();

  Obj.NoVerteces=42;
  Obj.Vertex=Vtex;
  Obj.NoLines=63;
  Obj.Line[0].A=0;
  Obj.Line[0].B=1;
  Obj.Line[1].A=1;
  Obj.Line[1].B=2;
  Obj.Line[2].A=2;
  Obj.Line[2].B=3;
  Obj.Line[3].A=3;
  Obj.Line[3].B=4;
  Obj.Line[4].A=4;
  Obj.Line[4].B=5;
  Obj.Line[5].A=5;
  Obj.Line[5].B=6;
  Obj.Line[6].A=6;
  Obj.Line[6].B=7;
  Obj.Line[7].A=7;
  Obj.Line[7].B=8;
  Obj.Line[8].A=8;
  Obj.Line[8].B=9;
  Obj.Line[9].A=9;
  Obj.Line[9].B=10;
  Obj.Line[10].A=10;
  Obj.Line[10].B=11;
  Obj.Line[11].A=11;
  Obj.Line[11].B=12;
  Obj.Line[12].A=12;
  Obj.Line[12].B=13;
  Obj.Line[13].A=13;
  Obj.Line[13].B=14;
  Obj.Line[14].A=14;
  Obj.Line[14].B=15;
  Obj.Line[15].A=15;
  Obj.Line[15].B=16;
  Obj.Line[16].A=16;
  Obj.Line[16].B=17;
  Obj.Line[17].A=17;
  Obj.Line[17].B=18;
  Obj.Line[18].A=18;
  Obj.Line[18].B=19;
  Obj.Line[19].A=19;
  Obj.Line[19].B=20;
  Obj.Line[20].A=20;
  Obj.Line[20].B=0;

  Obj.Line[21].A=21;
  Obj.Line[21].B=22;
  Obj.Line[22].A=22;
  Obj.Line[22].B=23;
  Obj.Line[23].A=23;
  Obj.Line[23].B=24;
  Obj.Line[24].A=24;
  Obj.Line[24].B=25;
  Obj.Line[25].A=25;
  Obj.Line[25].B=26;
  Obj.Line[26].A=26;
  Obj.Line[26].B=27;
  Obj.Line[27].A=27;
  Obj.Line[27].B=28;
  Obj.Line[28].A=28;
  Obj.Line[28].B=29;
  Obj.Line[29].A=29;
  Obj.Line[29].B=30;
  Obj.Line[30].A=30;
  Obj.Line[30].B=31;
  Obj.Line[31].A=31;
  Obj.Line[31].B=32;
  Obj.Line[32].A=32;
  Obj.Line[32].B=33;
  Obj.Line[33].A=33;
  Obj.Line[33].B=34;
  Obj.Line[34].A=34;
  Obj.Line[34].B=35;
  Obj.Line[35].A=35;
  Obj.Line[35].B=36;
  Obj.Line[36].A=36;
  Obj.Line[36].B=37;
  Obj.Line[37].A=37;
  Obj.Line[37].B=38;
  Obj.Line[38].A=38;
  Obj.Line[38].B=39;
  Obj.Line[39].A=39;
  Obj.Line[39].B=40;
  Obj.Line[40].A=40;
  Obj.Line[40].B=41;
  Obj.Line[41].A=41;
  Obj.Line[41].B=21;

  Obj.Line[42].A=0;
  Obj.Line[42].B=21;
  Obj.Line[43].A=1;
  Obj.Line[43].B=22;
  Obj.Line[44].A=2;
  Obj.Line[44].B=23;
  Obj.Line[45].A=3;
  Obj.Line[45].B=24;
  Obj.Line[46].A=4;
  Obj.Line[46].B=25;
  Obj.Line[47].A=5;
  Obj.Line[47].B=26;
  Obj.Line[48].A=6;
  Obj.Line[48].B=27;
  Obj.Line[49].A=7;
  Obj.Line[49].B=28;
  Obj.Line[50].A=8;
  Obj.Line[50].B=29;
  Obj.Line[51].A=9;
  Obj.Line[51].B=30;
  Obj.Line[52].A=10;
  Obj.Line[52].B=31;
  Obj.Line[53].A=11;
  Obj.Line[53].B=32;
  Obj.Line[54].A=12;
  Obj.Line[54].B=33;
  Obj.Line[55].A=13;
  Obj.Line[55].B=34;
  Obj.Line[56].A=14;
  Obj.Line[56].B=35;
  Obj.Line[57].A=15;
  Obj.Line[57].B=36;
  Obj.Line[58].A=16;
  Obj.Line[58].B=37;
  Obj.Line[59].A=17;
  Obj.Line[59].B=38;
  Obj.Line[60].A=18;
  Obj.Line[60].B=39;
  Obj.Line[61].A=19;
  Obj.Line[61].B=40;
  Obj.Line[62].A=20; //20
  Obj.Line[62].B=41;



  if(!LoadBin("data/waaz.raw",Waaz))               return(1);
  if(!LoadBin("data/alita.raw",Alita))             return(2);
  if(!LoadBin("data/palette.pal",Ooze1Pal))        return(3);
  if(!LoadBin("data/v1.pal",Paula))                return(4);
  if(!LoadBin("data/text_10h.raw",verspiegeld))    return(5);
  if(!LoadBin("data/circle.raw",Circle))           return(6);
  if(!LoadBin("data/ooze_1.raw",Ooze1))            return(7);
  if(!LoadBin("data/frontbak.pal",Frontback))      return(8);
  if(!LoadBin("data/front.raw",Front))             return(9);
  if(!LoadBin("data/back.raw",Back))               return(10);
  if(!LoadBin("data/v1.raw",V1))                   return(11);
  if(!LoadBin("data/sun.raw",Sun))                 return(12);
  if(!LoadBin("data/sun.pal",SunPal))              return(13);
  if(!LoadBin("data/v2.raw",V2))                   return(11);
  if(!LoadBin("data/v3.raw",V3))                   return(11);
  if(!LoadBin("data/v3.pal",v3pal))                return(11);

  //+((sin(Count*C)+1)*30)
  Sines(90,150,AddS320,320);
  Sines(80,150,AddE320,200);
  Sines(100,64,AddS256,256);      // 100, 64; 100, 64 = water.
  Sines(100,64,AddE256,256);      // 100, 128; 1, 128; = 2 golfjes.

  InitPolar();
  std::cout << endl;
  srandom(99795);

  //  int Xstart = (gfx.x-320)>>1;
  //  int Ystart = (gfx.y-200)>>1;

  if(gfx.usedb) 
    vid = gfx.p();
  else
    vid = new(nothrow) unsigned char[gfx.x*gfx.y*(gfx.bpp/8)];

  if(vid==NULL) {
    std::cout << "Cannot allocate video buffer.\n";
    exit(23);
  }

  //  std::cout << "Xstart: " << Xstart << ", Ystart: " << Ystart << ".\n";

  InitPalette(Ooze1Pal);
  Palette(Paula);

  mod.start();

  AngInc=2;
  OfsInc=256-2;

  while(!gfx.kbhit() && mod.position()<0x04) {
    updateloop;

    spihCakirpaPeniuneG(IncX,IncY,MirTex,verspiegeld);
    MirrorEgg(MirTex);
    Polar(Angle+=AngInc,Offset+=OfsInc,Bufter,MirTex);

    IncX = (1-cos(Degree/90*M_PI))*(4*180*sin(Degree/180*M_PI));
    IncY = (1-cos(Degree/90*M_PI))*(4*180*cos(Degree/180*M_PI));

    Degree++;
    if(Degree==360.0) Degree=0.0;

    Dump(Bufter);
  }

  HalfPalette(Paula);
  kroket(Bufter,V1);
  Dump(Bufter);

  while(!gfx.kbhit() && mod.position()<0x05) {
    updateloop;
    noDump;
  }

  Palette(Paula);

  while(!gfx.kbhit() && mod.position()<0x09) {
    updateloop;

    Count+=3;
    DoWobbel(Textuur, verspiegeld, Count, Count, 256, 256);
    Polar(Angle+=AngInc,Offset+=OfsInc,Bufter,Textuur);

    // wait retrace
    
    Dump(Bufter);
  }

  HalfPalette(Paula);
  kroket(Bufter,V2);
  Dump(Bufter);

  while(!gfx.kbhit() && mod.position()<0x0A) {
    updateloop;
    noDump;
  }

  Palette(Frontback);
  memcpy(Gaten, Front, 0x10000);
  OfsInc=0;

  while(!gfx.kbhit() && mod.position()<0x0E) {
    updateloop;

    Count+=3;

    if(mod.position()>0x0A && toggle) Gatenkaas(Gaten, Circle);
    toggle = !toggle;

    Polar(Angle+=AngInc,Offset+=OfsInc,Bufter,Back);
    DoWobbel(Bufter2, Gaten, Count, Count, 320, 200);

    for(i=0;i<0xFA00;i++)
      {
	if(Bufter2[i]==0) Bufter2[i]=Bufter[i];
      }

    // wait retrace

    Dump(Bufter2);
  }

  Palette(SunPal);

  God_init(&Obj, Frame, 62);

  while(!gfx.kbhit() && mod.position()<0x10) {
    updateloop;

    God();

    Dump(VidBuf);
  }

  Palette(Ooze1Pal);

  while(!gfx.kbhit() && mod.position()<0x14) {
    updateloop;

    Count+=3;
    //    C=(2*M_PI)/256;
    //  +((sin(Count*C)+1)*30

    DoWobbel(WaazNRLE, Waaz, Count, Count, 320, 200);

    GenuinePaprikaChips(IncX,IncY,Bufter,Ooze1);
    IncX = (1+sin(Degree/90*M_PI))*(2*180*sin(Degree/180*M_PI)*0.83333333);
    IncY = (1+sin(Degree/90*M_PI))*(2*180*cos(Degree/180*M_PI));
    //  IncX = 1000;
    //  IncY = 1000;


    //  if(Count>128)
    ShowPic(Bufter, Alita, 256, 150);

    NRLEadd(Bufter2, Bufter, WaazNRLE);

    Degree+=2.0;
    if(Degree==360.0) Degree=0.0;

    //  DumpR(Bufter2,Bufter);
    Dump(Bufter2);
  }

  Palette(SunPal);

  God_init(&Obj, Frame, 62);

  while(!gfx.kbhit() && mod.position()<0x16) {
    updateloop;
    
    God();

    Dump(VidBuf);
  }

  Palette(Ooze1Pal);

  while(!gfx.kbhit() && mod.position()<0x1A) {
    updateloop;

    Count+=3;
    //    C=(2*M_PI)/256;
    //  +((sin(Count*C)+1)*30

    DoWobbel(WaazNRLE, Waaz, Count, Count, 320, 200);

    GenuinePaprikaChips(IncX,IncY,Bufter,Ooze1);
    IncX = (1+sin(Degree/90*M_PI))*(2*180*sin(Degree/180*M_PI)*0.83333333);
    IncY = (1+cos(Degree/90*M_PI))*(2*180*cos(Degree/180*M_PI));
    //  IncX = 1000;
    //  IncY = 1000;


    //  if(Count>128)
    ShowPic(Bufter, Alita, 256, 150);

    NRLEadd(Bufter2, Bufter, WaazNRLE);

    Degree+=2.0;
    if(Degree==360.0) Degree=0.0;

    DumpR(Bufter2,Bufter);
    //  Dump(Bufter2);
  }


  Palette(Frontback);
  memcpy(Gaten, Front, 0x10000);
  OfsInc=0;

  while(!gfx.kbhit() && mod.position()<0x1E) {
    updateloop;

    Count+=3;

    if(mod.position()>0x1A && toggle) Gatenkaas(Gaten, Circle);
    toggle = !toggle;
    DoWobbel(Bufter, Back, Count, Count, 320, 200);
    Polar(Angle+=AngInc,Offset+=OfsInc,Bufter2,Gaten);

    for(i=0;i<0xFA00;i++)
    {
      if(Bufter2[i]==0) Bufter2[i]=Bufter[i];
    }

    // wait retrace

    Dump(Bufter2);
  }


  Palette(v3pal);
  //  kroket(Bufter2,V3);
  Dump(V3);

  while(!gfx.kbhit()) {
    updateloop;
    noDump;
  }

  mod.stop();

  tijd.Total(frames);
  
  return 0;
}


int random2(int x)
{
    return (int)(((float)(rand()&0xFFFF) * (float)x) / (float)65535);
}

// Thaumaturge spul hieronder...

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Rotozoom ding                                         *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void GenuinePaprikaChips(word IncX, word IncY, byte *Bufter, byte *verspiegeld)
{
  word  x, y;
  word  PosX, PosY;
  dword Pos, Inc, Dst, Src;

  PosX = - (IncX*160 + IncY*100);
  PosY = - (IncX*100 - IncY*160);

  for(y=0, Dst=0; y<RESS_Y; y++)
  {
    Inc = ((dword) IncX<<16) + IncY;
    Pos = ((dword) PosX<<16) + PosY;

    for(x=0; x<RESS_X; x++)
    {
    Pos += Inc;
//      Pos += Inc<<1;
      Src  = ((Pos>>16)&0xFF00) + ((Pos>>8)&0xFF);
      Bufter[Dst++]=verspiegeld[Src];
    }

    PosX+=IncY;
    PosY-=IncX;
  }
 }

void ShowPic(byte *Buffer, byte *Pic, word xs, word ys)
{
  word y, x;
  for(y=0;y<ys;y++)
  {
    for(x=0;x<(xs-1);x++)
    {
      if(Pic[y*256+x]!=255) Buffer[y*320+x]=Pic[y*256+x];
    }
  }
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Gaten                                                 *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void Gatenkaas(byte *Target, byte *Source)
{
  word x, y, x2, y2, thunder, lightning;


  x2 = random2(256);
  y2 = random2(256);

  for(x=0;x<32;x++)
  {
    for(y=0;y<32;y++)
    {
      if((y2+y)<256) thunder = (y2+y)*256; else thunder = (y2+y-256)*256;
      if((x2+x)<256) lightning = (x2+x); else lightning = (x2+x-256);
      if(Source[y*(32+1)+x]==0) Target[thunder+lightning]=0;
    }
  }
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Wobbel                                                *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void DoWobbel(byte *Target, byte *Source, byte AddXtex, byte AddYtex, word Resx, word Resy)
{
  word Xpos, Ypos;
  byte Xtex, Ytex;

  if(Resx==320)
  {
    for(Ypos=0;Ypos<Resy;Ypos++)
    {
      for(Xpos=0;Xpos<Resx;Xpos++)
      {
        Xtex=Xpos-AddE320[Ypos]+AddXtex;
        Ytex=Ypos-AddS320[Xpos]+AddYtex;

        Target[Xpos+(Ypos*Resx)]=Source[Xtex+(Ytex*256)];

      }
    }
  }
  else
  {
    for(Ypos=0;Ypos<Resy;Ypos++)
    {
      for(Xpos=0;Xpos<Resx;Xpos++)
      {
        Xtex=Xpos-AddE256[Ypos]+AddXtex;
        Ytex=Ypos-AddS256[Xpos]+AddYtex;

        Target[Xpos+(Ypos*Resx)]=Source[Xtex+(Ytex*256)];

      }
    }
  }
}

void Sines(byte Amp, word Freq, byte *Tabel, word Res)
{
  word x; //, y;
  float a;

  a=(2*M_PI)/Freq;

  for(x=0;x<Res;x++) Tabel[x]= (0.5*Amp*(sin(a*x)+1));
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Filezooi                                              *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
short LoadBin(char *File, void *Buffer)
{
  long filesize;
  FILE *in;

  in=fopen(File,"rb");
  if(!in) return(FALSE);

  filesize=FileLength(in)-1;
  filesize-=fread(Buffer,1,filesize,in);
  if(filesize)
    return(FALSE);
  return(TRUE);
}

long FileLength(FILE *fs)
{
  long current,result;

  current=ftell(fs);

  fseek(fs,0,SEEK_END);
  result=ftell(fs);

  fseek(fs,current,SEEK_SET);
  return(result);
}

void NRLEadd(byte *Target, byte *Source, byte* NRLE)
{
  word i;

  for(i=0;i<0xFA00;i++)
  {
    Target[i]=Source[i]+NRLE[i]*64;
  }
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Palette                                               *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void Palette(byte *Paula)
{
  word i;

  //  outportb(0x3C8,0);
  //  for(i=0;i<768;i++) outportb(0x3C9,Paula[i]);
  for(i=0;i<256;i++) gfx.pal(i,Paula[3*i+0],Paula[3*i+1],Paula[3*i+2]);
  //  for(i=0;i<256;i++) gfx.pal(i,i,i,i);
  gfx.initpal();
}

void HalfPalette(byte *Paula)
{
  word i;

  //  outportb(0x3C8,0);
  //  for(i=0;i<64*3;i++) outportb(0x3C9,Paula[i]>>1);
  for(i=0;i<64;i++) gfx.pal(i,Paula[3*i+0]>>1,Paula[3*i+1]>>1,Paula[3*i+2]>>1);
  gfx.initpal();
}


void InitPalette(byte *Paula)
{
  word i;

  for(i=0; i<16*3; i+=3)
  {
    if      (Paula[i]+(Redh*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Redh*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Redh*3);
    if      (Paula[i]+(Redh*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Redh*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Redh*2);
    if      (Paula[i]+(Redh*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Redh*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Redh*1);
  }
  for(i=1; i<16*3; i+=3)
  {
    if      (Paula[i]+(Grnh*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Grnh*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Grnh*3);
    if      (Paula[i]+(Grnh*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Grnh*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Grnh*2);
    if      (Paula[i]+(Grnh*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Grnh*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Grnh*1);
  }
  for(i=2; i<16*3; i+=3)
  {
    if      (Paula[i]+(Bluh*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Bluh*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Bluh*3);
    if      (Paula[i]+(Bluh*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Bluh*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Bluh*2);
    if      (Paula[i]+(Bluh*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Bluh*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Bluh*1);
  }
  for(i=16*3+0; i<64*3; i+=3)
  {
    if      (Paula[i]+(Redi*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Redi*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Redi*3);
    if      (Paula[i]+(Redi*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Redi*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Redi*2);
    if      (Paula[i]+(Redi*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Redi*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Redi*1);
  }
  for(i=16*3+1; i<64*3; i+=3)
  {
    if      (Paula[i]+(Grni*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Grni*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Grni*3);
    if      (Paula[i]+(Grni*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Grni*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Grni*2);
    if      (Paula[i]+(Grni*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Grni*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Grni*1);
  }
  for(i=16*3+2; i<64*3; i+=3)
  {
    if      (Paula[i]+(Blui*3)>0x3F) Paula[i+192*3] = 0x3F;
    else if (Paula[i]+(Blui*3)<0)    Paula[i+192*3] = 0;
    else                             Paula[i+192*3]=Paula[i]+(Blui*3);
    if      (Paula[i]+(Blui*3)>0x3F) Paula[i+128*3] = 0x3F;
    else if (Paula[i]+(Blui*3)<0)    Paula[i+128*3] = 0;
    else                             Paula[i+128*3]=Paula[i]+(Blui*2);
    if      (Paula[i]+(Blui*3)>0x3F) Paula[i+ 64*3] = 0x3F;
    else if (Paula[i]+(Blui*3)<0)    Paula[i+ 64*3] = 0;
    else                             Paula[i+ 64*3]=Paula[i]+(Blui*1);
  }
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Polar                                                 *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void Polar(byte Ang, byte Ofs, byte *Bufter, byte *verspiegeld)
{
  word Pc;

  for(Pc=0; Pc<64000; Pc++)
    Bufter[Pc] = verspiegeld[( ((Radius[Pc] + Ofs)<<8) + Angle2[Pc] + Ang ) & 0xFFFF];
}

void InitPolar(void)
{
  byte a=0; //, r;
  word c=0;
  double x,y;
  
  for(y=-100;y<100;y++)
    {
      //      std::cout << '#';
      for(x=-160;x<160;x++)
	{
	  if(x==0)
	    {
	      if(y<0)  a=64;
	      if(y==0) a=0;
	      if(y>0)  a=192;
	    }
	  else
	    {
	      a = (128.0*(atan2(y,x)+M_PI)) / (M_PI);
	    }
	  
	  Angle2[c]=a;
	  Radius[c]=(byte) sqrt(x*x+y*y);
	  
	  c++;
	}
    }
}

/****************************************************************************\
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                      Spiegel                                               *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
*                                                                            *
\****************************************************************************/
void MirrorEgg(byte *Tex)
{
  unsigned short x,y,yofs;

  for(y=0,yofs=0;y<128;y++)
  {
    for(x=0;x<64;x++)
    {
      Tex[yofs+127-x]=Tex[x+yofs];
    }
    yofs+=256;
  }

  for(y=0,yofs=0;y<128;y++)
  {
    for(x=0;x<128;x++)
      Tex[x+255*256-yofs]=Tex[x+yofs];

    yofs+=256;
  }

  for(y=0,yofs=0;y<256;y++)
  {
    memcpy(Tex+yofs+128,Tex+yofs,128);
    yofs+=256;
  }
}

void spihCakirpaPeniuneG(word IncX, word IncY, byte *Bufter, byte *Texture)
{
  word  x, y;
  word  PosX, PosY;
  dword Pos, Inc, Dst, Src;

  PosX = - (IncX*160 + IncY*100);
  PosY = - (IncX*100 - IncY*160);

  for(y=0, Dst=0; y<128; y++)
  {
    Inc = ((dword) IncX<<16) + IncY;
    Pos = ((dword) PosX<<16) + PosY;

    for(x=0; x<64; x++)
    {
      Pos += Inc;
      Src  = ((Pos>>16)&0xFF00) + ((Pos>>8)&0xFF);
      Bufter[Dst++]=Texture[Src];
    }
    Dst+=256-64;

    PosX+=IncY;
    PosY-=IncX;
  }
}

void kroket(byte *Target, byte *Source)
{
  word  x, y;

  for(y=0;y<320*200;y+=320)
  {
    for(x=0;x<320;x++)
    {
      if(Source[y+x]!=0) Target[y+x]=Source[y+x];
    }
  }
}

void God_init(_Object *Obj, _Frame *Frame, short NoFrames)
{
  noframes = NoFrames;

  CloneObj(&TRObj,Obj);
  CloneObj(&Flat,Obj);

  TRObj.Vertex=VT1;
  Flat.Vertex=VT2;
  
  SObj = *Obj;
  frame = Frame;

  c=1;
}

void God()
{
  c++;
  if (c>=noframes) c=1;


  //    if((mod.position()==0x0F) && (mod.row()>0x2A)) break;
  //    if((mod.position()==0x15) && (mod.row()>0x20)) break;

  TRot(&TRObj,SObj,
       frame[c].dx,frame[c].dy,frame[c].dz,
       frame[c].ax,frame[c].ay,frame[c].az);
  Perspective(&Flat, TRObj);

  Offset=0;
  Polar(Angle+=AngInc,Offset+=OfsInc,VidBuf,Sun);
  Display(Flat);
}

void TRot(_Object *DST,_Object SRC,
         long dX,long dY,long dZ,
         float aX,float aY,float aZ)
{
  int c; //,v;

  float m1,m2,m3,m4,m5,m6,m7,m8,m9,t1,t2,t3,t4;

  m1 = cos(aY)*cos(aZ);
  m2 = sin(aX)*sin(aY)*cos(aZ)-cos(aX)*sin(aZ);
  m3 = cos(aX)*sin(aY)*cos(aZ)+sin(aX)*sin(aZ);

  m4 = cos(aY)*sin(aZ);
  m5 = sin(aX)*sin(aY)*sin(aZ)+cos(aX)*cos(aZ);
  m6 = cos(aX)*sin(aY)*sin(aZ)-sin(aX)*cos(aZ);

  m7 =-sin(aY);
  m8 = sin(aX)*cos(aY);
  m9 = cos(aX)*cos(aY);

  t2 = m1*m2;
  t3 = m4*m5;
  t4 = m7*m8;

  for(c=0;c<SRC.NoVerteces;c++)
  {
    t1=SRC.Vertex[c].X * SRC.Vertex[c].Y;

    DST->Vertex[c].X=(SRC.Vertex[c].X+m2)*(SRC.Vertex[c].Y+m1) - t1 - t2 + SRC.Vertex[c].Z * m3 + dX;
    DST->Vertex[c].Y=(SRC.Vertex[c].X+m5)*(SRC.Vertex[c].Y+m4) - t1 - t3 + SRC.Vertex[c].Z * m6 + dY;
    DST->Vertex[c].Z=(SRC.Vertex[c].X+m8)*(SRC.Vertex[c].Y+m7) - t1 - t4 + SRC.Vertex[c].Z * m9 + dZ;
  }
  DST->NoVerteces=SRC.NoVerteces;
}

void Perspective(_Object *DST, _Object SRC)
{
  long c;

  for(c=0;c<SRC.NoVerteces;c++)
  {
    DST->Vertex[c].X= 160+D*(SRC.Vertex[c].X)/(SRC.Vertex[c].Z+H);
    DST->Vertex[c].Y= 100+D*(SRC.Vertex[c].Y)/(SRC.Vertex[c].Z+H);
  }
  DST->NoVerteces=SRC.NoVerteces;
}

void Display(_Object Obj)
{
  long c;
  _Vertex *V;

  V=Obj.Vertex;
  for(c=0;c<Obj.NoLines;c++)
  {
    Line(V[Obj.Line[c].A].X, V[Obj.Line[c].A].Y,
         V[Obj.Line[c].B].X, V[Obj.Line[c].B].Y);
  }
}


void Line(int X1,int Y1,int X2,int Y2)
{
  float a,b,x,y,Slope;
  int r,c;
  c=(int)((0.8*g)+0.5);
  
  if(X2-X1==0&Y2-Y1==0)
    Pix(X1,Y1,c);
  else
    {
      if(abs(X2-X1)>=abs(Y2-Y1))
	{
	  if(X1>X2)
	    {
	      a=X2;
	      X2=X1;
	      X1=a;
	      
	      a=Y2;
	      Y2=Y1;
	      Y1=a;
	    }

	  Slope=(float)(Y2-Y1)/(X2-X1);

	  for(x=X1,y=Y1;x<=X2;x++)
	    {
	      if((int)y==y)
		Pix(x,y,c);
	      else
		{
		  a=((y-(int)y)*g);
		  b=((1-(y-(int)y))*g);
		  r=(int)(y+0.5);
		  if(a<b)
		    {
		      Pix(x,r,b);
		      Pix(x,r+1,a);
		    }
		  else
		    {
		      Pix(x,r-1,b);
		      Pix(x,r,a);
		    }
		}
	      y+=Slope;
	    }
	}
      else
	{
	  if(Y1>Y2)
	    {
	      a=Y2;
	      Y2=Y1;
	      Y1=a;

	      a=X2;
	      X2=X1;
	      X1=a;
	    }

	  Slope=(float)(X2-X1)/(Y2-Y1);

	  for(y=Y1,x=X1;y<=Y2;y++)
	    {
	      if((int)x==x)
		Pix(x,y,c);
	      else
		{
		  a=((x-(int)x)*g);
		  b=((1-(x-(int)x))*g);
		  r=(int)(x+0.5);
		  if(a<b)
		    {
		      Pix(r,y,b);
		      Pix(r+1,y,a);
		    }
		  else
		    {
		      Pix(r-1,y,b);
		      Pix(r,y,a);
		    }
		}
	      x+=Slope;
	    }
	}
    }
}
