/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

 */


#include "MikMod.h"

MikMod::~MikMod(void) {
  MikMod_Exit();
}

MikMod::MikMod(char* modfile) {
  MikMod_RegisterAllDrivers();
  MikMod_RegisterAllLoaders();
  
  md_reverb = 0;

  if(MikMod_Init("")) {
    printf("Could not initialize sound, reason: %s\n",
	   MikMod_strerror(MikMod_errno));
    exit(4);
  }
  
  module = Player_Load(modfile,0x10,0);  // 0x10 = number of voices.
  if(!module) {
    printf("Could not load module, reason: %s\n",
	   MikMod_strerror(MikMod_errno));
    exit(5);
  }

  module->wrap = 1; // yes looping.
}
