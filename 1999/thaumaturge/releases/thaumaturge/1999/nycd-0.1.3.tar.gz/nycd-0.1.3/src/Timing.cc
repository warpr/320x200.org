/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

 */

#include "Timing.h"

int
timeval_subtract (struct timeval *result, struct timeval *x, struct timeval *y)
{
  // Perform the carry for the later subtraction by updating Y. 
  if (x->tv_usec < y->tv_usec) {
    int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
    y->tv_usec -= 1000000 * nsec;
    y->tv_sec += nsec;
  }
  if (x->tv_usec - y->tv_usec > 1000000) {
    int nsec = (y->tv_usec - x->tv_usec) / 1000000;
    y->tv_usec += 1000000 * nsec;
    y->tv_sec -= nsec;
  }
  
  // Compute the time remaining to wait. `tv_usec' is certainly positive. 
  result->tv_sec = x->tv_sec - y->tv_sec;
  result->tv_usec = x->tv_usec - y->tv_usec;
  
  // Return 1 if result is negative. 
  return x->tv_sec < y->tv_sec;
}

Timing::Timing(int Hz=70) 
{
  if (Hz==0) {
    std::cout << "0 Hz? ain't that cute,...\n";
    std::cout << "BUT IT'S WRONG!!!\n";
    exit(7);
  }
  frametime = 1000000/Hz;
  gettimeofday(&start,NULL);
  gettimeofday(&mark,NULL);
}

void Timing::Total(int frames=0)
{
  double tijd;
  gettimeofday(&end,NULL);
  timeval_subtract(&t, &end, &start);
  tijd = t.tv_usec + t.tv_sec*1000000;
  tijd = tijd / 1000000;

  if(frames==0) {
    std::cout << tijd << " seconden verstreken.\n";
  } else {
    std::cout << frames << " frames / " << tijd << " seconden = " << frames/tijd << " fps.\n";
  }
}

void Timing::Wait(void)
{
  int td=0;
  while(td<frametime) {
    gettimeofday(&t,NULL);
    timeval_subtract(&end, &t, &mark);
    td = end.tv_usec;
  }
  gettimeofday(&mark,NULL);
}
