/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

 */

#include <iostream>
#include <memory>
#include "OpenPTC.h"

OpenPTC::~OpenPTC(void) { 
  surface.unlock();
}

OpenPTC::OpenPTC(int X, int Y)
  : x(X), y(Y), bpp(8), usedb(true), usert(false), format(8), surface(X,Y,format)
{
  try
    {
      std::cout << "PTC: ";
      
      console.option("dga pedantic init");
      console.open("Thaumaturge 1997 - nycd",x,y,format);
      
      for (int i=0; i<256; i++) data[i] = i;
      
      palette.load(data);
      console.palette(palette);
      surface.palette(palette);
      
      bp = (unsigned char*) surface.lock();
      
      std::cout << "PTC: " << "X: " << x << ", Y: " << y << ", bpp: " 
		<< bpp << ", usedb: " << usedb << ", usert: " << usert << ".\n";
    }
  catch (Error error)
    {
      error.report();
      exit(1);
    }
}

