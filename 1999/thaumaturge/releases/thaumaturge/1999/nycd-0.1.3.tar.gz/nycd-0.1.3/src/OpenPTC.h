/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

 */


#ifndef _S_PTC_
#define _S_PTC_

#include <ptc/ptc.h>

class OpenPTC {
 public:
  OpenPTC(int X, int Y);
  
  ~OpenPTC(void);
  
  void flush(void) { 
    surface.unlock();
    surface.copy(console);
    console.update();
    surface.lock();
  }

  void putbox(void* vid) {  }
  void pal(int c, int r, int g, int b) { 
    data[c] = (r<<18) | (g<<10) | (b<<2);
  }
  void initpal(void) {
    palette.load(data);
    console.palette(palette);
    surface.palette(palette);
  }

  bool kbhit(void) { return console.key(); }
  void Wait(void) { }
  
  unsigned char*   p(void)   { return bp; }
  
  int x;
  int y;
  int bpp;
  bool usedb;
  bool usert;
 private:
  int32 data[256];
  Console console;
  Format format;
  Surface surface;
  Palette palette;

  unsigned char* bp;
};


#endif 

