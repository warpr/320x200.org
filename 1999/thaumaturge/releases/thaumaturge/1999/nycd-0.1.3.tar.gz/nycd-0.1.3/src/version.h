
#define ver "thaumaturge 1997 - nycd 0.1.3"
