/*
  This file is part of nycd, a Thaumaturge demo.
  nycd is copyright 1997-1999 by Thaumaturge.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; see the file COPYING; if not, write to
  the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

 */


#ifndef _S_GGI_
#define _S_GGI_

#include <ggi/ggi.h>
#include <ggi/misc.h>

class libGGI {
 public:
  libGGI(int X, int Y);
  
  ~libGGI(void);
  
  void flush(void) { ggiFlush(visual); }
  void putbox(void* vid) { ggiPutBox(visual, 0, 0, x, y, vid); }
  void pal(int c, int r, int g, int b) { 
    colours[c].r = r<<10;
    colours[c].g = g<<10;
    colours[c].b = b<<10;
  }
  void initpal(void) { ggiSetPalette(visual, 0, 0x100, colours); }

  bool kbhit(void) { return ggiKbhit(visual); }
  void Wait(void) { ggiWaitRayPos(visual, &raypos_x, &raypos_y); }
  
  unsigned char*   p(void)   { return bp;   }
  
  int x;
  int y;
  int bpp;
  bool usedb;
  bool usert;
 private:
  ggi_color colours[0x100];
  ggi_mode suggested;
  ggi_visual_t visual;
  const ggi_directbuffer *dbuf;
  const ggi_pixelformat *format;
  sint32 raypos_x, raypos_y;
  
  unsigned char* bp;
};


#endif 

