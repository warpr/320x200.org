#!/bin/sh 
nasm -f bin doslinux.asm -o doslinux.com 
chmod +x doslinux.com
